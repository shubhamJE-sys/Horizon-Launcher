package com.horizon.launcher;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * The poster home screen. The whole screen is one sky that follows the time and weather; the frame lines,
 * clock, messages, battery, signal meter, music deck and text buttons are all drawn here.
 */
public class PosterView extends View {

    public interface Host {
        void openDrawer();

        void pickApp(int target);

        void openStyleMenu();
    }

    private static final float DW = 360f, DH = 804f;
    private static final int RED_DEFAULT = Color.parseColor("#C8382C");
    private static final int MOON = Color.parseColor("#EDE6D3");

    private static final float SC_L = 9.5f, SC_T = 241f, SC_R = 350.5f, SC_B = 477f;
    private static final float LAKE_Y = 241f + 236f * 0.66f;

    // music deck
    private static final float DECK_L = 12f, DECK_T = 399f, DECK_R = 348f, DECK_B = 549f;
    private static final float KEY_T = 494f, KEY_B = 540f;
    private static final float[] KEY_L = {24f, 104f, 184f, 264f};
    private static final float KEY_W = 72f;

    private static final String WEATHER_URL =
            "https://api.open-meteo.com/v1/forecast?latitude=26.23&longitude=81.23"
                    + "&current=temperature_2m,weather_code,cloud_cover"
                    + "&daily=sunrise,sunset&timezone=auto&forecast_days=1";

    private static final String[] BUTTON_WORDS = {
            "PHONE", "MESSAGES", "BROWSER", "GALLERY", "CAMERA", "PLAY STORE"};
    private static final String[] DEFAULT_CAPS = {
            "MAKE THE CALL", "SEND A MESSAGE", "BROWSE THE WEB",
            "SHARE YOUR MOMENTS", "CAPTURE THE MOMENT", "DISCOVER NEW APPS"};
    private static final String[] NEWS_PACKAGES = {
            "com.google.android.apps.magazines", "com.eterno", "com.nis.app",
            "com.microsoft.amp.apps.bingnews", "flipboard.app", "com.toi.reader.activities"};

    private static final float[][] CLOUDS = {
            {.15f, .12f, 1.0f}, {.58f, .05f, 1.3f}, {.82f, .24f, 0.9f}, {.33f, .30f, 1.1f},
            {.70f, .40f, 1.0f}, {.06f, .42f, 0.8f}, {.92f, .02f, 0.8f}};

    private static final String[] TOWER = {
            "....#....",
            ".#..#..#.",
            "#.#.#.#.#",
            "#.#.#.#.#",
            "...###...",
            "...#.#...",
            "..#...#.."};

    private final Host host;
    private Bitmap sceneBmp;
    private String sceneBmpId = "";
    private Typeface bebas, roboto;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint layerPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audio;
    private SignalWatcher signal;
    private ConnectivityManager.NetworkCallback netCallback;

    private float scale = 1f, offX = 0f, offY = 0f;
    private int bottomInset = 0;
    private boolean receiving = false;
    private boolean started = false;
    private long lastTap = 0;

    private float downX, downY;
    private long downTime;
    private int touchSlop = 24;

    private int batteryPct = 100;
    private int pluggedType = 0;
    private float tempC = -1f;

    private boolean weatherOk = false;
    private volatile boolean fetching = false;
    private long lastFetch = 0;
    private int wCode = 0, wCloud = 0;
    private float wTemp = 0f;
    private int sunriseMin = 360, sunsetMin = 1080;

    private final float[] rainX = new float[120];
    private final float[] rainY = new float[120];
    private final float[] starX = new float[70];
    private final float[] starY = new float[70];
    private final float[] starR = new float[70];

    private boolean panelOpen = false;

    // user-chosen apps: 0-5 buttons, 6 music, 7 clock, 8 calendar, 9 greeting (news)
    private final ComponentName[] custom = new ComponentName[10];
    private final String[] customLabel = new String[10];
    private SharedPreferences prefs;
    private boolean longFired = false;
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            onLongPress();
        }
    };
    private final Runnable wallHold = new Runnable() {
        @Override
        public void run() {
            onWallHold();
        }
    };

    // look of the day
    private ContentPack pack;
    private Look look;
    private int lookDay = Integer.MIN_VALUE;
    private boolean lookDirty = true;
    private Sky sky;
    private Palette pal = Palette.HORIZON;

    // sun / moon of this frame
    private float bodyX, bodyY, bodyR;
    private boolean bodyUp, isDay;

    // network readout
    private float wifiFrac = 0f, mobFrac = 0f;
    private String wifiLabel = "WI-FI • OFF", mobLabel = "MOBILE • --";
    private boolean noNet = false;

    // battery message cache
    private String batText = "";
    private String batKey = "";

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                readBattery(intent);
            }
            fetchWeather();
            invalidate();
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (started && panelOpen) handler.postDelayed(this, musicActive() ? 90 : 1000);
        }
    };

    public PosterView(Context ctx, Host host) {
        super(ctx);
        this.host = host;
        setBackgroundColor(Sky.CREAM);
        try {
            touchSlop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        } catch (Exception ignored) { }
        try {
            bebas = Typeface.createFromAsset(ctx.getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(ctx.getAssets(), "Roboto-Regular.ttf");
        } catch (Exception e) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }
        audio = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        prefs = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
        for (int i = 0; i < custom.length; i++) {
            String f = prefs.getString("app_" + i, null);
            if (f != null) {
                custom[i] = ComponentName.unflattenFromString(f);
                customLabel[i] = prefs.getString("label_" + i, "");
            }
        }
        sunriseMin = prefs.getInt("sr", 360);
        sunsetMin = prefs.getInt("ss", 1080);
        pack = ContentPack.load(ctx);

        signal = new SignalWatcher(ctx, new Runnable() {
            @Override
            public void run() {
                postInvalidate();
            }
        });

        Random r = new Random(11);
        for (int i = 0; i < rainX.length; i++) {
            rainX[i] = r.nextFloat() * 341f;
            rainY[i] = r.nextFloat() * 236f;
        }
        for (int i = 0; i < starX.length; i++) {
            starX[i] = 4f + r.nextFloat() * 352f;
            starY[i] = 8f + r.nextFloat() * 370f;
            starR[i] = 0.5f + r.nextFloat() * 0.9f;
        }
        Intent sticky = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (sticky != null) readBattery(sticky);
    }

    // ---------- public API for the activity ----------

    public void setBottomInset(int px) {
        bottomInset = Math.max(0, px);
        invalidate();
    }

    public void setCustom(int target, ComponentName cn, String label) {
        if (target < 0 || target >= custom.length) return;
        SharedPreferences.Editor ed = prefs.edit();
        if (cn == null) {
            custom[target] = null;
            customLabel[target] = null;
            ed.remove("app_" + target).remove("label_" + target);
        } else {
            custom[target] = cn;
            customLabel[target] = label;
            ed.putString("app_" + target, cn.flattenToString()).putString("label_" + target, label);
        }
        ed.apply();
        invalidate();
    }

    public void closePanel() {
        panelOpen = false;
        handler.removeCallbacks(ticker);
        invalidate();
    }

    /** Called after the style menu changed a setting or a pack was imported. */
    public void refreshLook() {
        lookDirty = true;
        invalidate();
    }

    public void reloadPack() {
        pack = ContentPack.load(getContext());
        lookDirty = true;
        invalidate();
    }

    public ContentPack pack() {
        return pack;
    }

    public Look look() {
        ensureLook(Calendar.getInstance());
        return look;
    }

    public int skyMid() {
        return sky != null ? sky.mid() : Sky.CREAM;
    }

    public int skyInk() {
        return sky != null ? sky.fgAt(400f) : Sky.INK;
    }

    public int skyAccent() {
        return sky != null ? sky.accent() : RED_DEFAULT;
    }

    public int sunriseMin() {
        return sunriseMin;
    }

    public int sunsetMin() {
        return sunsetMin;
    }

    public float cloudAmount() {
        return cloudFrac();
    }

    // ---------- lifecycle (called by the activity) ----------

    public void start() {
        started = true;
        if (!receiving) {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_TIME_TICK);
            f.addAction(Intent.ACTION_TIME_CHANGED);
            f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            f.addAction(Intent.ACTION_BATTERY_CHANGED);
            f.addAction(Intent.ACTION_POWER_CONNECTED);
            f.addAction(Intent.ACTION_POWER_DISCONNECTED);
            f.addAction("android.net.conn.CONNECTIVITY_CHANGE");
            f.addAction("android.net.wifi.RSSI_CHANGED");
            f.addAction("android.net.wifi.WIFI_STATE_CHANGED");
            if (Build.VERSION.SDK_INT >= 33) {
                getContext().registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                getContext().registerReceiver(receiver, f);
            }
            receiving = true;
        }
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && netCallback == null) {
                netCallback = new ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(Network network) {
                        postInvalidate();
                    }

                    @Override
                    public void onLost(Network network) {
                        postInvalidate();
                    }

                    @Override
                    public void onCapabilitiesChanged(Network network, NetworkCapabilities nc) {
                        postInvalidate();
                    }
                };
                NetworkRequest req = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
                cm.registerNetworkCallback(req, netCallback);
            }
        } catch (Throwable t) {
            netCallback = null;
        }
        if (signal != null) signal.start();
        Intent sticky = getContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (sticky != null) readBattery(sticky);
        fetchWeather();
        invalidate();
        handler.removeCallbacks(ticker);
        if (panelOpen) handler.postDelayed(ticker, 500);
    }

    public void stop() {
        started = false;
        handler.removeCallbacks(ticker);
        handler.removeCallbacks(longPress);
        handler.removeCallbacks(wallHold);
        if (receiving) {
            try { getContext().unregisterReceiver(receiver); } catch (Exception ignored) { }
            receiving = false;
        }
        if (netCallback != null) {
            try {
                ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                if (cm != null) cm.unregisterNetworkCallback(netCallback);
            } catch (Throwable ignored) { }
            netCallback = null;
        }
        if (signal != null) signal.stop();
    }

    // ---------- battery ----------

    private void readBattery(Intent i) {
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scaleVal = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (level >= 0 && scaleVal > 0) batteryPct = Math.round(level * 100f / scaleVal);
        pluggedType = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        tempC = t >= 0 ? t / 10f : -1f;
    }

    // ---------- weather ----------

    private void fetchWeather() {
        long now = SystemClock.elapsedRealtime();
        if (fetching) return;
        if (weatherOk && now - lastFetch < 30L * 60L * 1000L) return;
        if (!weatherOk && lastFetch != 0 && now - lastFetch < 2L * 60L * 1000L) return;
        fetching = true;
        lastFetch = now;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection con = (HttpURLConnection) new URL(WEATHER_URL).openConnection();
                    con.setConnectTimeout(8000);
                    con.setReadTimeout(8000);
                    InputStream in = con.getInputStream();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    con.disconnect();
                    JSONObject j = new JSONObject(bo.toString("UTF-8"));
                    JSONObject cur = j.getJSONObject("current");
                    final float temp = (float) cur.getDouble("temperature_2m");
                    final int code = cur.getInt("weather_code");
                    final int cloud = cur.getInt("cloud_cover");
                    JSONObject d = j.getJSONObject("daily");
                    final int sr = toMinutes(d.getJSONArray("sunrise").getString(0));
                    final int ss = toMinutes(d.getJSONArray("sunset").getString(0));
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            wTemp = temp;
                            wCode = code;
                            wCloud = cloud;
                            if (sr > 0 && ss > sr) {
                                sunriseMin = sr;
                                sunsetMin = ss;
                                prefs.edit().putInt("sr", sr).putInt("ss", ss).apply();
                            }
                            prefs.edit().putInt("wcloud", cloud).putInt("wcode", code).apply();
                            weatherOk = true;
                            invalidate();
                        }
                    });
                } catch (Exception ignored) {
                } finally {
                    fetching = false;
                }
            }
        }).start();
    }

    private int toMinutes(String iso) {
        int h = Integer.parseInt(iso.substring(11, 13));
        int m = Integer.parseInt(iso.substring(14, 16));
        return h * 60 + m;
    }

    private float cloudFrac() {
        if (!weatherOk) return 0f;
        float c = wCloud / 100f;
        if (wCode >= 51) c = Math.max(c, 0.8f);
        else if (wCode == 45 || wCode == 48) c = Math.max(c, 0.6f);
        return Math.max(0f, Math.min(1f, c));
    }

    private int rainLevel() {
        if (!weatherOk) return 0;
        switch (wCode) {
            case 51: case 53: case 55: case 56: case 57:
                return 1;
            case 61: case 63: case 66: case 80: case 81:
                return 2;
            case 65: case 67: case 82: case 95: case 96: case 99:
                return 3;
            default:
                return 0;
        }
    }

    private boolean snowing() {
        return weatherOk && ((wCode >= 71 && wCode <= 77) || wCode == 85 || wCode == 86);
    }

    private String weatherLabel(boolean night) {
        switch (wCode) {
            case 0: return night ? "CLEAR NIGHT" : "CLEAR SKY";
            case 1: return "MOSTLY CLEAR";
            case 2: return "PARTLY CLOUDY";
            case 3: return "OVERCAST";
            case 45: case 48: return "FOG";
            case 51: case 53: case 55: case 56: case 57: return "DRIZZLE";
            case 61: case 63: case 65: case 66: case 67: return "RAIN";
            case 80: case 81: case 82: return "SHOWERS";
            case 71: case 73: case 75: case 77: case 85: case 86: return "SNOW";
            case 95: case 96: case 99: return "THUNDERSTORM";
            default: return "WEATHER";
        }
    }

    // ---------- network readout (Wi-Fi row and mobile row) ----------

    private static String strength(float frac) {
        if (frac >= 0.75f) return "STRONG";
        if (frac >= 0.5f) return "GOOD";
        if (frac >= 0.28f) return "FAIR";
        return "WEAK";
    }

    private void readNetwork() {
        boolean wifiConn = false, cellData = false;
        int rssi = Integer.MIN_VALUE;
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                    if (nc == null || !nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue;
                    if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        wifiConn = true;
                        if (Build.VERSION.SDK_INT >= 29) {
                            int ss = nc.getSignalStrength();
                            if (ss != NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED) rssi = ss;
                        }
                    } else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        cellData = true;
                    }
                }
            }
        } catch (Throwable ignored) { }

        boolean wifiOn = false;
        try {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                wifiOn = wm.isWifiEnabled();
                if (wifiConn && rssi == Integer.MIN_VALUE) {
                    WifiInfo wi = wm.getConnectionInfo();
                    if (wi != null && wi.getRssi() > -127) rssi = wi.getRssi();
                }
            }
        } catch (Throwable ignored) { }

        if (wifiConn) {
            if (rssi != Integer.MIN_VALUE) {
                wifiFrac = Math.max(0.08f, Math.min(1f, (rssi + 100f) / 50f));
                wifiLabel = "WI-FI • " + strength(wifiFrac);
            } else {
                wifiFrac = 1f;
                wifiLabel = "WI-FI • CONNECTED";
            }
        } else {
            wifiFrac = 0f;
            wifiLabel = wifiOn ? "WI-FI • NOT JOINED" : "WI-FI • OFF";
        }

        int lvl = signal != null ? signal.level() : -1;
        if (lvl >= 0) {
            mobFrac = lvl / 4f;
            mobLabel = lvl == 0 ? "MOBILE • NO SIGNAL" : "MOBILE • " + strength(Math.max(0.28f, mobFrac));
            if (lvl == 4) mobLabel = "MOBILE • STRONG";
        } else {
            mobFrac = cellData ? 1f : 0f;
            mobLabel = cellData ? "MOBILE • DATA ON" : "MOBILE • DATA OFF";
        }
        noNet = !wifiConn && !cellData;
    }

    // ---------- music remote ----------

    private boolean musicActive() {
        try {
            return audio != null && audio.isMusicActive();
        } catch (Exception e) {
            return false;
        }
    }

    private void sendKey(int code) {
        try {
            long t = SystemClock.uptimeMillis();
            audio.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0));
            audio.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0));
        } catch (Exception ignored) { }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        }, 500);
    }

    private void transport(int which) {
        int key = which == 0 ? KeyEvent.KEYCODE_MEDIA_PREVIOUS
                : (which == 1 ? KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE : KeyEvent.KEYCODE_MEDIA_NEXT);
        sendKey(key);
    }

    private void launchComponent(ComponentName cn) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(cn);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }

    private void openMusicApp() {
        if (custom[6] != null) {
            launchComponent(custom[6]);
            return;
        }
        if (host != null) host.pickApp(6);
    }

    private void openNews() {
        if (custom[9] != null) {
            launchComponent(custom[9]);
            return;
        }
        PackageManager pm = getContext().getPackageManager();
        for (String pkg : NEWS_PACKAGES) {
            try {
                Intent li = pm.getLaunchIntentForPackage(pkg);
                if (li != null) {
                    li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(li);
                    return;
                }
            } catch (Exception ignored) { }
        }
        if (host != null) host.pickApp(9);
    }

    private void openClock() {
        if (custom[7] != null) {
            launchComponent(custom[7]);
            return;
        }
        try {
            Intent i = new Intent(AlarmClock.ACTION_SHOW_ALARMS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            return;
        } catch (Exception ignored) { }
        try {
            PackageManager pm = getContext().getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo r : pm.queryIntentActivities(main, 0)) {
                String lbl = String.valueOf(r.loadLabel(pm)).toLowerCase(Locale.ROOT);
                String pkg = r.activityInfo.packageName.toLowerCase(Locale.ROOT);
                if (lbl.contains("clock") || pkg.contains("deskclock") || pkg.contains("alarmclock")) {
                    launchComponent(new ComponentName(r.activityInfo.packageName, r.activityInfo.name));
                    return;
                }
            }
        } catch (Exception ignored) { }
    }

    private void openCalendar() {
        if (custom[8] != null) {
            launchComponent(custom[8]);
            return;
        }
        startIntent(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR));
    }

    private void startIntent(Intent i) {
        if (i == null) return;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }

    // ---------- touch ----------

    /** Which tappable area a point (design units) is in: 0-5 buttons, 6 music, 7 clock, 8 calendar, 9 greeting, 10 drawer strip, -1 none. */
    private int hotspot(float x, float y) {
        if (inRect(x, y, 240f, 480f, 350f, 552f)) return 6;
        if (inRect(x, y, 8f, 479f, 238f, 553f)) return 9;
        if (inRect(x, y, 8f, 641f, 352f, 771f)) {
            int col = (int) ((x - 8f) / (344f / 3f));
            col = Math.max(0, Math.min(2, col));
            return (y < 713f ? 0 : 3) + col;
        }
        if (inRect(x, y, 8f, 34f, 108f, 196f)) return 7;
        if (inRect(x, y, 108f, 34f, 228f, 150f) || inRect(x, y, 228f, 34f, 352f, 240f)) return 8;
        if (inRect(x, y, 90f, 771f, 270f, 800f)) return 10;
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = e.getX();
                downY = e.getY();
                downTime = SystemClock.uptimeMillis();
                longFired = false;
                handler.removeCallbacks(longPress);
                handler.removeCallbacks(wallHold);
                float x = (downX - offX) / scale, y = (downY - offY) / scale;
                if (!panelOpen) {
                    if (hotspot(x, y) >= 0 && hotspot(x, y) != 10) handler.postDelayed(longPress, 450);
                    else if (hotspot(x, y) < 0) handler.postDelayed(wallHold, 2000);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                float mx = e.getX() - downX, my = e.getY() - downY;
                if (mx * mx + my * my > (float) touchSlop * touchSlop * 2.5f) {
                    handler.removeCallbacks(longPress);
                    handler.removeCallbacks(wallHold);
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                handler.removeCallbacks(wallHold);
                return true;
            case MotionEvent.ACTION_UP: {
                handler.removeCallbacks(longPress);
                handler.removeCallbacks(wallHold);
                if (longFired) return true;
                float dx = e.getX() - downX, dy = e.getY() - downY;
                if (dy < -touchSlop * 4f && Math.abs(dy) > Math.abs(dx)) {
                    closePanel();
                    if (host != null) host.openDrawer();
                } else if (dx * dx + dy * dy <= (float) touchSlop * touchSlop
                        && SystemClock.uptimeMillis() - downTime < 500) {
                    handleTap(e.getX(), e.getY());
                }
                return true;
            }
            default:
                return true;
        }
    }

    private void onLongPress() {
        float x = (downX - offX) / scale;
        float y = (downY - offY) / scale;
        int target = hotspot(x, y);
        if (target >= 0 && target <= 9 && host != null) {
            longFired = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            host.pickApp(target);
        }
    }

    private void onWallHold() {
        if (host == null || panelOpen) return;
        longFired = true;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        host.openStyleMenu();
    }

    private boolean inRect(float x, float y, float l, float t, float r, float b) {
        return x >= l && x <= r && y >= t && y <= b;
    }

    private void handleTap(float px, float py) {
        long now = SystemClock.uptimeMillis();
        if (now - lastTap < 300) return;
        float x = (px - offX) / scale;
        float y = (py - offY) / scale;

        if (panelOpen) {
            lastTap = now;
            if (inRect(x, y, DECK_L, DECK_T, DECK_R, DECK_B)) {
                deckTap(x, y);
            } else {
                closePanel(); // touching outside closes the player
            }
            return;
        }
        int h = hotspot(x, y);
        if (h < 0) return;
        lastTap = now;
        switch (h) {
            case 6:
                panelOpen = true;
                handler.removeCallbacks(ticker);
                handler.postDelayed(ticker, 300);
                invalidate();
                break;
            case 7:
                openClock();
                break;
            case 8:
                openCalendar();
                break;
            case 9:
                openNews();
                break;
            case 10:
                if (host != null) host.openDrawer();
                break;
            default:
                launchButton(h);
                break;
        }
    }

    private void deckTap(float x, float y) {
        if (y < KEY_T || y > KEY_B) return;
        for (int i = 0; i < 4; i++) {
            if (x >= KEY_L[i] && x <= KEY_L[i] + KEY_W) {
                if (i == 3) openMusicApp();
                else transport(i);
                return;
            }
        }
    }

    private void launchButton(int idx) {
        if (idx >= 0 && idx < 6 && custom[idx] != null) {
            launchComponent(custom[idx]);
            return;
        }
        Intent i = null;
        switch (idx) {
            case 0:
                i = new Intent(Intent.ACTION_DIAL);
                break;
            case 1:
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING);
                break;
            case 2:
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
                break;
            case 3:
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY);
                break;
            case 4:
                i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                break;
            case 5:
                i = getContext().getPackageManager().getLaunchIntentForPackage("com.android.vending");
                break;
            default:
                break;
        }
        startIntent(i);
    }

    // ---------- look of the day ----------

    private void ensureLook(Calendar cal) {
        int dn = Texts.dayNumber(cal);
        if (look == null || lookDirty || dn != lookDay
                || (look.previewUntil > 0 && System.currentTimeMillis() > look.previewUntil)) {
            look = Look.compute(getContext(), pack, cal);
            lookDay = dn;
            lookDirty = false;
            pal = look.pal;
        }
        if (!look.sceneId.equals(sceneBmpId)) {
            sceneBmp = loadScene(look.sceneId);
            sceneBmpId = look.sceneId;
        }
    }

    private Bitmap loadScene(String id) {
        Bitmap b = null;
        try {
            File f = pack.sceneFile(id);
            if (f != null && f.isFile()) {
                b = BitmapFactory.decodeFile(f.getAbsolutePath());
            }
        } catch (Throwable ignored) { }
        if (b == null) {
            try {
                InputStream in = getContext().getAssets().open("scene_" + id + ".webp");
                b = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Throwable ignored) { }
        }
        if (b == null && !"lake".equals(id)) {
            try {
                InputStream in = getContext().getAssets().open("scene_lake.webp");
                b = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Throwable ignored) { }
        }
        return b;
    }

    // ---------- drawing helpers ----------

    private void text(Canvas c, String t, float x, float y, float size, int color,
                      Typeface tf, Paint.Align align, float spacingEm) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(tf);
        paint.setTextSize(size);
        paint.setColor(color);
        paint.setTextAlign(align);
        paint.setLetterSpacing(spacingEm);
        c.drawText(t, x, y, paint);
    }

    /** Draws text and shrinks it if it would be wider than maxW. Returns the size used. */
    private float fitText(Canvas c, String t, float x, float y, float size, float minSize, int color,
                          Typeface tf, Paint.Align align, float spacingEm, float maxW) {
        paint.setTypeface(tf);
        paint.setLetterSpacing(spacingEm);
        paint.setTextSize(size);
        float w = paint.measureText(t);
        if (w > maxW) size = Math.max(minSize, size * maxW / w);
        text(c, t, x, y, size, color, tf, align, spacingEm);
        return size;
    }

    private float blockSize(String[] lines, float size, float minSize, float spacingEm, Typeface tf, float maxW) {
        paint.setTypeface(tf);
        paint.setLetterSpacing(spacingEm);
        float s = size;
        for (String ln : lines) {
            paint.setTextSize(size);
            float w = paint.measureText(ln);
            if (w > maxW) s = Math.min(s, Math.max(minSize, size * maxW / w));
        }
        return s;
    }

    private void textBlock(Canvas c, String pooled, float x, float firstY, float lineGap, float size, float minSize,
                           float spacingEm, Typeface tf, Paint.Align align, float maxW) {
        String[] lines = pooled.split("\\|");
        float s = blockSize(lines, size, minSize, spacingEm, tf, maxW);
        for (int i = 0; i < lines.length; i++) {
            text(c, lines[i].trim(), x, firstY + i * lineGap, s, sky.fgAt(firstY + i * lineGap), tf, align, spacingEm);
        }
    }

    private void hline(Canvas c, float x0, float x1, float y, float w) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(w);
        paint.setColor(sky.fgAt(y));
        c.drawLine(x0, y, x1, y, paint);
    }

    private void vline(Canvas c, float x, float y0, float y1, float w) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(w);
        paint.setColor(sky.fgAt((y0 + y1) / 2f));
        c.drawLine(x, y0, x, y1, paint);
    }

    // ---------- main draw ----------

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        Calendar cal = Calendar.getInstance();
        ensureLook(cal);
        int availH = Math.max(1, h - bottomInset);
        scale = Math.min(w / DW, availH / DH);
        offX = (w - DW * scale) / 2f;
        offY = (availH - DH * scale) / 2f;

        int nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        sky = Sky.compute(pal, nowMin, sunriseMin, sunsetMin, cloudFrac());
        computeBody(nowMin);
        readNetwork();

        c.drawColor(sky.cols[3]);
        c.save();
        c.translate(offX, offY);
        c.scale(scale, scale);
        float vx0 = -offX / scale, vy0 = -offY / scale;
        float vx1 = (w - offX) / scale, vy1 = (h - offY) / scale;
        try {
            sky.drawBackdrop(c, paint, vx0, vy0, vx1, vy1, SC_L, SC_T, SC_R, SC_B, bodyX, LAKE_Y);
            drawSkyObjects(c, cal);
            drawSceneLayer(c);
            drawWeatherFx(c);
            drawFrames(c);
        } catch (Exception ignored) { }
        try { drawLive(c, cal); } catch (Exception ignored) { }
        c.restore();
    }

    private void computeBody(int nowMin) {
        int sr = sunriseMin, ss = sunsetMin;
        isDay = nowMin >= sr && nowMin <= ss;
        if (isDay) {
            float t = (nowMin - sr) / (float) Math.max(1, ss - sr);
            bodyX = 40f + t * 270f;
            float base = LAKE_Y + 24f, peak = 292f;
            bodyY = base - (float) Math.sin(Math.PI * t) * (base - peak);
            bodyR = 33f;
        } else {
            int len = 1440 - (ss - sr);
            int m2 = nowMin >= ss ? nowMin - ss : nowMin + 1440 - ss;
            float t = m2 / (float) Math.max(1, len);
            bodyX = 40f + t * 270f;
            float base = LAKE_Y + 22f, peak = 288f;
            bodyY = base - (float) Math.sin(Math.PI * t) * (base - peak);
            bodyR = 24f;
        }
        bodyUp = bodyY < LAKE_Y - 6f;
    }

    private void drawSkyObjects(Canvas c, Calendar cal) {
        float cc = cloudFrac();
        float nightK = sky.nightK;
        int accent = sky.accent();
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);

        if (nightK > 0.15f) {
            int a = (int) (255 * nightK * (1f - cc * 0.8f));
            paint.setColor(MOON);
            paint.setAlpha(Math.max(0, Math.min(255, a)));
            for (int i = 0; i < starX.length; i++) {
                if (!pal.bleed && (starX[i] < SC_L || starX[i] > SC_R || starY[i] < SC_T + 6f || starY[i] > SC_T + 126f)) continue;
                if (starY[i] > LAKE_Y - 14f) continue;
                c.drawCircle(starX[i], starY[i], starR[i], paint);
            }
            paint.setAlpha(255);
        }

        c.save();
        if (!pal.bleed) c.clipRect(SC_L, SC_T, SC_R, SC_B);

        if (isDay) {
            paint.setColor(accent);
            paint.setAlpha((int) (255 * (1f - 0.55f * cc)));
            c.drawCircle(bodyX, bodyY, bodyR, paint);
            paint.setAlpha(255);
        } else {
            double phase = Texts.moonPhase(System.currentTimeMillis());
            float f = (float) ((1.0 - Math.cos(2.0 * Math.PI * phase)) / 2.0);
            float dd = 2f * bodyR * f;
            paint.setColor(MOON);
            paint.setAlpha((int) (255 * (1f - 0.5f * cc)));
            c.drawCircle(bodyX, bodyY, bodyR, paint);
            paint.setAlpha(255);
            paint.setColor(sky.colorAt(bodyY));
            c.drawCircle(phase < 0.5 ? bodyX - dd : bodyX + dd, bodyY, bodyR + 0.5f, paint);
        }

        try {
            Decor.sky(c, paint, sky, look.fest == null ? null : look.fest.decor, SC_T, LAKE_Y, System.currentTimeMillis());
        } catch (Exception ignored) { }
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);

        int nCl = Math.round(cc * CLOUDS.length);
        int cloudCol = nightK > 0.5f ? Color.parseColor("#3A4150")
                : (cc > 0.6f ? Color.parseColor("#B3AD9F") : Color.parseColor("#F6F0E3"));
        for (int i = 0; i < nCl && i < CLOUDS.length; i++) {
            float cx = SC_L + CLOUDS[i][0] * 341f;
            float cy = SC_T + 14f + CLOUDS[i][1] * 150f;
            float s = CLOUDS[i][2];
            paint.setColor(cloudCol);
            paint.setAlpha(235);
            c.drawOval(new RectF(cx - 26f * s, cy - 8f * s, cx + 26f * s, cy + 8f * s), paint);
            c.drawOval(new RectF(cx - 29f * s, cy - 13f * s, cx + 1f * s, cy + 3f * s), paint);
            c.drawOval(new RectF(cx - 8f * s, cy - 17f * s, cx + 27f * s, cy + 2f * s), paint);
            paint.setAlpha(255);
        }
        c.restore();
    }

    private void drawSceneLayer(Canvas c) {
        float cc = cloudFrac();
        float nightK = sky.nightK;
        c.save();
        c.clipRect(SC_L, SC_T, SC_R, SC_B);
        if (sceneBmp != null) {
            float a = 1f - 0.55f * nightK - 0.2f * cc;
            float bl = 16f * nightK;
            float[] tint = pal.tint;
            ColorMatrix cm = new ColorMatrix(new float[]{
                    a * tint[0], 0, 0, 0, 0,
                    0, a * tint[1], 0, 0, 0,
                    0, 0, a * tint[2], 0, bl,
                    0, 0, 0, 1, 0});
            layerPaint.setColorFilter(new ColorMatrixColorFilter(cm));
            int save = c.saveLayer(SC_L, SC_T, SC_R, SC_B, null);
            c.drawBitmap(sceneBmp, null, new RectF(SC_L, SC_T, SC_R, SC_B), layerPaint);
            if (pal.bleed) {
                // let the water melt into the colour of the page below it
                Paint mask = new Paint();
                mask.setShader(new LinearGradient(0f, SC_B - 36f, 0f, SC_B, 0xFF000000, 0x1F000000, Shader.TileMode.CLAMP));
                mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                c.drawRect(SC_L, SC_B - 36f, SC_R, SC_B, mask);
            }
            c.restoreToCount(save);
        }

        if (bodyUp) {
            int col = isDay ? sky.accent() : MOON;
            for (int i = 0; i < 9; i++) {
                float w = (30f - i * 2.8f) * (1f - 0.4f * cc);
                float yy = LAKE_Y + 5f + i * 8f;
                paint.setShader(null);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(col);
                paint.setAlpha(150 - i * 8);
                c.drawRect(bodyX - w, yy, bodyX + w, yy + 1.8f, paint);
            }
            paint.setAlpha(255);
        }
        try {
            Decor.front(c, paint, sky, look.fest == null ? null : look.fest.decor, LAKE_Y, System.currentTimeMillis());
        } catch (Exception ignored) { }
        c.restore();
    }

    private void drawWeatherFx(Canvas c) {
        float nightK = sky.nightK;
        c.save();
        c.clipRect(SC_L, SC_T, SC_R, SC_B);
        paint.setShader(null);
        if (weatherOk && (wCode == 45 || wCode == 48)) {
            int fog = nightK > 0.5f ? Color.parseColor("#2A2F3B") : Color.parseColor("#E4DCC8");
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new LinearGradient(0, 320f, 0, LAKE_Y + 30f,
                    Color.argb(0, Color.red(fog), Color.green(fog), Color.blue(fog)),
                    Color.argb(190, Color.red(fog), Color.green(fog), Color.blue(fog)),
                    Shader.TileMode.CLAMP));
            c.drawRect(SC_L, 320f, SC_R, SC_B, paint);
            paint.setShader(null);
        }
        int rl = rainLevel();
        if (rl > 0) {
            int n = rl == 1 ? 40 : (rl == 2 ? 75 : 115);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(0.9f);
            paint.setColor(nightK > 0.5f ? MOON : Sky.INK);
            paint.setAlpha(120);
            for (int i = 0; i < n; i++) {
                float x0 = SC_L + rainX[i];
                float y0 = SC_T + rainY[i];
                c.drawLine(x0, y0, x0 - 2.5f, y0 + 9f, paint);
            }
            paint.setAlpha(255);
            paint.setStyle(Paint.Style.FILL);
        }
        if (snowing()) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(nightK > 0.5f ? MOON : Color.WHITE);
            for (int i = 0; i < 80; i++) {
                c.drawCircle(SC_L + rainX[i], SC_T + rainY[i], 1.5f, paint);
            }
        }
        c.restore();
    }

    private void drawFrames(Canvas c) {
        float L = 8f, R = 352f;
        hline(c, L, R, 34f, 1.5f);
        hline(c, L, R, 786f, 1.5f);
        vline(c, L, 34f, 786f, 1.5f);
        vline(c, R, 34f, 786f, 1.5f);
        hline(c, L, R, 240f, 1.5f);
        vline(c, 228f, 34f, 240f, 1.5f);
        hline(c, L, R, 478f, 1.5f);
        hline(c, L, R, 553f, 1.5f);
        vline(c, 136f, 553f, 611f, 1.5f);
        hline(c, L, R, 611f, 1.5f);
        hline(c, L, R, 641f, 2.2f);
        hline(c, L, R, 713f, 2.2f);
        hline(c, L, R, 771f, 2.2f);
        vline(c, L + 344f / 3f, 641f, 771f, 2.2f);
        vline(c, L + 688f / 3f, 641f, 771f, 2.2f);
    }

    // ---------- the live content ----------

    private void drawLive(Canvas c, Calendar cal) {
        boolean h24 = DateFormat.is24HourFormat(getContext());
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int hh = h24 ? hour : ((hour % 12 == 0) ? 12 : hour % 12);
        int mm = cal.get(Calendar.MINUTE);
        int accent = sky.accent();

        text(c, String.format(Locale.US, "%02d", hh), 14, 108, 96, sky.fgAt(70f), bebas, Paint.Align.LEFT, 0f);
        text(c, String.format(Locale.US, "%02d", mm), 14, 182, 96, accent, bebas, Paint.Align.LEFT, 0f);

        int dateInk = sky.fgAt(88f);
        String mon = cal.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
        text(c, mon, 112, 62, 24, dateInk, bebas, Paint.Align.LEFT, 0.04f);
        text(c, String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), 112, 88, 24, dateInk, bebas, Paint.Align.LEFT, 0.04f);
        text(c, String.valueOf(cal.get(Calendar.YEAR)), 112, 114, 24, dateInk, bebas, Paint.Align.LEFT, 0.04f);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(dateInk);
        paint.setStrokeWidth(1.5f);
        c.drawLine(112, 126, 160, 126, paint);
        if (!h24) {
            text(c, hour < 12 ? "AM" : "PM", 112, 144, 10, accent, roboto, Paint.Align.LEFT, 0.25f);
        }

        String day = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
        float size = 62f;
        paint.setTypeface(bebas);
        paint.setTextSize(size);
        paint.setLetterSpacing(0.02f);
        float wdt = paint.measureText(day);
        if (wdt > 182f) size = size * 182f / wdt;
        float cap = size * 0.70f;
        c.save();
        c.translate(266f + cap / 2f, 228f);
        c.rotate(-90f);
        text(c, day, 0, 0, size, sky.fgAt(130f), bebas, Paint.Align.LEFT, 0.02f);
        c.restore();

        // slogans beside the day name
        textBlock(c, look.slogan1, 300f, 52f, 8.6f, 6f, 4.2f, 0.23f, roboto, Paint.Align.LEFT, 50f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accent);
        c.drawRect(300f, 100f, 322f, 102f, paint);
        textBlock(c, look.slogan2, 300f, 118f, 8.6f, 6f, 4.2f, 0.23f, roboto, Paint.Align.LEFT, 50f);
        paint.setColor(accent);
        c.drawRect(300f, 200f, 322f, 202f, paint);

        fitText(c, look.tagline, 18f, 222f, 6.5f, 4.5f, sky.fgAt(222f), roboto, Paint.Align.LEFT, 0.4f, 205f);

        // scene corner messages and weather
        textBlock(c, look.cornerL, 18f, 257f, 9.4f, 6.5f, 4.5f, 0.46f, roboto, Paint.Align.LEFT, 100f);
        textBlock(c, look.cornerR, 344f, 257f, 9.4f, 6.5f, 4.5f, 0.46f, roboto, Paint.Align.RIGHT, 120f);
        if (weatherOk) {
            String wl = weatherLabel(!isDay) + " • " + Math.round(wTemp) + "°C";
            text(c, wl, 344f, 470f, 7f, sky.fgAt(470f), roboto, Paint.Align.RIGHT, 0.2f);
        }

        // greeting (a festival replaces it)
        String greet;
        if (look.fest != null && look.fest.greet.length() > 0) greet = look.fest.greet;
        else greet = hour < 12 ? "GOOD MORNING" : (hour < 17 ? "GOOD AFTERNOON" : (hour < 21 ? "GOOD EVENING" : "GOOD NIGHT"));
        fitText(c, greet, 18, 524, 40f, 18f, sky.fgAt(515f), bebas, Paint.Align.LEFT, 0.03f, 215f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accent);
        c.drawRect(18, 534, 54, 536.5f, paint);

        try { drawMusicButton(c); } catch (Exception ignored) { }

        int docInk = sky.fgAt(580f);
        text(c, String.valueOf(cal.get(Calendar.DAY_OF_YEAR)), 16, 590, 42, docInk, bebas, Paint.Align.LEFT, 0f);
        text(c, "DAY OF THE YEAR", 16, 603, 5.6f, docInk, roboto, Paint.Align.LEFT, 0.25f);

        // note about this day, next to the day number
        String[] noteLines = look.dayNote.split("\\|");
        float ns = blockSize(noteLines, 6f, 4.2f, 0.27f, roboto, 34f);
        for (int i = 0; i < noteLines.length && i < 4; i++) {
            text(c, noteLines[i].trim(), 96f, 563.5f + i * 8.2f, ns, docInk, roboto, Paint.Align.LEFT, 0.27f);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accent);
        c.drawRect(98f, 597f, 118f, 599f, paint);

        try { drawBattery(c, cal); } catch (Exception ignored) { }
        try { drawSignal(c); } catch (Exception ignored) { }
        try { drawButtons(c); } catch (Exception ignored) { }
        try { if (panelOpen) drawDeck(c); } catch (Exception ignored) { }

        int foot = sky.fgAt(780f);
        text(c, "SWIPE UP • ALL APPS", 180f, 782f, 7f, foot, roboto, Paint.Align.CENTER, 0.3f);
        text(c, "HOLD SCENE • STYLE", 14f, 781f, 5.2f, foot, roboto, Paint.Align.LEFT, 0.2f);
        text(c, "L4.1", 346f, 781f, 5.5f, foot, roboto, Paint.Align.RIGHT, 0.2f);
    }

    private void drawCassette(Canvas c, float cx, float cy, float s, boolean spin, int ink, int accent) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(ink);
        paint.setStrokeWidth(1.7f * Math.max(0.8f, s));
        c.drawRoundRect(new RectF(cx - 30f * s, cy - 20f * s, cx + 30f * s, cy + 20f * s), 4f * s, 4f * s, paint);
        paint.setStrokeWidth(1.2f * Math.max(0.8f, s));
        c.drawRoundRect(new RectF(cx - 22f * s, cy - 14f * s, cx + 22f * s, cy + 3f * s), 3f * s, 3f * s, paint);
        float[] rx = {cx - 10f * s, cx + 10f * s};
        float ry = cy - 5.5f * s, rr = 5.2f * s;
        double base = spin ? ((System.currentTimeMillis() / 1000L) % 6L) * 60.0 : 0.0;
        for (int i = 0; i < 2; i++) {
            c.drawCircle(rx[i], ry, rr, paint);
            for (int k = 0; k < 3; k++) {
                double a = Math.toRadians(base + k * 120.0);
                c.drawLine(rx[i], ry, rx[i] + (float) Math.cos(a) * rr, ry + (float) Math.sin(a) * rr, paint);
            }
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accent);
        c.drawRect(cx - 20f * s, cy + 9f * s, cx + 20f * s, cy + 12f * s, paint);
        paint.setColor(ink);
        c.drawCircle(cx - 25f * s, cy - 15f * s, 1.1f * s, paint);
        c.drawCircle(cx + 25f * s, cy - 15f * s, 1.1f * s, paint);
        c.drawCircle(cx - 25f * s, cy + 15f * s, 1.1f * s, paint);
        c.drawCircle(cx + 25f * s, cy + 15f * s, 1.1f * s, paint);
    }

    private void drawMusicButton(Canvas c) {
        if (panelOpen) return;
        boolean playing = musicActive();
        int ink = sky.fgAt(510f);
        drawCassette(c, 292f, 506f, 0.95f, playing, ink, sky.accent());
        text(c, "MUSIC", 292f, 546f, 13f, ink, bebas, Paint.Align.CENTER, 0.14f);
        if (playing) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(sky.accent());
            c.drawCircle(326f, 489f, 3f, paint);
        }
    }

    private void drawButtons(Canvas c) {
        float cw = 344f / 3f;
        float maxW = cw - 12f;
        int accent = sky.accent();
        for (int row = 0; row < 2; row++) {
            int ink = sky.fgAt(row == 0 ? 690f : 750f);
            for (int col = 0; col < 3; col++) {
                int idx = row * 3 + col;
                float cx = 8f + cw * (col + 0.5f);
                float baseline = row == 0 ? 678f : 744f;
                String word;
                String cap;
                if (custom[idx] != null && customLabel[idx] != null && customLabel[idx].length() > 0) {
                    word = customLabel[idx].toUpperCase(Locale.getDefault());
                    cap = "YOUR CHOICE";
                } else {
                    word = BUTTON_WORDS[idx];
                    cap = DEFAULT_CAPS[idx];
                }
                float size = 22f;
                paint.setTypeface(bebas);
                paint.setLetterSpacing(0.06f);
                paint.setTextSize(size);
                float w = paint.measureText(word);
                if (w > maxW) size = Math.max(11f, size * maxW / w);
                paint.setTextSize(size);
                CharSequence shown = word;
                if (paint.measureText(word) > maxW) {
                    TextPaint tp = new TextPaint(paint);
                    shown = TextUtils.ellipsize(word, tp, maxW, TextUtils.TruncateAt.END);
                }
                text(c, shown.toString(), cx, baseline, size, ink, bebas, Paint.Align.CENTER, 0.06f);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(accent);
                c.drawRect(cx - 9, baseline + 6, cx + 9, baseline + 8, paint);
                text(c, cap, cx, row == 0 ? 707f : 766f, 6.5f, ink, roboto, Paint.Align.CENTER, 0.31f);
            }
        }
    }

    private void drawSignal(Canvas c) {
        int ink = sky.fgAt(626f);
        int accent = sky.accent();
        int skip = noNet ? 9 : 0;
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        for (int row = 0; row < 2; row++) {
            float frac = noNet ? 0f : (row == 0 ? wifiFrac : mobFrac);
            int filled = Math.round(frac * 40f);
            for (int i = skip; i < 40; i++) {
                paint.setColor(ink);
                paint.setAlpha(i < filled ? 255 : 38);
                float x = 16f + i * 6.2f;
                float y = 618f + row * 8f;
                c.drawRect(x, y, x + 5f, y + 6f, paint);
            }
        }
        paint.setAlpha(255);
        if (noNet) {
            // a tower made of little squares, crossed out
            float cell = 3f, pitch = 3.6f, x0 = 16f, y0 = 614f;
            paint.setColor(ink);
            for (int r = 0; r < TOWER.length; r++) {
                for (int k = 0; k < TOWER[r].length(); k++) {
                    if (TOWER[r].charAt(k) == '#') {
                        c.drawRect(x0 + k * pitch, y0 + r * pitch, x0 + k * pitch + cell, y0 + r * pitch + cell, paint);
                    }
                }
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.9f);
            paint.setColor(accent);
            c.drawLine(x0 - 2f, y0 - 1f, x0 + 9 * pitch + 1f, y0 + 7 * pitch + 1f, paint);
            paint.setStyle(Paint.Style.FILL);
            text(c, "NO TOWER", 278f, 624f, 5.8f, ink, roboto, Paint.Align.LEFT, 0.16f);
            text(c, "NO CONNECTION", 278f, 632f, 5.8f, ink, roboto, Paint.Align.LEFT, 0.16f);
        } else {
            text(c, wifiLabel, 278f, 624f, 5.8f, ink, roboto, Paint.Align.LEFT, 0.16f);
            text(c, mobLabel, 278f, 632f, 5.8f, ink, roboto, Paint.Align.LEFT, 0.16f);
        }
    }

    private String batteryMessage(Calendar cal, boolean charging) {
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        String key = Texts.dayNumber(cal) + "|" + (batteryPct / 5) + "|" + charging + "|" + (hour / 4) + "|" + look.key;
        if (!key.equals(batKey)) {
            batKey = key;
            batText = Texts.battery(batteryPct, charging, pack.quotes("batCharging"), pack.quotes("batFull"),
                    pack.quotes("batHigh"), pack.quotes("batMid"), pack.quotes("batLow"), pack.quotes("batCrit"),
                    Texts.dayNumber(cal), hour);
        }
        return batText;
    }

    private void drawBattery(Canvas c, Calendar cal) {
        float x = 146, y = 562, w = 52, h = 22;
        boolean charging = pluggedType != 0;
        int ink = sky.fgAt(575f);
        int accent = sky.accent();

        paint.setShader(null);
        paint.setColor(ink);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.8f);
        c.drawRoundRect(x, y, x + w, y + h, 3, 3, paint);
        paint.setStyle(Paint.Style.FILL);
        c.drawRect(x + w, y + 6, x + w + 4, y + h - 6, paint);

        int segs = Math.max(batteryPct > 0 ? 1 : 0, Math.round(batteryPct / 20f));
        paint.setColor(accent);
        float sw = (w - 8) / 5f;
        for (int i = 0; i < segs && i < 5; i++) {
            float sx = x + 3 + i * sw;
            c.drawRect(sx, y + 3, sx + sw - 2, y + h - 3, paint);
        }

        if (charging) {
            float cx = x + w / 2f, top = y + 2f;
            Path bolt = new Path();
            bolt.moveTo(cx + 3f, top);
            bolt.lineTo(cx - 6f, top + 11f);
            bolt.lineTo(cx - 0.5f, top + 11f);
            bolt.lineTo(cx - 3f, top + 18f);
            bolt.lineTo(cx + 6f, top + 7f);
            bolt.lineTo(cx + 0.5f, top + 7f);
            bolt.close();
            paint.setColor(sky.colorAt(575f));
            paint.setStyle(Paint.Style.FILL_AND_STROKE);
            paint.setStrokeWidth(1.6f);
            c.drawPath(bolt, paint);
            paint.setColor(ink);
            paint.setStyle(Paint.Style.FILL);
            c.drawPath(bolt, paint);
        }

        text(c, batteryPct + "%", 342, 592, 44, ink, bebas, Paint.Align.RIGHT, 0f);

        String status;
        if (charging) {
            String src = pluggedType == BatteryManager.BATTERY_PLUGGED_WIRELESS ? "WIRELESS"
                    : (pluggedType == BatteryManager.BATTERY_PLUGGED_USB ? "USB" : "CABLE");
            status = "CHARGING • " + src;
        } else {
            status = "ON BATTERY";
        }
        if (tempC >= 0) status += " • " + Math.round(tempC) + "°C";
        text(c, status, 146, 593, 6.2f, charging ? accent : ink, roboto, Paint.Align.LEFT, 0.16f);

        // a short message that matches the charge
        String msg = "“" + batteryMessage(cal, charging) + "”";
        paint.setTypeface(roboto);
        paint.setLetterSpacing(0.04f);
        float qs = 6f;
        paint.setTextSize(qs);
        float qw = paint.measureText(msg);
        if (qw > 204f) qs = Math.max(4.2f, qs * 204f / qw);
        paint.setTextSkewX(-0.2f);
        text(c, msg, 146f, 604f, qs, ink, roboto, Paint.Align.LEFT, 0.04f);
        paint.setTextSkewX(0f);
    }

    // ---------- the cassette deck ----------

    private void keyFace(Canvas c, int i, boolean pressed, int face, int ink) {
        float l = KEY_L[i], t = KEY_T + (pressed ? 2f : 0f), r = l + KEY_W, b = KEY_B + (pressed ? 1f : 0f);
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(pressed ? 40 : 90, 0, 0, 0));
        c.drawRoundRect(new RectF(l + 1.5f, t + 3.5f, r + 1.5f, b + 3.5f), 5f, 5f, paint);
        paint.setColor(face);
        c.drawRoundRect(new RectF(l, t, r, b), 5f, 5f, paint);
        paint.setColor(Color.argb(pressed ? 0 : 70, 255, 255, 255));
        c.drawRoundRect(new RectF(l + 3f, t + 2f, r - 3f, t + 5f), 2f, 2f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f);
        paint.setColor(ink);
        c.drawRoundRect(new RectF(l, t, r, b), 5f, 5f, paint);
    }

    private void tri(Canvas c, float x0, float y0, float x1, float y1, float x2, float y2, int col) {
        Path p = new Path();
        p.moveTo(x0, y0);
        p.lineTo(x1, y1);
        p.lineTo(x2, y2);
        p.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(col);
        c.drawPath(p, paint);
    }

    private void drawDeck(Canvas c) {
        boolean playing = musicActive();
        boolean dark = sky.darkAt(470f);
        int ink = sky.fgAt(470f);
        int accent = sky.accent();
        int body = dark ? Color.parseColor("#2A2C36") : Color.parseColor("#E6DCC4");
        int panel = dark ? Color.parseColor("#1D1F27") : Color.parseColor("#D6CBB1");
        int keyFace = dark ? Color.parseColor("#454957") : Color.parseColor("#2A2A28");
        int icon = Sky.LIGHT;

        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(110, 0, 0, 0));
        c.drawRoundRect(new RectF(DECK_L + 2f, DECK_T + 4f, DECK_R + 2f, DECK_B + 4f), 11f, 11f, paint);
        paint.setColor(body);
        c.drawRoundRect(new RectF(DECK_L, DECK_T, DECK_R, DECK_B), 11f, 11f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        paint.setColor(ink);
        c.drawRoundRect(new RectF(DECK_L, DECK_T, DECK_R, DECK_B), 11f, 11f, paint);

        // cassette window
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#17181C"));
        c.drawRoundRect(new RectF(24f, 408f, 190f, 480f), 7f, 7f, paint);
        paint.setColor(Color.parseColor("#CFC3A3"));
        c.drawRoundRect(new RectF(29f, 413f, 185f, 475f), 5f, 5f, paint);
        paint.setColor(Color.parseColor("#EFE7D3"));
        c.drawRect(40f, 418f, 174f, 440f, paint);
        paint.setColor(accent);
        c.drawRect(46f, 429f, 168f, 431f, paint);
        paint.setColor(Color.parseColor("#2B2A28"));
        c.drawRoundRect(new RectF(58f, 445f, 156f, 470f), 12f, 12f, paint);

        long now = System.currentTimeMillis();
        float frac = ((now / 60000L) % 12L) / 12f;
        float[] hx = {79f, 135f};
        float hy = 457.5f;
        float[] tape = {11.5f - 3f * frac, 8.5f + 3f * frac};
        double spin = playing ? (now % 1200L) / 1200.0 * 360.0 : 20.0;
        for (int i = 0; i < 2; i++) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.parseColor("#5A4632"));
            c.drawCircle(hx[i], hy, tape[i], paint);
            paint.setColor(Color.parseColor("#E8E2D0"));
            c.drawCircle(hx[i], hy, 7f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.5f);
            paint.setColor(Color.parseColor("#2B2A28"));
            for (int k = 0; k < 6; k++) {
                double a = Math.toRadians(spin + k * 60.0);
                c.drawLine(hx[i] + (float) Math.cos(a) * 2.2f, hy + (float) Math.sin(a) * 2.2f,
                        hx[i] + (float) Math.cos(a) * 6.5f, hy + (float) Math.sin(a) * 6.5f, paint);
            }
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(Color.parseColor("#5A4632"));
        c.drawLine(hx[0], hy + tape[0], hx[1], hy + tape[1], paint);

        // speaker grille and lamp
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panel);
        c.drawRoundRect(new RectF(200f, 408f, 340f, 480f), 7f, 7f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f);
        paint.setColor(ink);
        c.drawRoundRect(new RectF(200f, 408f, 340f, 480f), 7f, 7f, paint);
        paint.setStrokeWidth(1.5f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setAlpha(150);
        for (int i = 0; i < 6; i++) {
            float yy = 426f + i * 9f;
            c.drawLine(212f, yy, 328f, yy, paint);
        }
        paint.setAlpha(255);
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(playing ? accent : Color.argb(110, Color.red(accent), Color.green(accent), Color.blue(accent)));
        c.drawCircle(214f, 416f, 3.2f, paint);
        if (playing) {
            paint.setColor(Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)));
            c.drawCircle(214f, 416f, 6f, paint);
        }

        // keys
        keyFace(c, 0, false, keyFace, ink);
        keyFace(c, 1, playing, accent, ink);
        keyFace(c, 2, false, keyFace, ink);
        keyFace(c, 3, false, keyFace, ink);
        float cy = (KEY_T + KEY_B) / 2f;
        float c0 = KEY_L[0] + KEY_W / 2f, c1 = KEY_L[1] + KEY_W / 2f + (playing ? 0f : 0f);
        float c2 = KEY_L[2] + KEY_W / 2f, c3 = KEY_L[3] + KEY_W / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(icon);
        // back
        c.drawRect(c0 - 11f, cy - 8f, c0 - 8.5f, cy + 8f, paint);
        tri(c, c0 + 11f, cy - 8f, c0 - 6f, cy, c0 + 11f, cy + 8f, icon);
        // play / pause
        float py = cy + (playing ? 1f : 0f);
        if (playing) {
            c.drawRect(c1 - 7f, py - 8f, c1 - 2.5f, py + 8f, paint);
            c.drawRect(c1 + 2.5f, py - 8f, c1 + 7f, py + 8f, paint);
        } else {
            tri(c, c1 - 6f, py - 9f, c1 - 6f, py + 9f, c1 + 9f, py, icon);
        }
        // next
        c.drawRect(c2 + 8.5f, cy - 8f, c2 + 11f, cy + 8f, paint);
        tri(c, c2 - 11f, cy - 8f, c2 + 6f, cy, c2 - 11f, cy + 8f, icon);
        // eject (opens the music app)
        tri(c, c3 - 10f, cy + 1f, c3 + 10f, cy + 1f, c3, cy - 9f, icon);
        c.drawRect(c3 - 10f, cy + 4.5f, c3 + 10f, cy + 8.5f, paint);
    }
}
