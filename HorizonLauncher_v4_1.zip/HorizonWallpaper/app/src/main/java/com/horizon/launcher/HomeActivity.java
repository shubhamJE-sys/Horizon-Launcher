package com.horizon.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.pm.LauncherApps;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.util.DisplayMetrics;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import java.util.Calendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends Activity implements PosterView.Host {

    private static final int REQ_PACK = 41;

    // colours follow the sky of the home screen; these are the defaults until it has drawn once
    private int INK = Color.parseColor("#1B1B1A");
    private int RED = Color.parseColor("#C8382C");
    private int CREAM = Color.parseColor("#ECE3D0");

    private static final String[] TARGET_NAMES = {
            "PHONE BUTTON", "MESSAGES BUTTON", "BROWSER BUTTON", "GALLERY BUTTON",
            "CAMERA BUTTON", "PLAY STORE BUTTON", "MUSIC OPEN BUTTON", "CLOCK TAP", "CALENDAR TAP",
            "GREETING TAP (NEWS)"};

    private static class AppEntry {
        String label;
        ComponentName component; // null = "reset to default" entry
    }

    private PosterView poster;
    private FrameLayout root;
    private LinearLayout drawer;
    private GridView grid;
    private TextView titleView, countView;
    private Typeface bebas, roboto;
    private final List<AppEntry> apps = new ArrayList<AppEntry>();
    private final List<AppEntry> shown = new ArrayList<AppEntry>();
    private BaseAdapter adapter;
    private int pickTarget = -1;
    private TextView closeView;
    private View ruleView;
    private FrameLayout gridFrameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(CREAM));
        try {
            bebas = Typeface.createFromAsset(getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(getAssets(), "Roboto-Regular.ttf");
        } catch (Exception e) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(CREAM);
        poster = new PosterView(this, this);
        root.addView(poster, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildDrawer();
        root.addView(drawer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawer.setVisibility(View.GONE);
        setContentView(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int bottom = insets.getSystemWindowInsetBottom();
                poster.setBottomInset(bottom);
                drawer.setPadding(dp(18), dp(52), dp(18), bottom + dp(8));
                return insets;
            }
        });
        root.requestApplyInsets();

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, new OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            // A launcher never exits: back closes the app grid or the music panel.
                            if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
                            else poster.closePanel();
                        }
                    });
        }
        hideBars();
    }

    /**
     * Keeps the lock screen and the plain wallpaper behind the launcher in the same colours as the home screen.
     * Runs only when the day, scheme, scene, festival or part of the day (day / twilight / night) changes.
     */
    private void updateWallpapers() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        final Look look = poster.look();
        final int sr = poster.sunriseMin(), ss = poster.sunsetMin();
        final int nowMin = LockArt.minuteOfDay();
        final int bucket = LockArt.bucket(nowMin, sr, ss);
        final boolean lockOn = sp.getBoolean("lock_auto", true);
        final String key = LockArt.key(look, bucket) + "|" + lockOn;
        if (key.equals(sp.getString("wp_key", ""))) return;
        sp.edit().putString("wp_key", key).apply();
        final float cloud = poster.cloudAmount();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    WallpaperManager wm = WallpaperManager.getInstance(HomeActivity.this);
                    Sky sky = Sky.compute(look.pal, nowMin, sr, ss, cloud);
                    int sw, sh;
                    if (Build.VERSION.SDK_INT >= 30) {
                        android.graphics.Rect b = getWindowManager().getMaximumWindowMetrics().getBounds();
                        sw = b.width();
                        sh = b.height();
                    } else {
                        DisplayMetrics dm = getResources().getDisplayMetrics();
                        sw = dm.widthPixels;
                        sh = dm.heightPixels;
                    }
                    int w = Math.min(sw, 1440), h = Math.round(w * (float) sh / sw);
                    Bitmap plain = LockArt.plain(sky, Math.max(2, w / 2), Math.max(2, h / 2));
                    wm.setBitmap(plain, new android.graphics.Rect(0, 0, plain.getWidth(), plain.getHeight()),
                            true, WallpaperManager.FLAG_SYSTEM);
                    if (lockOn) {
                        Bitmap lock = LockArt.lock(HomeActivity.this, look, sky, nowMin, sr, ss, cloud, w, h);
                        // show the whole picture, not a zoomed crop of it
                        wm.setBitmap(lock, new android.graphics.Rect(0, 0, lock.getWidth(), lock.getHeight()),
                                true, WallpaperManager.FLAG_LOCK);
                    }
                } catch (Throwable ignored) { }
            }
        }).start();
    }

    private void refreshTheme() {
        CREAM = poster.skyMid();
        INK = poster.skyInk();
        RED = poster.skyAccent();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onResume() {
        super.onResume();
        poster.start();
        hideBars();
        refreshTheme();
        getWindow().setBackgroundDrawable(new ColorDrawable(CREAM));
        root.post(new Runnable() {
            @Override
            public void run() {
                updateWallpapers();
            }
        });
    }

    @Override
    protected void onPause() {
        poster.stop();
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Pressing Home again returns to the poster.
        if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
        poster.closePanel();
    }

    // ---------- app grid ----------

    private View makeCell() {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER);
        cell.setBackgroundColor(CREAM);
        cell.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(88)));

        TextView tv = new TextView(this);
        tv.setTypeface(bebas);
        tv.setTextSize(21f);
        tv.setTextColor(INK);
        tv.setLetterSpacing(0.06f);
        tv.setGravity(Gravity.CENTER);
        tv.setMaxLines(2);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setPadding(dp(6), 0, dp(6), 0);
        cell.addView(tv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View bar = new View(this);
        bar.setBackgroundColor(RED);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(18), dp(2));
        bp.topMargin = dp(7);
        cell.addView(bar, bp);
        return cell;
    }

    private void buildDrawer() {
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(CREAM);
        drawer.setClickable(true);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.BOTTOM);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleView = new TextView(this);
        titleView.setTypeface(bebas);
        titleView.setTextSize(52f);
        titleView.setTextColor(INK);
        titleView.setLetterSpacing(0.03f);
        titleView.setIncludeFontPadding(false);
        titleBox.addView(titleView);
        countView = new TextView(this);
        countView.setTypeface(roboto);
        countView.setTextSize(10f);
        countView.setTextColor(RED);
        countView.setLetterSpacing(0.3f);
        titleBox.addView(countView);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("CLOSE");
        close.setTypeface(bebas);
        close.setTextSize(24f);
        close.setTextColor(RED);
        close.setLetterSpacing(0.1f);
        close.setPadding(dp(16), dp(12), 0, dp(6));
        closeView = close;
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });
        header.addView(close, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        drawer.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View rule = new View(this);
        rule.setBackgroundColor(INK);
        ruleView = rule;
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(2));
        rp.topMargin = dp(10);
        rp.bottomMargin = dp(12);
        drawer.addView(rule, rp);

        // grid lines come from the dark background showing through 1dp gaps, like the poster's button grid
        FrameLayout gridFrame = new FrameLayout(this);
        gridFrame.setBackgroundColor(INK);
        gridFrameView = gridFrame;
        gridFrame.setPadding(dp(1), dp(1), dp(1), dp(1));

        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dp(1));
        grid.setVerticalSpacing(dp(1));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setBackgroundColor(INK);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setVerticalScrollBarEnabled(false);
        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return shown.size();
            }

            @Override
            public Object getItem(int position) {
                return shown.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View cell = convertView != null ? convertView : makeCell();
                TextView tv = (TextView) ((LinearLayout) cell).getChildAt(0);
                tv.setText(shown.get(position).label.toUpperCase(Locale.getDefault()));
                tv.setTextColor(INK);
                cell.setBackgroundColor(CREAM);
                ((LinearLayout) cell).getChildAt(1).setBackgroundColor(RED);
                return cell;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                onEntryClicked(shown.get(position));
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AppEntry a = shown.get(position);
                if (pickTarget >= 0 || a.component == null) return false;
                showAppMenu(a);
                return true;
            }
        });
        gridFrame.addView(grid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawer.addView(gridFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        for (ResolveInfo r : found) {
            if (r.activityInfo == null) continue;
            if (getPackageName().equals(r.activityInfo.packageName)) continue;
            AppEntry a = new AppEntry();
            a.label = String.valueOf(r.loadLabel(pm));
            a.component = new ComponentName(r.activityInfo.packageName, r.activityInfo.name);
            apps.add(a);
        }
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry x, AppEntry y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });
        shown.clear();
        if (pickTarget >= 0) {
            AppEntry reset = new AppEntry();
            reset.label = "DEFAULT";
            reset.component = null;
            shown.add(reset);
        }
        shown.addAll(apps);
        if (pickTarget >= 0) {
            titleView.setText("CHOOSE APP");
            countView.setText("FOR: " + TARGET_NAMES[pickTarget]);
        } else {
            titleView.setText("ALL APPS");
            countView.setText(apps.size() + " APPS");
        }
        adapter.notifyDataSetChanged();
    }

    private void onEntryClicked(AppEntry a) {
        if (pickTarget >= 0) {
            poster.setCustom(pickTarget, a.component, a.component == null ? null : a.label);
            closeDrawer();
            return;
        }
        if (a.component == null) return;
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(a.component);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
        } catch (Exception ignored) { }
        closeDrawer();
    }

    // ---------- long-press menu (app shortcuts + app info) ----------

    private List<ShortcutInfo> loadShortcuts(String pkg) {
        List<ShortcutInfo> out = new ArrayList<ShortcutInfo>();
        try {
            LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
            if (la != null && la.hasShortcutHostPermission()) {
                LauncherApps.ShortcutQuery q = new LauncherApps.ShortcutQuery();
                q.setPackage(pkg);
                q.setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC
                        | LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST
                        | LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED);
                List<ShortcutInfo> l = la.getShortcuts(q, Process.myUserHandle());
                if (l != null) {
                    for (ShortcutInfo si : l) {
                        if (si.isEnabled() && si.getShortLabel() != null && out.size() < 6) out.add(si);
                    }
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    private boolean hasShortcutAccess() {
        try {
            LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
            return la != null && la.hasShortcutHostPermission();
        } catch (Exception e) {
            return false;
        }
    }

    private void addMenuRow(LinearLayout box, String label, final Dialog d, final Runnable action) {
        View line = new View(this);
        line.setBackgroundColor(Color.parseColor("#33000000"));
        box.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        TextView row = new TextView(this);
        row.setText(label.toUpperCase(Locale.getDefault()));
        row.setTypeface(bebas);
        row.setTextSize(22f);
        row.setTextColor(INK);
        row.setLetterSpacing(0.06f);
        row.setSingleLine(true);
        row.setEllipsize(TextUtils.TruncateAt.END);
        row.setPadding(0, dp(12), 0, dp(12));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                try {
                    action.run();
                } catch (Exception ignored) { }
            }
        });
        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void showAppMenu(final AppEntry a) {
        refreshTheme();
        final String pkg = a.component.getPackageName();
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CREAM);
        bg.setStroke(dp(2), INK);
        box.setBackground(bg);
        box.setPadding(dp(22), dp(16), dp(22), dp(12));

        TextView head = new TextView(this);
        head.setText(a.label.toUpperCase(Locale.getDefault()));
        head.setTypeface(bebas);
        head.setTextSize(32f);
        head.setTextColor(INK);
        head.setLetterSpacing(0.04f);
        head.setSingleLine(true);
        head.setEllipsize(TextUtils.TruncateAt.END);
        box.addView(head);
        View bar = new View(this);
        bar.setBackgroundColor(RED);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(30), dp(2));
        bp.topMargin = dp(4);
        bp.bottomMargin = dp(6);
        box.addView(bar, bp);

        addMenuRow(box, "OPEN", d, new Runnable() {
            @Override
            public void run() {
                onEntryClicked(a);
            }
        });

        final LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
        for (final ShortcutInfo si : loadShortcuts(pkg)) {
            addMenuRow(box, String.valueOf(si.getShortLabel()), d, new Runnable() {
                @Override
                public void run() {
                    closeDrawer();
                    la.startShortcut(si, null, null);
                }
            });
        }

        addMenuRow(box, "APP INFO / UNINSTALL", d, new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        });

        if (!hasShortcutAccess()) {
            TextView note = new TextView(this);
            note.setText("TO SEE APP SHORTCUTS, SET HORIZON LAUNCHER AS YOUR DEFAULT HOME APP");
            note.setTypeface(roboto);
            note.setTextSize(8f);
            note.setTextColor(RED);
            note.setLetterSpacing(0.12f);
            note.setPadding(0, dp(8), 0, dp(2));
            box.addView(note);
        }

        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.84f),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    // ---------- style menu (hold the scene for two seconds) ----------

    private Dialog newMenu(String title, String sub, LinearLayout[] boxOut) {
        refreshTheme();
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CREAM);
        bg.setStroke(dp(2), INK);
        outer.setBackground(bg);
        outer.setPadding(dp(22), dp(16), dp(22), dp(12));

        TextView head = new TextView(this);
        head.setText(title);
        head.setTypeface(bebas);
        head.setTextSize(32f);
        head.setTextColor(INK);
        head.setLetterSpacing(0.04f);
        head.setSingleLine(true);
        outer.addView(head);
        View bar = new View(this);
        bar.setBackgroundColor(RED);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(30), dp(2));
        bp.topMargin = dp(4);
        bp.bottomMargin = dp(4);
        outer.addView(bar, bp);
        if (sub != null) {
            TextView st = new TextView(this);
            st.setText(sub);
            st.setTypeface(roboto);
            st.setTextSize(8f);
            st.setTextColor(RED);
            st.setLetterSpacing(0.12f);
            st.setPadding(0, 0, 0, dp(4));
            outer.addView(st);
        }
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        outer.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        boxOut[0] = box;

        d.setContentView(outer);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.86f),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        return d;
    }

    private void addNote(LinearLayout box, String text) {
        TextView note = new TextView(this);
        note.setText(text);
        note.setTypeface(roboto);
        note.setTextSize(8f);
        note.setTextColor(RED);
        note.setLetterSpacing(0.12f);
        note.setPadding(0, dp(8), 0, dp(2));
        box.addView(note);
    }

    private static String shortName(Palette p) {
        int i = p.name.indexOf('•');
        return (i > 0 ? p.name.substring(0, i) : p.name).trim();
    }

    /** Applies the change, then opens the style menu again so several things can be changed in a row. */
    private void styleChanged() {
        poster.refreshLook();
        poster.post(new Runnable() {
            @Override
            public void run() {
                updateWallpapers();
                openStyleMenu();
            }
        });
    }

    @Override
    public void openStyleMenu() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        final Look look = poster.look();
        final ContentPack pk = poster.pack();
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("STYLE", null, hb);
        LinearLayout box = hb[0];

        Palette cur = Palette.byId(sp.getString("pal", "HORIZON"));
        addMenuRow(box, "COLOUR SCHEME: " + shortName(cur), d, new Runnable() {
            @Override
            public void run() {
                chooseScheme();
            }
        });
        String sc = sp.getString("scene", "AUTO");
        String scName = "NEW EACH DAY";
        if (!"AUTO".equals(sc)) {
            for (String[] s : Look.allScenes(pk)) {
                if (s[0].equals(sc)) scName = s[1];
            }
        }
        addMenuRow(box, "WALLPAPER: " + scName, d, new Runnable() {
            @Override
            public void run() {
                chooseScene();
            }
        });
        final boolean festOn = sp.getBoolean("fest", true);
        addMenuRow(box, "FESTIVAL THEMES: " + (festOn ? "ON" : "OFF"), d, new Runnable() {
            @Override
            public void run() {
                sp.edit().putBoolean("fest", !festOn).apply();
                styleChanged();
            }
        });
        final boolean lockOn = sp.getBoolean("lock_auto", true);
        addMenuRow(box, "LOCK SCREEN: " + (lockOn ? "MATCHES HOME" : "LEAVE ALONE"), d, new Runnable() {
            @Override
            public void run() {
                sp.edit().putBoolean("lock_auto", !lockOn).apply();
                styleChanged();
            }
        });
        addMenuRow(box, "PREVIEW A FESTIVAL", d, new Runnable() {
            @Override
            public void run() {
                choosePreview();
            }
        });
        if (look.previewUntil > 0) {
            addMenuRow(box, "STOP PREVIEW", d, new Runnable() {
                @Override
                public void run() {
                    sp.edit().remove("pv_name").remove("pv_until").apply();
                    styleChanged();
                }
            });
        }
        addMenuRow(box, "IMPORT CONTENT PACK", d, new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_PACK);
                } catch (Exception e) {
                    Toast.makeText(HomeActivity.this, "NO FILE PICKER FOUND", Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (!pk.isEmpty()) {
            addMenuRow(box, "REMOVE IMPORTED PACK", d, new Runnable() {
                @Override
                public void run() {
                    ContentPack.reset(HomeActivity.this);
                    sp.edit().remove("scene").apply();
                    poster.reloadPack();
                    styleChanged();
                    Toast.makeText(HomeActivity.this, "PACK REMOVED", Toast.LENGTH_SHORT).show();
                }
            });
            addNote(box, "PACK: " + (pk.name().length() > 0 ? pk.name().toUpperCase(Locale.getDefault()) + " • " : "") + pk.summary());
        }
        if (look.fest != null) addNote(box, "TODAY: " + look.fest.name + " • FESTIVAL COLOURS ARE ON");
        addMenuRow(box, "DONE", d, new Runnable() {
            @Override
            public void run() { }
        });
        d.show();
    }

    private void chooseScheme() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("COLOUR SCHEME", "THE WHOLE SCREEN FOLLOWS THE SKY IN THESE COLOURS", hb);
        String cur = sp.getString("pal", "HORIZON");
        for (final Palette p : Palette.USER) {
            addMenuRow(hb[0], (p.id.equals(cur) ? "> " : "") + p.name, d, new Runnable() {
                @Override
                public void run() {
                    sp.edit().putString("pal", p.id).apply();
                    styleChanged();
                }
            });
        }
        d.show();
    }

    private void chooseScene() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("WALLPAPER", "THE SCENE IN THE MIDDLE OF THE POSTER", hb);
        String cur = sp.getString("scene", "AUTO");
        addMenuRow(hb[0], ("AUTO".equals(cur) ? "> " : "") + "NEW EACH DAY", d, new Runnable() {
            @Override
            public void run() {
                sp.edit().putString("scene", "AUTO").apply();
                styleChanged();
            }
        });
        for (final String[] s : Look.allScenes(poster.pack())) {
            addMenuRow(hb[0], (s[0].equals(cur) ? "> " : "") + s[1], d, new Runnable() {
                @Override
                public void run() {
                    sp.edit().putString("scene", s[0]).apply();
                    styleChanged();
                }
            });
        }
        d.show();
    }

    private void choosePreview() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("PREVIEW", "SHOWS THE FESTIVAL LOOK FOR FIVE MINUTES", hb);
        for (final String n : Look.PREVIEW_NAMES) {
            addMenuRow(hb[0], n, d, new Runnable() {
                @Override
                public void run() {
                    sp.edit().putString("pv_name", n)
                            .putLong("pv_until", System.currentTimeMillis() + 5L * 60L * 1000L).apply();
                    styleChanged();
                }
            });
        }
        d.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PACK || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String msg = ContentPack.importFrom(HomeActivity.this, uri);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        poster.reloadPack();
                        styleChanged();
                        Toast.makeText(HomeActivity.this, msg, Toast.LENGTH_LONG).show();
                    }
                });
            }
        }).start();
    }

    private void applyDrawerTheme() {
        refreshTheme();
        drawer.setBackgroundColor(CREAM);
        root.setBackgroundColor(CREAM);
        titleView.setTextColor(INK);
        countView.setTextColor(RED);
        closeView.setTextColor(RED);
        ruleView.setBackgroundColor(INK);
        gridFrameView.setBackgroundColor(INK);
        grid.setBackgroundColor(INK);
    }

    @Override
    public void openDrawer() {
        applyDrawerTheme();
        pickTarget = -1;
        loadApps();
        grid.setSelection(0);
        drawer.setVisibility(View.VISIBLE);
    }

    @Override
    public void pickApp(int target) {
        if (target < 0 || target >= TARGET_NAMES.length) return;
        applyDrawerTheme();
        pickTarget = target;
        loadApps();
        grid.setSelection(0);
        drawer.setVisibility(View.VISIBLE);
    }

    private void closeDrawer() {
        pickTarget = -1;
        drawer.setVisibility(View.GONE);
    }
}
