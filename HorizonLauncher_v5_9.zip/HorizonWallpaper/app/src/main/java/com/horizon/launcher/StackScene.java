package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.io.InputStream;

/**
 * The layered Classic scenes ("city" and "highway"): every layer is a transparent picture already placed in the
 * 1364x944 picture space, drawn back to front, with traffic and people that move between the layers.
 *
 * City:    far skyline + towers, lit windows (night), shop-houses, road with street furniture; vehicles drive on the
 *          road, people walk on the pavement.
 * Highway: mountains + valley, road on the slope, foreground trees; vehicles drive between the road and the trees
 *          (the trees at the sides of the road cover them as they enter and leave).
 * A rare Meteor motorbike overtakes everything (every 40 to 60 minutes, or on a double tap on the scene).
 */
final class StackScene {

    static final int W = 1364, H = 944;
    private static final long PERIOD = 50L * 60000L;
    private static final long METEOR_MS = 3000L;
    private static volatile long manualStart = -1000000L;

    final boolean city;
    private Bitmap b0, bWin, b1, b2;
    private Bitmap[] veh = new Bitmap[0];
    private Bitmap[] ppl = new Bitmap[0];
    private Bitmap[] props = new Bitmap[0];
    private Bitmap meteor;

    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint plain = new Paint(Paint.FILTER_BITMAP_FLAG);
    private Paint tint;

    private StackScene(boolean city) { this.city = city; }

    private static Bitmap dec(Context ctx, String name) {
        try {
            InputStream in = ctx.getAssets().open(name);
            try { return BitmapFactory.decodeStream(in); } finally { in.close(); }
        } catch (Throwable t) {
            return null;
        }
    }

    private static Bitmap[] decAll(Context ctx, String prefix, int n) {
        Bitmap[] out = new Bitmap[n];
        for (int i = 0; i < n; i++) out[i] = dec(ctx, prefix + i + ".webp");
        return out;
    }

    static StackScene load(Context ctx, String id) {
        boolean city = "city".equals(id);
        StackScene s = new StackScene(city);
        if (city) {
            s.b0 = dec(ctx, "sc_city_0.webp");
            s.bWin = dec(ctx, "sc_city_win.webp");
            s.b1 = dec(ctx, "sc_city_1.webp");
            s.b2 = dec(ctx, "sc_city_2.webp");
            s.veh = decAll(ctx, "spr_cv", 18);
            s.ppl = decAll(ctx, "spr_cp", 12);
        } else {
            s.b0 = dec(ctx, "sc_hw_0.webp");
            s.b1 = dec(ctx, "sc_hw_1.webp");
            s.b2 = dec(ctx, "sc_hw_2.webp");
            s.veh = decAll(ctx, "spr_hv", 8);
            s.props = decAll(ctx, "spr_hp", 5);
        }
        s.meteor = dec(ctx, "spr_meteor0.webp");
        if (s.b0 == null || s.b1 == null) return null;
        return s;
    }

    /** Double tap on the scene: the Meteor rides past now (ignored while one is already riding). */
    static boolean trigger(long now) {
        if (now - manualStart < METEOR_MS + 4000L) return false;
        manualStart = now;
        return true;
    }

    // ---------- drawing ----------

    void draw(Canvas c, Paint tinted, float l, float r, float top, float bottom, float nightK, long now) {
        float[] g = SceneRender.geo(l, r, top, bottom);
        float s = g[3];
        tint = tinted;
        Paint bp = new Paint(tinted);
        bp.setFilterBitmap(true);
        c.save();
        c.translate(g[0], g[2]);
        c.scale(s, s);
        if (city) drawCity(c, bp, nightK, now); else drawHighway(c, bp, nightK, now);
        c.restore();
    }

    private void layer(Canvas c, Paint p, Bitmap b) {
        if (b != null) c.drawBitmap(b, 0f, 0f, p);
    }

    private void drawCity(Canvas c, Paint bp, float night, long now) {
        layer(c, bp, b0);
        if (bWin != null && night > 0.05f) {
            plain.setAlpha((int) (255 * Math.min(1f, night * 1.15f)));
            c.drawBitmap(bWin, 0f, 0f, plain);
            plain.setAlpha(255);
        }
        layer(c, bp, b1);
        if (now > 0L) {
            people(c, bp, now, night);
        }
        layer(c, bp, b2);
        lamps(c, night, new float[][]{{118, 627}, {265, 627}, {565, 627}, {930, 627}}, 70f);
        if (now > 0L) {
            traffic(c, bp, now, night, 918f, 938f, false, 0.34f, 1.0f);
        }
    }

    private void drawHighway(Canvas c, Paint bp, float night, long now) {
        layer(c, bp, b0);
        layer(c, bp, b1);
        // roadside: tea stall, prayer flags, shrine and a warning sign on the far verge
        if (props.length >= 5) {
            prop(c, bp, props[3], 520f, 650f);
            prop(c, bp, props[1], 660f, 650f);
            prop(c, bp, props[4], 870f, 648f);
            prop(c, bp, props[0], 1055f, 652f);
        }
        if (night > 0.1f) {
            lamps(c, night, new float[][]{{505, 628}, {540, 630}}, 42f);
            lamps(c, night, new float[][]{{866, 650}}, 26f);
        }
        if (now > 0L) {
            traffic(c, bp, now, night, 668f, 686f, true, 0.22f, 0.54f);
            // the trees beside the road hide the cars entering and leaving it
            c.save();
            c.clipRect(0f, 540f, 368f, 760f);
            layer(c, bp, b1);
            c.restore();
            c.save();
            c.clipRect(1135f, 540f, W, 760f);
            layer(c, bp, b1);
            c.restore();
        }
        layer(c, bp, b2);
    }

    private void prop(Canvas c, Paint bp, Bitmap b, float cx, float base) {
        if (b != null) c.drawBitmap(b, cx - b.getWidth() / 2f, base - b.getHeight(), bp);
    }

    private void lamps(Canvas c, float night, float[][] pts, float rad) {
        if (night < 0.06f) return;
        float k = Math.min(1f, night * 1.2f);
        for (float[] p : pts) {
            glow.setShader(new RadialGradient(p[0], p[1], rad,
                    new int[]{argb(190 * k, 255, 214, 130), argb(70 * k, 255, 190, 90), 0},
                    new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(p[0], p[1], rad, glow);
        }
        glow.setShader(null);
    }

    private static int argb(float a, int r, int g, int b) {
        return ((int) Math.max(0, Math.min(255, a)) << 24) | (r << 16) | (g << 8) | b;
    }

    // ---------- people ----------

    private static int hash(long a, int b) {
        long x = a * 0x9E3779B97F4A7C15L + b * 0xBF58476D1CE4E5B9L;
        x ^= (x >>> 29);
        x *= 0x94D049BB133111EBL;
        x ^= (x >>> 32);
        return (int) (x & 0x7fffffff);
    }

    private void people(Canvas c, Paint bp, long now, float night) {
        final long S = 15000L;            // a new walker may start every 15 s
        final float speed = 26f;          // picture px per second
        final long dur = (long) ((W + 400f) / speed * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        for (long n = n0; n <= n1; n++) {
            int h = hash(n, 7);
            if (h % 100 >= 78) continue;
            long t = now - n * S;
            if (t < 0 || t > dur) continue;
            int pick = (h >> 8) % 9;      // walkers 0-7 and the dog
            if (pick == 8) pick = 9;
            Bitmap b = pick < ppl.length ? ppl[pick] : null;
            if (b == null) continue;
            boolean rightward = ((h >> 4) & 1) == 0;
            float sp = speed * (0.85f + ((h >> 12) % 40) / 100f);
            float x = -200f + sp * t / 1000f;
            if (!rightward) x = W + 200f - sp * t / 1000f;
            if (x < -200f || x > W + 200f) continue;
            float feet = 874f + ((h >> 16) % 5);
            // a gentle stride bob
            float bob = (float) Math.abs(Math.sin(t / 1000.0 * 5.2 + h)) * 2.2f;
            drawSprite(c, bp, b, x, feet - bob, !rightward, false, night, 0f);
        }
    }

    // ---------- traffic ----------

    /**
     * Two lanes. Lane A runs left to right (feet at yA), lane B right to left (feet at yB). The sprite sheet of the
     * city has both directions; the highway only has right-facing ones, which are mirrored.
     */
    private void traffic(Canvas c, Paint bp, long now, float night, float yA, float yB, boolean mirrorOnly, float spacingK, float meteorK) {
        runLane(c, bp, now, night, yA, true, mirrorOnly, 1);
        runLane(c, bp, now, night, yB, false, mirrorOnly, 2);
        meteor(c, bp, now, night, yA + (mirrorOnly ? 1f : 0f), meteorK);
    }

    private void runLane(Canvas c, Paint bp, long now, float night, float feet, boolean rightward, boolean mirrorOnly, int lane) {
        final long S = city ? 6500L : 7500L;
        final float speed = city ? 115f : (rightward ? 80f : 70f);
        final long dur = (long) ((W + 800f) / speed * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        for (long n = n0; n <= n1; n++) {
            int h = hash(n, lane * 31);
            if (h % 100 >= (city ? 72 : 55)) continue;
            long t = now - n * S;
            if (t < 0 || t > dur) continue;
            int count = veh.length;
            int k;
            boolean flip;
            if (mirrorOnly) {
                k = (h >> 6) % count;
                flip = !rightward;
            } else {
                // right-facing pictures are 0..8, left-facing 9..17
                int base = (h >> 6) % 9;
                k = rightward ? base : base + 9;
                flip = false;
            }
            Bitmap b = veh[k];
            if (b == null) continue;
            float sp = speed * (0.9f + ((h >> 14) % 25) / 100f);
            float x = rightward ? -400f + sp * t / 1000f : W + 400f - sp * t / 1000f;
            if (x < -420f || x > W + 420f) continue;
            // the heaviest vehicles are slower
            drawSprite(c, bp, b, x, feet, flip, true, night, 1f);
        }
    }

    private void meteor(Canvas c, Paint bp, long now, float night, float feet, float scale) {
        if (meteor == null) return;
        long k = now / PERIOD;
        long ev = k * PERIOD + (long) ((hash(k, 99) % 10000) / 10000f * 10f * 60000f);
        float p = -1f;
        if (now >= ev && now < ev + METEOR_MS) p = (now - ev) / (float) METEOR_MS;
        long m = now - manualStart;
        if (m >= 0 && m < METEOR_MS) p = m / (float) METEOR_MS;
        if (p < 0f) return;
        float bw = meteor.getWidth() * scale, bh = meteor.getHeight() * scale;
        float x = -bw + (W + 2f * bw) * p;       // about three times faster than the traffic
        float y = feet;
        c.save();
        c.translate(x - bw / 2f + bw / 2f, 0f);
        // speed streak behind the bike
        if (night > 0.2f) {
            float a = Math.min(1f, night * 1.3f);
            glow.setShader(new android.graphics.LinearGradient(-bw * 2.4f, 0f, 0f, 0f, 0x00FF4030, argb(120 * a, 255, 70, 50), Shader.TileMode.CLAMP));
            c.drawRect(-bw * 2.4f, y - bh * 0.42f, 0f, y - bh * 0.34f, glow);
            glow.setShader(null);
        } else {
            glow.setShader(new android.graphics.LinearGradient(-bw * 2.0f, 0f, 0f, 0f, 0x00FFFFFF, 0x66FFFFFF, Shader.TileMode.CLAMP));
            c.drawRect(-bw * 2.0f, y - bh * 0.30f, 0f, y - bh * 0.26f, glow);
            glow.setShader(null);
        }
        c.restore();
        Paint pp = bp;
        c.drawBitmap(meteor, null, new android.graphics.RectF(x, y - bh, x + bw, y), pp);
        if (night > 0.12f) {
            float hx = x + bw * 0.97f, hy = y - bh * 0.46f;
            headlight(c, hx, hy, 150f * scale + 40f, night, true);
        }
    }

    private void headlight(Canvas c, float x, float y, float len, float night, boolean toRight) {
        float a = Math.min(1f, (night - 0.1f) * 1.4f);
        if (a <= 0f) return;
        float dir = toRight ? 1f : -1f;
        glow.setShader(new RadialGradient(x, y, len, new int[]{argb(190 * a, 255, 240, 190), argb(60 * a, 255, 225, 150), 0},
                new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        c.save();
        c.translate(x, y);
        c.scale(1.7f * dir, 0.45f);
        c.translate(-x, -y);
        c.drawCircle(x, y, len, glow);
        c.restore();
        glow.setShader(null);
    }

    /**
     * @param feet  y of the wheels / feet
     * @param flip  mirror the picture
     */
    private void drawSprite(Canvas c, Paint bp, Bitmap b, float cx, float feet, boolean flip, boolean vehicle, float night, float unused) {
        float w = b.getWidth(), h = b.getHeight();
        float left = cx - w / 2f, top = feet - h + 3f;
        c.save();
        if (flip) c.scale(-1f, 1f, cx, 0f);
        c.drawBitmap(b, left, top, bp);
        c.restore();
        if (vehicle && night > 0.12f) {
            // the car travels toward its front: right-facing picture unless mirrored
            boolean right = !flip;
            // pictures 9..17 of the city sheet face left; their flip flag is false but they head left
            int idx = -1;
            for (int i = 0; i < veh.length; i++) if (veh[i] == b) { idx = i; break; }
            if (city && idx >= 9) right = false;
            float fx = right ? cx + w * 0.47f : cx - w * 0.47f;
            float fy = top + h * 0.62f;
            headlight(c, fx, fy, Math.max(60f, w * 0.55f), night, right);
            float rx = right ? cx - w * 0.47f : cx + w * 0.47f;
            float a = Math.min(1f, (night - 0.1f) * 1.4f);
            glow.setShader(new RadialGradient(rx, fy, 9f, new int[]{argb(200 * a, 255, 50, 40), 0}, null, Shader.TileMode.CLAMP));
            c.drawCircle(rx, fy, 9f, glow);
            glow.setShader(null);
        }
    }
}
