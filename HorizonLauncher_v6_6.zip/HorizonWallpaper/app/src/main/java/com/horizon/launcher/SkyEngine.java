package com.horizon.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.Random;

/**
 * The sky engine: sun with rays, soft procedural clouds and shooting stars, all drawn in code (no pictures).
 * It is used by imported themes whose theme.json says "engine" (see ThemePack); the built-in looks are untouched.
 * Everything here is drawn in design units, like the rest of the poster.
 */
final class SkyEngine {
    private SkyEngine() { }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private static int mix(int a, int b, float t) {
        t = clamp(t);
        return Color.rgb(
                Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t),
                Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t),
                Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    private static int withAlpha(int rgb, float a) {
        return Color.argb(Math.round(255f * clamp(a)), Color.red(rgb), Color.green(rgb), Color.blue(rgb));
    }

    // ------------------------------------------------------------------ clouds

    /**
     * One soft cloud picture, drawn from overlapping round puffs: a darker underside first, then the lit body on top,
     * then the base is flattened with a soft fade. kind 0 = fair-weather cumulus, 1 = grey layered overcast, 2 = dark storm.
     */
    static Bitmap cloud(int kind, int idx) {
        final int W = 360, H = 170;
        Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Random rnd = new Random(1000L * kind + 7919L * idx + 13L);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int n = kind == 0 ? 9 + rnd.nextInt(5) : (kind == 1 ? 17 : 13);
        float[] px = new float[n], py = new float[n], pr = new float[n];
        for (int i = 0; i < n; i++) {
            float t = (i + 0.5f) / n;
            float bump = (float) Math.sin(Math.PI * t);
            float jit = 0.75f + 0.5f * rnd.nextFloat();
            px[i] = W * (0.14f + 0.72f * t) + (rnd.nextFloat() - 0.5f) * 14f;
            if (kind == 0) {
                pr[i] = (22f + 34f * bump) * jit;
                py[i] = H * 0.64f - bump * 36f + (rnd.nextFloat() - 0.5f) * 10f;
            } else if (kind == 1) {
                pr[i] = (17f + 17f * bump) * jit;
                py[i] = H * 0.58f - bump * 14f + (rnd.nextFloat() - 0.5f) * 20f;
            } else {
                pr[i] = (26f + 28f * bump) * jit;
                py[i] = H * 0.6f - bump * 22f + (rnd.nextFloat() - 0.5f) * 12f;
            }
        }
        int shadow = kind == 0 ? 0xB4C0D8 : (kind == 1 ? 0x8C94A0 : 0x2A313D);
        int light = kind == 0 ? 0xFFFFFF : (kind == 1 ? 0xD6DADF : 0x6F7A8C);
        float sx = kind == 1 ? 1.6f : 1f;   // the overcast layers are long and flat
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < n; i++) {
                float cx = px[i], cy = py[i] + (pass == 0 ? pr[i] * 0.28f : -pr[i] * 0.16f), r = pr[i] * (pass == 0 ? 1.05f : 0.92f);
                int col = pass == 0 ? shadow : light;
                p.setShader(new RadialGradient(cx, cy, r,
                        new int[]{withAlpha(col, pass == 0 ? 0.85f : 0.97f), withAlpha(col, pass == 0 ? 0.70f : 0.88f), withAlpha(col, 0f)},
                        new float[]{0f, 0.60f, 1f}, Shader.TileMode.CLAMP));
                c.save();
                if (sx != 1f) c.scale(sx, 1f, cx, cy);
                c.drawCircle(cx, cy, r, p);
                c.restore();
            }
        }
        // a soft, nearly flat base
        p.setShader(new LinearGradient(0, H * 0.58f, 0, H * 0.9f, 0xFF000000, 0x00000000, Shader.TileMode.CLAMP));
        p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawRect(0, 0, W, H, p);
        p.setXfermode(null);
        p.setShader(null);
        return b;
    }

    // ------------------------------------------------------------------ sun

    /**
     * The sun: soft glow, long and short rays that shimmer slowly, a bright bloom and a white-hot disc.
     * Low sun (warm 1): orange, a wide horizontal flare, fewer rays. Partly cloudy sky: soft beams fan out downwards.
     * Cloudy sky: only a faint glow. alpha 0..255 is the overall strength.
     */
    static void sun(Canvas c, Paint p, float x, float y, float r, int alpha, float warm, float cloud) {
        float al = clamp(alpha / 255f);
        warm = clamp(warm);
        cloud = clamp(cloud);
        long now = System.currentTimeMillis();
        int hot = mix(0xFFFFF0, 0xFFC878, warm);     // centre of the disc
        int rim = mix(0xFFEBA8, 0xFF7A26, warm);     // edge of the disc
        int glow = mix(0xFFE9A0, 0xFF8A3A, warm);
        float clear = 1f - 0.75f * cloud;
        p.setStyle(Paint.Style.FILL);
        p.setXfermode(null);
        p.setColorFilter(null);

        // soft beams through broken cloud
        float tri = 1f - Math.min(1f, Math.abs(cloud - 0.45f) / 0.30f);
        if (tri > 0.02f) {
            float len = r * 16f;
            p.setShader(new RadialGradient(x, y, len, new int[]{withAlpha(glow, 0.20f * tri * al), withAlpha(glow, 0f)},
                    new float[]{0.05f, 1f}, Shader.TileMode.CLAMP));
            Path beams = new Path();
            for (int k = 0; k < 7; k++) {
                double a = Math.toRadians(52 + k * 12.0 + 3.0 * Math.sin(now / 5000.0 + k * 2.1));
                double hw = Math.toRadians(2.0 + 1.6 * ((k * 5) % 3));
                beams.moveTo(x, y);
                beams.lineTo(x + (float) Math.cos(a - hw) * len, y + (float) Math.sin(a - hw) * len);
                beams.lineTo(x + (float) Math.cos(a + hw) * len, y + (float) Math.sin(a + hw) * len);
                beams.close();
            }
            c.drawPath(beams, p);
        }

        // wide soft glow
        float gr = r * 4.4f;
        p.setShader(new RadialGradient(x, y, gr, new int[]{withAlpha(glow, 0.50f * al * (0.45f + 0.55f * clear)), withAlpha(glow, 0f)},
                new float[]{r / gr * 0.8f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, gr, p);

        // low sun: a wide, flat flare along the horizon
        if (warm > 0.2f) {
            c.save();
            c.scale(1f, 0.14f, x, y);
            float fr = r * 6.5f;
            p.setShader(new RadialGradient(x, y, fr, new int[]{withAlpha(glow, 0.55f * warm * al), withAlpha(glow, 0f)},
                    new float[]{0.1f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, fr, p);
            c.restore();
        }

        // rays: sixteen thin spikes, long and short alternating, slowly turning
        float rayA = al * clear * (1f - 0.55f * warm);
        if (rayA > 0.03f) {
            float rot = (float) (now * 0.00004);
            float maxL = r * 3.7f;
            p.setShader(new RadialGradient(x, y, maxL, new int[]{withAlpha(0xFFFFFF, 0.85f * rayA), withAlpha(glow, 0f)},
                    new float[]{r * 0.9f / maxL, 1f}, Shader.TileMode.CLAMP));
            Path rays = new Path();
            for (int k = 0; k < 16; k++) {
                float a = rot + k * (float) (Math.PI * 2 / 16);
                boolean big = k % 2 == 0;
                float L = r * (big ? 3.5f : 2.3f) * (0.93f + 0.07f * (float) Math.sin(now / 1100.0 + k * 1.3));
                float hw = r * (big ? 0.11f : 0.07f);
                float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                float bx = x + ca * r * 0.9f, by = y + sa * r * 0.9f;
                rays.moveTo(bx - sa * hw, by + ca * hw);
                rays.lineTo(x + ca * L, y + sa * L);
                rays.lineTo(bx + sa * hw, by - ca * hw);
                rays.close();
            }
            c.drawPath(rays, p);
        }

        // bloom just outside the disc
        float br = r * 1.4f;
        p.setShader(new RadialGradient(x, y, br, new int[]{withAlpha(0xFFFFFF, 0.70f * al), withAlpha(0xFFFFFF, 0f)},
                new float[]{0.68f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, br, p);

        // the disc itself
        p.setShader(new RadialGradient(x - r * 0.08f, y - r * 0.08f, r * 1.05f,
                new int[]{withAlpha(hot, al), withAlpha(hot, al), withAlpha(rim, al)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
        p.setShader(null);
        p.setAlpha(255);
    }

    // ------------------------------------------------------------------ shooting star

    private static long hash(long v) {
        v *= 0x9E3779B97F4A7C15L;
        v ^= v >>> 29;
        v *= 0xBF58476D1CE4E5B9L;
        v ^= v >>> 32;
        return v;
    }

    /** A rare shooting star: about one every three minutes on a clear night, a streak that lives for under a second. */
    static void shootingStar(Canvas c, Paint p, long now, float xMin, float xMax, float yMin, float yMax, int alpha) {
        final long SLOT = 45000L, DUR = 900L;
        long slot = now / SLOT;
        long h = hash(slot);
        if ((h & 3L) != 0L) return;
        long t = now - slot * SLOT - (Math.abs(h >>> 8) % (SLOT - 2000L));
        if (t < 0L || t > DUR) return;
        float u = t / (float) DUR;
        float fx = ((h >>> 20) & 1023L) / 1023f, fy = ((h >>> 32) & 1023L) / 1023f;
        float x0 = xMin + (xMax - xMin) * (0.20f + 0.55f * fx);
        float y0 = yMin + (yMax - yMin) * (0.05f + 0.35f * fy);
        double ang = Math.toRadians(22 + ((h >>> 44) & 15L));
        float dx = (float) Math.cos(ang), dy = (float) Math.sin(ang);
        float travel = 95f * u;
        float hx = x0 + dx * travel, hy = y0 + dy * travel;
        float tail = 46f * (float) Math.sin(Math.PI * Math.min(1f, u * 1.1f));
        float a = (float) Math.sin(Math.PI * u) * clamp(alpha / 255f);
        if (a < 0.02f || tail < 2f) return;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(1.3f);
        p.setShader(new LinearGradient(hx - dx * tail, hy - dy * tail, hx, hy, withAlpha(0xFFFFFF, 0f), withAlpha(0xFFFFFF, a), Shader.TileMode.CLAMP));
        c.drawLine(hx - dx * tail, hy - dy * tail, hx, hy, p);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(withAlpha(0xFFFFFF, a));
        c.drawCircle(hx, hy, 1.5f, p);
        p.setAlpha(255);
        p.setStrokeCap(Paint.Cap.BUTT);
    }
}
