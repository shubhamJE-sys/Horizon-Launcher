package com.horizon.launcher;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.ArrayList;
import java.util.List;

/** The brighter constellations: where their stars are (right ascension in hours, declination in degrees) and the lines that join them. */
final class Constellations {

    private Constellations() { }

    static final class C {
        final String name;
        final double[][] st;   // {ra hours, dec degrees}
        final int[][] ln;      // pairs of star indexes, in the order a pen would draw them

        C(String name, double[][] st, int[][] ln) {
            this.name = name;
            this.st = st;
            this.ln = ln;
        }
    }

    static final C[] ALL = {
            new C("ORION", new double[][]{{5.585, 9.934}, {5.919, 7.407}, {5.419, 6.350}, {5.533, -0.299}, {5.603, -1.202}, {5.679, -1.943}, {5.796, -9.670}, {5.242, -8.202}},
                    new int[][]{{1, 0}, {0, 2}, {2, 3}, {3, 4}, {4, 5}, {5, 1}, {5, 6}, {3, 7}}),
            new C("TAURUS", new double[][]{{4.477, 19.18}, {4.599, 16.509}, {5.627, 21.14}, {5.438, 28.608}},
                    new int[][]{{0, 1}, {1, 2}, {1, 3}}),
            new C("AURIGA", new double[][]{{5.278, 45.998}, {5.992, 44.947}, {5.995, 37.213}, {5.438, 28.608}, {4.950, 33.166}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 0}}),
            new C("GEMINI", new double[][]{{7.577, 31.888}, {7.755, 28.026}},
                    new int[][]{{0, 1}}),
            new C("CANIS MAJOR", new double[][]{{6.378, -17.956}, {6.752, -16.716}, {7.140, -26.393}, {6.977, -28.972}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}}),
            new C("URSA MAJOR", new double[][]{{11.062, 61.751}, {11.031, 56.382}, {11.897, 53.695}, {12.257, 57.033}, {12.900, 55.960}, {13.399, 54.925}, {13.792, 49.313}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}, {3, 4}, {4, 5}, {5, 6}}),
            new C("CASSIOPEIA", new double[][]{{0.153, 59.150}, {0.675, 56.537}, {0.945, 60.717}, {1.430, 60.235}, {1.907, 63.67}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}}),
            new C("PEGASUS", new double[][]{{23.079, 15.205}, {23.063, 28.083}, {0.139, 29.09}, {0.220, 15.184}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 0}}),
            new C("ANDROMEDA", new double[][]{{0.139, 29.09}, {1.162, 35.62}, {2.065, 42.33}},
                    new int[][]{{0, 1}, {1, 2}}),
            new C("CYGNUS", new double[][]{{20.690, 45.280}, {20.370, 40.257}, {19.512, 27.960}, {19.749, 45.131}, {20.770, 33.970}},
                    new int[][]{{0, 1}, {1, 2}, {3, 1}, {1, 4}}),
            new C("LYRA", new double[][]{{18.616, 38.784}, {18.746, 37.605}, {18.835, 33.363}, {18.982, 32.689}, {18.908, 36.899}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 1}}),
            new C("AQUILA", new double[][]{{19.771, 10.613}, {19.846, 8.868}, {19.922, 6.407}},
                    new int[][]{{0, 1}, {1, 2}}),
            new C("SAGITTARIUS", new double[][]{{18.097, -30.424}, {18.350, -29.828}, {18.466, -25.422}, {18.921, -26.297}, {19.116, -27.670}, {19.043, -29.880}, {18.403, -34.385}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 5}, {5, 6}, {6, 0}}),
            new C("SCORPIUS", new double[][]{{16.091, -19.805}, {16.005, -22.622}, {16.490, -26.432}, {16.836, -34.293}, {17.622, -42.998}, {17.560, -37.104}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 5}}),
            new C("LEO", new double[][]{{10.139, 11.967}, {10.122, 16.762}, {10.333, 19.842}, {11.235, 20.524}, {11.818, 14.572}, {11.237, 15.430}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 5}, {5, 0}}),
            new C("BOOTES", new double[][]{{13.911, 18.398}, {14.261, 19.182}, {14.750, 27.074}, {14.535, 38.308}, {15.032, 40.391}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}}),
            new C("VIRGO", new double[][]{{11.845, 1.765}, {12.694, -1.449}, {13.578, -0.596}, {13.420, -11.161}, {13.036, 10.959}},
                    new int[][]{{0, 1}, {1, 2}, {2, 3}, {1, 4}}),
            new C("SOUTHERN CROSS", new double[][]{{12.443, -63.099}, {12.519, -57.113}, {12.795, -59.689}, {12.252, -58.749}},
                    new int[][]{{0, 1}, {2, 3}}),
    };

    /** {altitude, azimuth} in degrees of a star seen from lat, lon (north and east positive) at the given moment. */
    static double[] altAz(double raH, double dec, long ms, double lat, double lon) {
        double jd = ms / 86400000.0 + 2440587.5;
        double gmst = (280.46061837 + 360.98564736629 * (jd - 2451545.0)) % 360.0;
        if (gmst < 0) gmst += 360.0;
        double h = Math.toRadians(gmst + lon - raH * 15.0);
        double de = Math.toRadians(dec), la = Math.toRadians(lat);
        double sa = Math.sin(de) * Math.sin(la) + Math.cos(de) * Math.cos(la) * Math.cos(h);
        double alt = Math.asin(Math.max(-1.0, Math.min(1.0, sa)));
        double az = Math.atan2(-Math.cos(de) * Math.sin(h), Math.sin(de) * Math.cos(la) - Math.cos(de) * Math.sin(la) * Math.cos(h));
        double azd = Math.toDegrees(az);
        if (azd < 0) azd += 360.0;
        return new double[]{Math.toDegrees(alt), azd};
    }

    /** Mean altitude of a constellation's stars, or -90 if less than most of its stars are above minAlt. */
    static double meanAlt(C c, long ms, double lat, double lon, double minAlt) {
        double sum = 0;
        int up = 0;
        for (double[] s : c.st) {
            double a = altAz(s[0], s[1], ms, lat, lon)[0];
            sum += a;
            if (a > minAlt) up++;
        }
        return up >= Math.max(2, (int) Math.ceil(c.st.length * 0.75)) ? sum / c.st.length : -90;
    }

    /** The constellations that are properly up (all or nearly all of their stars above minAlt) at this moment. */
    static List<C> visible(long ms, double lat, double lon, double minAlt) {
        ArrayList<C> out = new ArrayList<C>();
        for (C c : ALL) if (meanAlt(c, ms, lat, lon, minAlt) > -90) out.add(c);
        return out;
    }

    /**
     * The figure as the sky shows it, around its own centre: star positions in x (right) and y (down), scaled so the
     * widest side is `size` units, plus the mean altitude in out[0] of the returned pair.
     */
    static float[][] shape(C c, long ms, double lat, double lon, float size, float[] meanAlt) {
        int n = c.st.length;
        double[] alt = new double[n], az = new double[n];
        double sa = 0, sx = 0, sy = 0;
        for (int i = 0; i < n; i++) {
            double[] q = altAz(c.st[i][0], c.st[i][1], ms, lat, lon);
            alt[i] = q[0];
            az[i] = q[1];
            sa += q[0];
            sx += Math.sin(Math.toRadians(q[1]));
            sy += Math.cos(Math.toRadians(q[1]));
        }
        double altC = sa / n, azC = Math.toDegrees(Math.atan2(sx, sy));
        float[][] p = new float[n][2];
        float minX = 1e9f, maxX = -1e9f, minY = 1e9f, maxY = -1e9f;
        for (int i = 0; i < n; i++) {
            double dAz = az[i] - azC;
            while (dAz > 180) dAz -= 360;
            while (dAz < -180) dAz += 360;
            p[i][0] = (float) (dAz * Math.cos(Math.toRadians(altC)));    // to the right as you look at it
            p[i][1] = (float) -(alt[i] - altC);                             // up on the sky is up on the screen
            minX = Math.min(minX, p[i][0]);
            maxX = Math.max(maxX, p[i][0]);
            minY = Math.min(minY, p[i][1]);
            maxY = Math.max(maxY, p[i][1]);
        }
        float w = Math.max(1f, Math.max(maxX - minX, maxY - minY));
        float k = size / w, cx = (minX + maxX) / 2f, cy = (minY + maxY) / 2f;
        for (int i = 0; i < n; i++) {
            p[i][0] = (p[i][0] - cx) * k;
            p[i][1] = (p[i][1] - cy) * k;
        }
        if (meanAlt != null && meanAlt.length > 0) meanAlt[0] = (float) altC;
        return p;
    }

    // ---- the one constellation the sky is drawing right now (page 1 and the window on page 2 show the same one) ----

    static final class Plan {
        C c;
        float[][] pts;     // figure scaled to about 92 units wide
        float meanAlt;     // degrees
        float fx;          // 0..1, where along the sky it is drawn
        float t;           // seconds into this constellation's turn
    }

    private static long planSlot = -1, visAt = 0;
    private static Plan planCur;
    private static List<C> visCache;
    private static final long SLOT_MS = 45000L;

    /** The constellation being traced now, or null while the sky rests (it draws for about 12 seconds in every 45). */
    static synchronized Plan plan(long now, double lat, double lon) {
        long slot = now / SLOT_MS;
        float t = (now % SLOT_MS) / 1000f;
        if (t > 12.5f) return null;
        if (slot != planSlot) {
            planSlot = slot;
            planCur = null;
            try {
                if (visCache == null || now - visAt > 120000L) {
                    visCache = visible(now, lat, lon, 14.0);
                    visAt = now;
                }
                if (!visCache.isEmpty()) {
                    Plan pl = new Plan();
                    pl.c = visCache.get((int) ((slot * 7 + 3) % visCache.size()));
                    float[] ma = new float[1];
                    pl.pts = shape(pl.c, now, lat, lon, 92f, ma);
                    pl.meanAlt = ma[0];
                    pl.fx = ((slot * 37) % 100) / 100f;
                    planCur = pl;
                }
            } catch (Throwable ignored) { planCur = null; }
        }
        if (planCur == null) return null;
        planCur.t = t;
        return planCur;
    }

    /** Draws the line running along the figure, then fading. scale shrinks the figure; alpha 0..1 is the strongest the line gets. */
    static void drawTrace(Canvas c, Paint p, Plan pl, float cx, float cy, float scale, float stroke, float starR, int color, float alpha) {
        float t = pl.t;
        float fade = t < 8f ? 1f : Math.max(0f, 1f - (t - 8f) / 4.5f);
        float grow = Math.min(1f, t / 5f);
        float a = alpha * fade;
        if (a <= 0.01f) return;
        int[][] ln = pl.c.ln;
        float[] len = new float[ln.length];
        float total = 0f;
        for (int i = 0; i < ln.length; i++) {
            float dx = (pl.pts[ln[i][1]][0] - pl.pts[ln[i][0]][0]) * scale, dy = (pl.pts[ln[i][1]][1] - pl.pts[ln[i][0]][1]) * scale;
            len[i] = (float) Math.sqrt(dx * dx + dy * dy);
            total += len[i];
        }
        float reach = total * grow;
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(stroke);
        p.setColor(color);
        p.setAlpha((int) (255 * a));
        float done = 0f, hx = 0f, hy = 0f;
        boolean head = false;
        boolean[] lit = new boolean[pl.pts.length];
        for (int i = 0; i < ln.length && done < reach; i++) {
            float x0 = cx + pl.pts[ln[i][0]][0] * scale, y0 = cy + pl.pts[ln[i][0]][1] * scale;
            float x1 = cx + pl.pts[ln[i][1]][0] * scale, y1 = cy + pl.pts[ln[i][1]][1] * scale;
            float part = len[i] <= 0f ? 1f : Math.min(1f, (reach - done) / len[i]);
            hx = x0 + (x1 - x0) * part;
            hy = y0 + (y1 - y0) * part;
            c.drawLine(x0, y0, hx, hy, p);
            lit[ln[i][0]] = true;
            if (part >= 1f) lit[ln[i][1]] = true;
            head = part < 1f;
            done += len[i];
        }
        p.setStyle(Paint.Style.FILL);
        p.setAlpha((int) (255 * Math.min(1f, a * 1.7f)));
        for (int i = 0; i < lit.length; i++)
            if (lit[i]) c.drawCircle(cx + pl.pts[i][0] * scale, cy + pl.pts[i][1] * scale, starR, p);
        if (head) {
            p.setAlpha((int) (255 * Math.min(1f, a * 2.2f)));
            c.drawCircle(hx, hy, starR * 0.75f, p);
        }
        p.setAlpha(255);
        p.setStrokeCap(Paint.Cap.BUTT);
    }
}
