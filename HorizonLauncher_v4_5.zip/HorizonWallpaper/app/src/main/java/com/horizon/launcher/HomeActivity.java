package com.horizon.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.pm.LauncherApps;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.util.DisplayMetrics;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.graphics.drawable.BitmapDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import java.util.HashMap;
import android.widget.ScrollView;
import android.widget.Toast;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import java.util.Calendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends Activity implements PosterView.Host {

    private static final int REQ_PACK = 41;
    private static final int REQ_LOC = 42;

    // colours follow the sky of the home screen; these are the defaults until it has drawn once
    private int INK = Color.parseColor("#1B1B1A");
    private int RED = Color.parseColor("#C8382C");
    private int CREAM = Color.parseColor("#ECE3D0");

    private static final String[] TARGET_NAMES = {
            "PHONE BUTTON", "MESSAGES BUTTON", "BROWSER BUTTON", "GALLERY BUTTON",
            "CAMERA BUTTON", "PLAY STORE BUTTON", "MUSIC OPEN BUTTON", "CLOCK TAP", "CALENDAR TAP",
            "GREETING TAP (NEWS)"};

    private static class AppEntry {
        String label;
        ComponentName component; // null = "reset to default" entry
    }

    private PosterView poster;
    private FrameLayout root;
    private LinearLayout drawer;
    private ListView grid;
    private TextView titleView, countView;

    // all-apps list: sections, text or icons, recent row, A-Z strip and a search bar
    private static class Row {
        int type;            // 0 letter heading, 1 one app as text, 2 up to three apps as icons, 3 recent apps
        int letterIdx;       // 0 = '#', 1..26 = A..Z
        AppEntry[] cells;
    }

    private final List<Row> rows = new ArrayList<Row>();
    private final int[] letterRow = new int[27];
    private final TextView[] railViews = new TextView[27];
    private final HashMap<String, Bitmap> iconCache = new HashMap<String, Bitmap>();
    private int iconSig = 0;
    private int railCurrent = -1;
    private String query = "";
    private boolean iconMode = false;
    private EditText searchBox;
    private LinearLayout searchFrame, rail;
    private TextView modeView;
    private View searchDash;
    private Typeface bebas, roboto;
    private final List<AppEntry> apps = new ArrayList<AppEntry>();
    private final List<AppEntry> shown = new ArrayList<AppEntry>();
    private BaseAdapter adapter;
    private int pickTarget = -1;
    private TextView closeView;
    private View ruleView;
    private FrameLayout gridFrameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (showCrashReport()) return;
        getWindow().setBackgroundDrawable(new ColorDrawable(CREAM));
        try {
            bebas = Typeface.createFromAsset(getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(getAssets(), "Roboto-Regular.ttf");
        } catch (Exception e) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(CREAM);
        poster = new PosterView(this, this);
        root.addView(poster, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildDrawer();
        root.addView(drawer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawer.setVisibility(View.GONE);
        setContentView(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int navBottom = insets.getSystemWindowInsetBottom();
                int imeBottom = navBottom;
                if (Build.VERSION.SDK_INT >= 30) {
                    navBottom = insets.getInsets(WindowInsets.Type.systemBars()).bottom;
                    imeBottom = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime()).bottom;
                }
                poster.setBottomInset(navBottom);
                // the keyboard lifts the whole all-apps list, search bar included
                drawer.setPadding(dp(18), dp(52), dp(18), imeBottom + dp(8));
                return insets;
            }
        });
        root.requestApplyInsets();

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, new OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            // A launcher never exits: back closes the app grid or the music panel.
                            if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
                            else poster.closePanel();
                        }
                    });
        }
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        hideBars();
    }

    /** If the last run crashed, shows the reason on screen (so it can be photographed) instead of the home screen. */
    private boolean showCrashReport() {
        String txt = null;
        try {
            java.io.File f = HorizonApp.crashFile(this);
            if (!f.exists()) return false;
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] b = new byte[(int) Math.min(f.length(), 8000)];
            int n = in.read(b);
            in.close();
            txt = new String(b, 0, Math.max(n, 0), "UTF-8");
        } catch (Throwable t) {
            return false;
        }
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(0xFFF3E9D2);
        col.setPadding(dp(16), dp(40), dp(16), dp(16));
        TextView head = new TextView(this);
        head.setText("HORIZON CRASH REPORT - send a photo of this");
        head.setTextColor(0xFFB3261E);
        head.setTextSize(16);
        head.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(head);
        ScrollView sv = new ScrollView(this);
        TextView body = new TextView(this);
        body.setText(txt);
        body.setTextColor(0xFF1B1B1B);
        body.setTextSize(10);
        body.setTypeface(Typeface.MONOSPACE);
        sv.addView(body);
        col.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        TextView btn = new TextView(this);
        btn.setText("CLEAR REPORT AND RESTART");
        btn.setTextColor(0xFFF3E9D2);
        btn.setBackgroundColor(0xFF1B1B1B);
        btn.setGravity(android.view.Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HorizonApp.crashFile(HomeActivity.this).delete();
                recreate();
            }
        });
        col.addView(btn);
        setContentView(col);
        return true;
    }

    /**
     * Keeps the lock screen and the plain wallpaper behind the launcher in the same colours as the home screen.
     * Runs only when the day, scheme, scene, festival or part of the day (day / twilight / night) changes.
     */
    private void updateWallpapers() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        final Look look = poster.look();
        final int sr = poster.sunriseMin(), ss = poster.sunsetMin();
        final int nowMin = LockArt.minuteOfDay();
        final int bucket = LockArt.bucket(nowMin, sr, ss);
        final boolean lockOn = sp.getBoolean("lock_auto", true);
        final String key = LockArt.key(this, look, bucket) + "|" + lockOn;
        if (key.equals(sp.getString("wp_key", ""))) return;
        sp.edit().putString("wp_key", key).apply();
        final float cloud = poster.cloudAmount();
        final float temp = poster.temperatureOrNaN();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    WallpaperManager wm = WallpaperManager.getInstance(HomeActivity.this);
                    Sky sky = Sky.compute(look.pal, nowMin, sr, ss, cloud);
                    int sw, sh;
                    if (Build.VERSION.SDK_INT >= 30) {
                        android.graphics.Rect b = getWindowManager().getMaximumWindowMetrics().getBounds();
                        sw = b.width();
                        sh = b.height();
                    } else {
                        DisplayMetrics dm = getResources().getDisplayMetrics();
                        sw = dm.widthPixels;
                        sh = dm.heightPixels;
                    }
                    int w = Math.min(sw, 1440), h = Math.round(w * (float) sh / sw);
                    Bitmap plain = LockArt.plain(sky, Math.max(2, w / 2), Math.max(2, h / 2));
                    wm.setBitmap(plain, new android.graphics.Rect(0, 0, plain.getWidth(), plain.getHeight()),
                            true, WallpaperManager.FLAG_SYSTEM);
                    if (lockOn) {
                        Bitmap lock = LockArt.lock(HomeActivity.this, look, sky, nowMin, sr, ss, cloud, temp, w, h);
                        // show the whole picture, not a zoomed crop of it
                        wm.setBitmap(lock, new android.graphics.Rect(0, 0, lock.getWidth(), lock.getHeight()),
                                true, WallpaperManager.FLAG_LOCK);
                    }
                } catch (Throwable ignored) { }
            }
        }).start();
    }

    /**
     * The drawer is a full page, so the sky's strong colour is calmed down into a paper tone (a hint of today's
     * scheme, never a glaring fill), and the accent is kept clearly darker (or lighter at night) than the paper.
     */
    private void refreshTheme() {
        int mid = poster.skyMid();
        int acc = poster.skyAccent();
        float[] bg = new float[3];
        Color.colorToHSV(mid, bg);
        boolean light = bg[2] > 0.5f;
        float[] ac = new float[3];
        Color.colorToHSV(acc, ac);
        if (light) {
            bg[1] = Math.min(0.20f, bg[1] * 0.38f);
            bg[2] = 0.93f;
            ac[1] = Math.min(0.78f, ac[1]) * 0.9f;
            ac[2] = Math.min(ac[2], 0.60f);
            INK = Color.parseColor("#1B1B1A");
        } else {
            bg[1] = Math.min(0.40f, bg[1] * 0.6f);
            bg[2] = Math.min(bg[2], 0.15f);
            ac[1] = ac[1] * 0.8f;
            ac[2] = Math.max(ac[2], 0.80f);
            INK = Color.parseColor("#EDE6D3");
        }
        CREAM = Color.HSVToColor(bg);
        RED = Color.HSVToColor(ac);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (poster == null) return;
        poster.start();
        hideBars();
        refreshTheme();
        getWindow().setBackgroundDrawable(new ColorDrawable(CREAM));
        root.post(new Runnable() {
            @Override
            public void run() {
                updateWallpapers();
            }
        });
    }

    @Override
    protected void onPause() {
        if (poster != null) poster.stop();
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (poster == null) return;
        // Pressing Home again returns to the poster.
        if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
        poster.closePanel();
    }

    // ---------- app grid ----------

    private View makeHair() {
        View h = new View(this);
        h.setBackgroundColor((INK & 0x00FFFFFF) | 0x40000000);
        h.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        return h;
    }

    private TextView makeLabel(float size, int maxLines, int gravity) {
        TextView tv = new TextView(this);
        tv.setTypeface(bebas);
        tv.setTextSize(size);
        tv.setTextColor(INK);
        tv.setLetterSpacing(0.06f);
        tv.setGravity(gravity);
        tv.setMaxLines(maxLines);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setIncludeFontPadding(false);
        return tv;
    }

    private View makeDash(int w) {
        View bar = new View(this);
        bar.setBackgroundColor(RED);
        bar.setLayoutParams(new LinearLayout.LayoutParams(dp(w), dp(2)));
        return bar;
    }

    private void wireEntry(View v, final AppEntry a) {
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                onEntryClicked(a);
            }
        });
        v.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View x) {
                if (pickTarget >= 0 || a.component == null) return false;
                showAppMenu(a);
                return true;
            }
        });
    }

    private View headingView(Row r) {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(0, dp(12), 0, dp(4));
        TextView t = new TextView(this);
        t.setTypeface(bebas);
        t.setTextSize(40f);
        t.setTextColor(RED);
        t.setIncludeFontPadding(false);
        t.setText(r.letterIdx == 0 ? "#" : String.valueOf((char) ('A' + r.letterIdx - 1)));
        h.addView(t, new LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.WRAP_CONTENT));
        View line = new View(this);
        line.setBackgroundColor(INK);
        h.addView(line, new LinearLayout.LayoutParams(0, dp(1.5f), 1f));
        return h;
    }

    private View textRowView(AppEntry a) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(query.length() > 0 ? dp(4) : dp(44), dp(9), dp(4), dp(7));
        TextView name = makeLabel(21f, 1, Gravity.START);
        name.setText(a.label.toUpperCase(Locale.getDefault()));
        row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(makeDash(14));
        box.addView(row);
        box.addView(makeHair());
        wireEntry(box, a);
        return box;
    }

    private Drawable styledIcon(AppEntry a) {
        String key = a.component.flattenToString();
        Bitmap b = iconCache.get(key);
        if (b == null) {
            try {
                Drawable d = getPackageManager().getActivityIcon(a.component);
                b = IconStyler.style(d, INK, CREAM, RED);
                if (mostlyBlank(b)) b = IconStyler.letterTile(a.label, INK, CREAM, RED, bebas);
            } catch (Throwable t) {
                b = IconStyler.letterTile(a.label, INK, CREAM, RED, bebas);
            }
            iconCache.put(key, b);
        }
        BitmapDrawable bd = new BitmapDrawable(getResources(), b);
        bd.setFilterBitmap(false);
        return bd;
    }

    /** True when the styled icon came out (almost) empty, e.g. an app whose icon has no usable shape. */
    private boolean mostlyBlank(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight(), ink = 0, tot = 0;
        for (int y = 0; y < h; y += 2) {
            for (int x = 0; x < w; x += 2) {
                tot++;
                if (b.getPixel(x, y) != CREAM) ink++;
            }
        }
        return tot > 0 && ink * 100 < tot * 2;
    }

    private View iconFrame(AppEntry a, int sizeDp) {
        FrameLayout wrap = new FrameLayout(this);
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(INK);
        f.setPadding(dp(1.5f), dp(1.5f), dp(1.5f), dp(1.5f));
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        iv.setImageDrawable(styledIcon(a));
        f.addView(iv, new FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        // fixed size, centred: otherwise the dark border fills the whole cell width
        wrap.addView(f, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL));
        return wrap;
    }

    private View iconRowView(AppEntry[] cells) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));
        for (int i = 0; i < 3; i++) {
            if (i >= cells.length) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
                continue;
            }
            AppEntry a = cells[i];
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(3), dp(2), dp(3), dp(2));
            cell.addView(iconFrame(a, 56));
            TextView name = makeLabel(14f, 2, Gravity.CENTER);
            name.setLineSpacing(0f, 0.95f);
            name.setText(a.label.toUpperCase(Locale.getDefault()));
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            np.topMargin = dp(5);
            cell.addView(name, np);
            LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(dp(16), dp(2));
            dp2.topMargin = dp(4);
            View dash = new View(this);
            dash.setBackgroundColor(RED);
            cell.addView(dash, dp2);
            wireEntry(cell, a);
            row.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        return row;
    }

    private View recentRowView(AppEntry[] cells) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(2), 0, dp(6));
        TextView tag = new TextView(this);
        tag.setTypeface(roboto);
        tag.setTextSize(8f);
        tag.setLetterSpacing(0.3f);
        tag.setTextColor((INK & 0x00FFFFFF) | 0xA0000000);
        tag.setText("RECENT");
        box.addView(tag);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(5);
        for (int i = 0; i < 4; i++) {
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            cp.leftMargin = i == 0 ? 0 : dp(6);
            if (i >= cells.length) {
                row.addView(new View(this), cp);
                continue;
            }
            AppEntry a = cells[i];
            View chip;
            if (iconMode) {
                LinearLayout cellBox = new LinearLayout(this);
                cellBox.setOrientation(LinearLayout.VERTICAL);
                cellBox.setGravity(Gravity.CENTER_HORIZONTAL);
                cellBox.addView(iconFrame(a, 50));
                TextView nm = makeLabel(11f, 1, Gravity.CENTER);
                nm.setText(a.label.toUpperCase(Locale.getDefault()));
                LinearLayout.LayoutParams nmp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                nmp.topMargin = dp(3);
                cellBox.addView(nm, nmp);
                chip = cellBox;
            } else {
                TextView t = makeLabel(15f, 1, Gravity.CENTER);
                t.setText(a.label.toUpperCase(Locale.getDefault()));
                t.setPadding(dp(2), dp(8), dp(2), dp(6));
                GradientDrawable gd = new GradientDrawable();
                gd.setColor(Color.TRANSPARENT);
                gd.setStroke(dp(1.5f), INK);
                t.setBackground(gd);
                chip = t;
            }
            wireEntry(chip, a);
            row.addView(chip, cp);
        }
        box.addView(row, rp);
        return box;
    }

    private void buildDrawer() {
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(CREAM);
        drawer.setClickable(true);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.BOTTOM);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleView = new TextView(this);
        titleView.setTypeface(bebas);
        titleView.setTextSize(52f);
        titleView.setTextColor(INK);
        titleView.setLetterSpacing(0.03f);
        titleView.setIncludeFontPadding(false);
        titleBox.addView(titleView);
        countView = new TextView(this);
        countView.setTypeface(roboto);
        countView.setTextSize(10f);
        countView.setTextColor(RED);
        countView.setLetterSpacing(0.3f);
        titleBox.addView(countView);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // text list or icon grid: one tap switches and the choice is remembered
        modeView = new TextView(this);
        modeView.setTypeface(bebas);
        modeView.setTextSize(16f);
        modeView.setLetterSpacing(0.08f);
        modeView.setTextColor(INK);
        modeView.setPadding(dp(10), dp(12), dp(6), dp(8));
        modeView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconMode = !iconMode;
                getSharedPreferences("horizon", MODE_PRIVATE).edit().putBoolean("drawer_icons", iconMode).apply();
                refreshDrawerList(false);
            }
        });
        header.addView(modeView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView close = new TextView(this);
        close.setText("CLOSE");
        close.setTypeface(bebas);
        close.setTextSize(24f);
        close.setTextColor(RED);
        close.setLetterSpacing(0.1f);
        close.setPadding(dp(10), dp(12), 0, dp(6));
        closeView = close;
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });
        header.addView(close, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        drawer.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View rule = new View(this);
        rule.setBackgroundColor(INK);
        ruleView = rule;
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(2));
        rp.topMargin = dp(10);
        rp.bottomMargin = dp(6);
        drawer.addView(rule, rp);

        // the list sits in a frame so the A-Z strip can float on its right edge
        FrameLayout listFrame = new FrameLayout(this);
        gridFrameView = listFrame;
        grid = new ListView(this);
        grid.setDivider(null);
        grid.setDividerHeight(0);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setVerticalScrollBarEnabled(false);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        grid.setBackgroundColor(Color.TRANSPARENT);
        grid.setCacheColorHint(Color.TRANSPARENT);
        // rows soften at the top and bottom edge instead of being cut in half, and the last rows can scroll fully clear
        grid.setClipToPadding(false);
        grid.setPadding(0, 0, 0, dp(26));
        grid.setVerticalFadingEdgeEnabled(true);
        grid.setFadingEdgeLength(dp(26));
        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return rows.size();
            }

            @Override
            public Object getItem(int position) {
                return rows.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                Row r = rows.get(position);
                if (r.type == 0) return headingView(r);
                if (r.type == 1) return textRowView(r.cells[0]);
                if (r.type == 2) return iconRowView(r.cells);
                return recentRowView(r.cells);
            }
        };
        grid.setAdapter(adapter);
        grid.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) { }

            @Override
            public void onScroll(AbsListView view, int first, int visible, int total) {
                int idx = -1;
                // the section that fills most of the screen counts: when the top row is mostly scrolled away, use the next one
                View top = view.getChildAt(0);
                if (top != null && visible > 1 && top.getBottom() < top.getHeight() * 0.6f) first++;
                for (int i = Math.min(first, rows.size() - 1); i >= 0; i--) {
                    if (rows.get(i).type == 0) {
                        idx = rows.get(i).letterIdx;
                        break;
                    }
                }
                if (idx < 0 && first + 1 < rows.size() && rows.get(first + 1).type == 0) idx = rows.get(first + 1).letterIdx;
                markRail(idx);
            }
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.rightMargin = dp(22);
        listFrame.addView(grid, lp);

        rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < 27; i++) {
            TextView t = new TextView(this);
            t.setTypeface(bebas);
            t.setTextSize(11f);
            t.setGravity(Gravity.CENTER);
            t.setIncludeFontPadding(false);
            t.setText(i == 0 ? "#" : String.valueOf((char) ('A' + i - 1)));
            railViews[i] = t;
            rail.addView(t, new LinearLayout.LayoutParams(dp(20), 0, 1f));
        }
        rail.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int act = e.getActionMasked();
                if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_MOVE) {
                    int idx = (int) (e.getY() / Math.max(1f, rail.getHeight() / 27f));
                    scrollToLetter(Math.max(0, Math.min(26, idx)));
                }
                return true;
            }
        });
        FrameLayout.LayoutParams rl = new FrameLayout.LayoutParams(dp(20), ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.END);
        rl.topMargin = dp(4);
        rl.bottomMargin = dp(4);
        listFrame.addView(rail, rl);
        drawer.addView(listFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // search bar at the bottom
        searchFrame = new LinearLayout(this);
        searchFrame.setOrientation(LinearLayout.HORIZONTAL);
        searchFrame.setGravity(Gravity.CENTER_VERTICAL);
        searchBox = new EditText(this);
        searchBox.setBackground(null);
        searchBox.setTypeface(bebas);
        searchBox.setTextSize(20f);
        searchBox.setLetterSpacing(0.12f);
        searchBox.setHint("SEARCH APPS");
        searchBox.setSingleLine(true);
        searchBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        searchBox.setPadding(dp(14), dp(8), dp(8), dp(8));
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) { }

            @Override
            public void afterTextChanged(Editable s) {
                String q = s.toString();
                if (q.equals(query)) return;
                query = q;
                refreshDrawerList(true);
            }
        });
        searchBox.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent ev) {
                // Enter opens the first match
                for (Row r : rows) {
                    if ((r.type == 1 || r.type == 2) && r.cells.length > 0 && r.cells[0].component != null) {
                        onEntryClicked(r.cells[0]);
                        return true;
                    }
                }
                return true;
            }
        });
        searchFrame.addView(searchBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        searchDash = makeDash(20);
        LinearLayout.LayoutParams sdp = new LinearLayout.LayoutParams(dp(20), dp(2));
        sdp.rightMargin = dp(14);
        searchFrame.addView(searchDash, sdp);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(8);
        drawer.addView(searchFrame, sp);
        iconMode = getSharedPreferences("horizon", MODE_PRIVATE).getBoolean("drawer_icons", false);
        styleSearch();
    }

    private void styleSearch() {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor((CREAM & 0x00FFFFFF) | 0x99000000);
        gd.setStroke(dp(2), INK);
        searchFrame.setBackground(gd);
        searchBox.setTextColor(INK);
        searchBox.setHintTextColor((INK & 0x00FFFFFF) | 0x80000000);
        searchBox.setHighlightColor((RED & 0x00FFFFFF) | 0x55000000);
        searchDash.setBackgroundColor(RED);
        modeView.setTextColor(INK);
        modeView.setText(iconMode ? "VIEW: ICONS" : "VIEW: TEXT");
    }

    private int letterIndexOf(String label) {
        if (label == null || label.length() == 0) return 0;
        char ch = Character.toUpperCase(label.charAt(0));
        return (ch >= 'A' && ch <= 'Z') ? ch - 'A' + 1 : 0;
    }

    private void addAppRows(List<AppEntry> list) {
        if (!iconMode) {
            for (AppEntry a : list) {
                Row r = new Row();
                r.type = 1;
                r.cells = new AppEntry[]{a};
                rows.add(r);
            }
            return;
        }
        for (int i = 0; i < list.size(); i += 3) {
            Row r = new Row();
            r.type = 2;
            int n = Math.min(3, list.size() - i);
            r.cells = new AppEntry[n];
            for (int k = 0; k < n; k++) r.cells[k] = list.get(i + k);
            rows.add(r);
        }
    }

    private List<AppEntry> recentApps() {
        List<AppEntry> out = new ArrayList<AppEntry>();
        String s = getSharedPreferences("horizon", MODE_PRIVATE).getString("recent", "");
        if (s.length() == 0) return out;
        for (String part : s.split(",")) {
            for (AppEntry a : apps) {
                if (a.component != null && a.component.flattenToString().equals(part)) {
                    out.add(a);
                    break;
                }
            }
            if (out.size() >= 4) break;
        }
        return out;
    }

    private void pushRecent(ComponentName c) {
        SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        String mine = c.flattenToString();
        StringBuilder sb = new StringBuilder(mine);
        int n = 1;
        for (String part : sp.getString("recent", "").split(",")) {
            if (part.length() == 0 || part.equals(mine)) continue;
            sb.append(',').append(part);
            if (++n >= 6) break;
        }
        sp.edit().putString("recent", sb.toString()).apply();
    }

    /** Rebuilds the rows from the app list, the search text and the text / icon choice. */
    private void buildRows() {
        rows.clear();
        java.util.Arrays.fill(letterRow, -1);
        String q = query.trim().toLowerCase(Locale.getDefault());
        List<AppEntry> list = new ArrayList<AppEntry>();
        AppEntry reset = null;
        for (AppEntry e : shown) {
            if (e.component == null) {
                reset = e;
                continue;
            }
            if (q.length() == 0 || e.label.toLowerCase(Locale.getDefault()).contains(q)) list.add(e);
        }
        if (reset != null && q.length() == 0) {
            Row r = new Row();
            r.type = 1;
            r.cells = new AppEntry[]{reset};
            rows.add(r);
        }
        if (q.length() > 0) {
            addAppRows(list);
            return;
        }
        if (pickTarget < 0) {
            List<AppEntry> rec = recentApps();
            if (!rec.isEmpty()) {
                Row r = new Row();
                r.type = 3;
                r.cells = rec.toArray(new AppEntry[0]);
                rows.add(r);
            }
        }
        int cur = -1;
        List<AppEntry> group = new ArrayList<AppEntry>();
        for (AppEntry a : list) {
            int li = letterIndexOf(a.label);
            if (li != cur) {
                addAppRows(group);
                group.clear();
                cur = li;
                Row h = new Row();
                h.type = 0;
                h.letterIdx = li;
                letterRow[li] = rows.size();
                rows.add(h);
            }
            group.add(a);
        }
        addAppRows(group);
    }

    private void refreshDrawerList(boolean toTop) {
        buildRows();
        styleSearch();
        adapter.notifyDataSetChanged();
        rail.setVisibility(query.trim().length() > 0 ? View.INVISIBLE : View.VISIBLE);
        if (toTop) grid.setSelection(0);
        markRail(-1);
    }

    private void markRail(int idx) {
        railCurrent = idx;
        for (int i = 0; i < 27; i++) {
            TextView t = railViews[i];
            if (t == null) continue;
            boolean has = letterRow[i] >= 0;
            if (i == idx) {
                t.setTextColor(CREAM);
                t.setBackgroundColor(RED);
            } else {
                t.setTextColor(has ? INK : (INK & 0x00FFFFFF) | 0x50000000);
                t.setBackgroundColor(Color.TRANSPARENT);
            }
        }
    }

    private void scrollToLetter(int idx) {
        int target = -1;
        for (int i = idx; i < 27; i++) {
            if (letterRow[i] >= 0) {
                target = i;
                break;
            }
        }
        if (target < 0) {
            for (int i = idx; i >= 0; i--) {
                if (letterRow[i] >= 0) {
                    target = i;
                    break;
                }
            }
        }
        if (target >= 0) {
            grid.setSelectionFromTop(letterRow[target], 0);
            markRail(target);
        }
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        for (ResolveInfo r : found) {
            if (r.activityInfo == null) continue;
            if (getPackageName().equals(r.activityInfo.packageName)) continue;
            AppEntry a = new AppEntry();
            a.label = String.valueOf(r.loadLabel(pm));
            a.component = new ComponentName(r.activityInfo.packageName, r.activityInfo.name);
            apps.add(a);
        }
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry x, AppEntry y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });
        shown.clear();
        if (pickTarget >= 0) {
            AppEntry reset = new AppEntry();
            reset.label = "DEFAULT";
            reset.component = null;
            shown.add(reset);
        }
        shown.addAll(apps);
        if (pickTarget >= 0) {
            titleView.setText("CHOOSE APP");
            countView.setText("FOR: " + TARGET_NAMES[pickTarget]);
        } else {
            titleView.setText("ALL APPS");
            countView.setText(apps.size() + " APPS");
        }
        refreshDrawerList(false);
    }

    private void onEntryClicked(AppEntry a) {
        if (pickTarget >= 0) {
            poster.setCustom(pickTarget, a.component, a.component == null ? null : a.label);
            closeDrawer();
            return;
        }
        if (a.component == null) return;
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(a.component);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
            pushRecent(a.component);
        } catch (Exception ignored) { }
        closeDrawer();
    }

    // ---------- long-press menu (app shortcuts + app info) ----------

    private List<ShortcutInfo> loadShortcuts(String pkg) {
        List<ShortcutInfo> out = new ArrayList<ShortcutInfo>();
        try {
            LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
            if (la != null && la.hasShortcutHostPermission()) {
                LauncherApps.ShortcutQuery q = new LauncherApps.ShortcutQuery();
                q.setPackage(pkg);
                q.setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC
                        | LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST
                        | LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED);
                List<ShortcutInfo> l = la.getShortcuts(q, Process.myUserHandle());
                if (l != null) {
                    for (ShortcutInfo si : l) {
                        if (si.isEnabled() && si.getShortLabel() != null && out.size() < 6) out.add(si);
                    }
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    private boolean hasShortcutAccess() {
        try {
            LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
            return la != null && la.hasShortcutHostPermission();
        } catch (Exception e) {
            return false;
        }
    }

    private void addMenuRow(LinearLayout box, String label, final Dialog d, final Runnable action) {
        View line = new View(this);
        line.setBackgroundColor(Color.parseColor("#33000000"));
        box.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        TextView row = new TextView(this);
        row.setText(label.toUpperCase(Locale.getDefault()));
        row.setTypeface(bebas);
        row.setTextSize(22f);
        row.setTextColor(INK);
        row.setLetterSpacing(0.06f);
        row.setSingleLine(true);
        row.setEllipsize(TextUtils.TruncateAt.END);
        row.setPadding(0, dp(12), 0, dp(12));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                try {
                    action.run();
                } catch (Exception ignored) { }
            }
        });
        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void showAppMenu(final AppEntry a) {
        refreshTheme();
        final String pkg = a.component.getPackageName();
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CREAM);
        bg.setStroke(dp(2), INK);
        box.setBackground(bg);
        box.setPadding(dp(22), dp(16), dp(22), dp(12));

        TextView head = new TextView(this);
        head.setText(a.label.toUpperCase(Locale.getDefault()));
        head.setTypeface(bebas);
        head.setTextSize(32f);
        head.setTextColor(INK);
        head.setLetterSpacing(0.04f);
        head.setSingleLine(true);
        head.setEllipsize(TextUtils.TruncateAt.END);
        box.addView(head);
        View bar = new View(this);
        bar.setBackgroundColor(RED);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(30), dp(2));
        bp.topMargin = dp(4);
        bp.bottomMargin = dp(6);
        box.addView(bar, bp);

        addMenuRow(box, "OPEN", d, new Runnable() {
            @Override
            public void run() {
                onEntryClicked(a);
            }
        });

        final LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
        for (final ShortcutInfo si : loadShortcuts(pkg)) {
            addMenuRow(box, String.valueOf(si.getShortLabel()), d, new Runnable() {
                @Override
                public void run() {
                    closeDrawer();
                    la.startShortcut(si, null, null);
                }
            });
        }

        addMenuRow(box, "APP INFO / UNINSTALL", d, new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        });

        if (!hasShortcutAccess()) {
            TextView note = new TextView(this);
            note.setText("TO SEE APP SHORTCUTS, SET HORIZON LAUNCHER AS YOUR DEFAULT HOME APP");
            note.setTypeface(roboto);
            note.setTextSize(8f);
            note.setTextColor(RED);
            note.setLetterSpacing(0.12f);
            note.setPadding(0, dp(8), 0, dp(2));
            box.addView(note);
        }

        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.84f),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    // ---------- style menu (hold the scene for two seconds) ----------

    private Dialog newMenu(String title, String sub, LinearLayout[] boxOut) {
        refreshTheme();
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CREAM);
        bg.setStroke(dp(2), INK);
        outer.setBackground(bg);
        outer.setPadding(dp(22), dp(16), dp(22), dp(12));

        TextView head = new TextView(this);
        head.setText(title);
        head.setTypeface(bebas);
        head.setTextSize(32f);
        head.setTextColor(INK);
        head.setLetterSpacing(0.04f);
        head.setSingleLine(true);
        outer.addView(head);
        View bar = new View(this);
        bar.setBackgroundColor(RED);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(30), dp(2));
        bp.topMargin = dp(4);
        bp.bottomMargin = dp(4);
        outer.addView(bar, bp);
        if (sub != null) {
            TextView st = new TextView(this);
            st.setText(sub);
            st.setTypeface(roboto);
            st.setTextSize(8f);
            st.setTextColor(RED);
            st.setLetterSpacing(0.12f);
            st.setPadding(0, 0, 0, dp(4));
            outer.addView(st);
        }
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        outer.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        boxOut[0] = box;

        d.setContentView(outer);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.86f),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        return d;
    }

    private void addNote(LinearLayout box, String text) {
        TextView note = new TextView(this);
        note.setText(text);
        note.setTypeface(roboto);
        note.setTextSize(8f);
        note.setTextColor(RED);
        note.setLetterSpacing(0.12f);
        note.setPadding(0, dp(8), 0, dp(2));
        box.addView(note);
    }

    private static String shortName(Palette p) {
        int i = p.name.indexOf('•');
        return (i > 0 ? p.name.substring(0, i) : p.name).trim();
    }

    /** Applies the change, then opens the style menu again so several things can be changed in a row. */
    private void styleChanged() {
        poster.refreshLook();
        poster.post(new Runnable() {
            @Override
            public void run() {
                updateWallpapers();
                openStyleMenu();
            }
        });
    }

    @Override
    public void openStyleMenu() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        final Look look = poster.look();
        final ContentPack pk = poster.pack();
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("STYLE", null, hb);
        LinearLayout box = hb[0];

        String palPref = sp.getString("pal", "AUTO");
        String palShown = "AUTO".equals(palPref) ? "NEW EACH DAY (" + shortName(look.pal) + " TODAY)" : shortName(Palette.byId(palPref));
        addMenuRow(box, "COLOUR SCHEME: " + palShown, d, new Runnable() {
            @Override
            public void run() {
                chooseScheme();
            }
        });
        String sc = sp.getString("scene", "AUTO");
        String scName = "NEW EACH DAY";
        if (!"AUTO".equals(sc)) {
            for (String[] s : Look.allScenes(pk)) {
                if (s[0].equals(sc)) scName = s[1];
            }
        }
        addMenuRow(box, "WALLPAPER: " + scName, d, new Runnable() {
            @Override
            public void run() {
                chooseScene();
            }
        });
        addMenuRow(box, "SKY PLACE: " + Loc.name(this).toUpperCase(Locale.getDefault())
                + (Loc.auto(this) ? " (AUTO)" : ""), d, new Runnable() {
            @Override
            public void run() {
                chooseLocation();
            }
        });
        final boolean festOn = sp.getBoolean("fest", true);
        addMenuRow(box, "FESTIVAL THEMES: " + (festOn ? "ON" : "OFF"), d, new Runnable() {
            @Override
            public void run() {
                sp.edit().putBoolean("fest", !festOn).apply();
                styleChanged();
            }
        });
        final boolean lockOn = sp.getBoolean("lock_auto", true);
        addMenuRow(box, "LOCK SCREEN: " + (lockOn ? "MATCHES HOME" : "LEAVE ALONE"), d, new Runnable() {
            @Override
            public void run() {
                sp.edit().putBoolean("lock_auto", !lockOn).apply();
                styleChanged();
            }
        });
        addMenuRow(box, "PREVIEW A FESTIVAL", d, new Runnable() {
            @Override
            public void run() {
                choosePreview();
            }
        });
        if (look.previewUntil > 0) {
            addMenuRow(box, "STOP PREVIEW", d, new Runnable() {
                @Override
                public void run() {
                    sp.edit().remove("pv_name").remove("pv_until").apply();
                    styleChanged();
                }
            });
        }
        addMenuRow(box, "IMPORT CONTENT PACK", d, new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_PACK);
                } catch (Exception e) {
                    Toast.makeText(HomeActivity.this, "NO FILE PICKER FOUND", Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (!pk.isEmpty()) {
            addMenuRow(box, "REMOVE IMPORTED PACK", d, new Runnable() {
                @Override
                public void run() {
                    ContentPack.reset(HomeActivity.this);
                    sp.edit().remove("scene").apply();
                    poster.reloadPack();
                    styleChanged();
                    Toast.makeText(HomeActivity.this, "PACK REMOVED", Toast.LENGTH_SHORT).show();
                }
            });
            addNote(box, "PACK: " + (pk.name().length() > 0 ? pk.name().toUpperCase(Locale.getDefault()) + " • " : "") + pk.summary());
        }
        if (look.fest != null) addNote(box, "TODAY: " + look.fest.name + " • FESTIVAL COLOURS ARE ON");
        addMenuRow(box, "DONE", d, new Runnable() {
            @Override
            public void run() { }
        });
        d.show();
    }

    private void chooseScheme() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("COLOUR SCHEME", "THE WHOLE SCREEN FOLLOWS THE SKY IN THESE COLOURS", hb);
        String cur = sp.getString("pal", "AUTO");
        addMenuRow(hb[0], ("AUTO".equals(cur) ? "> " : "") + "NEW COLOUR EACH DAY", d, new Runnable() {
            @Override
            public void run() {
                sp.edit().putString("pal", "AUTO").apply();
                styleChanged();
            }
        });
        for (final Palette p : Palette.USER) {
            addMenuRow(hb[0], (p.id.equals(cur) ? "> " : "") + p.name, d, new Runnable() {
                @Override
                public void run() {
                    sp.edit().putString("pal", p.id).apply();
                    styleChanged();
                }
            });
        }
        d.show();
    }

    private void chooseScene() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("WALLPAPER", "THE SCENE IN THE MIDDLE OF THE POSTER", hb);
        String cur = sp.getString("scene", "AUTO");
        addMenuRow(hb[0], ("AUTO".equals(cur) ? "> " : "") + "NEW EACH DAY", d, new Runnable() {
            @Override
            public void run() {
                sp.edit().putString("scene", "AUTO").apply();
                styleChanged();
            }
        });
        for (final String[] s : Look.allScenes(poster.pack())) {
            addMenuRow(hb[0], (s[0].equals(cur) ? "> " : "") + s[1], d, new Runnable() {
                @Override
                public void run() {
                    sp.edit().putString("scene", s[0]).apply();
                    styleChanged();
                }
            });
        }
        d.show();
    }

    /** Where the sun and moon are drawn for: a city picked by hand, or the phone's own last known place. */
    private void chooseLocation() {
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("SKY PLACE", "SUNRISE, SUNSET, SUN AND MOON POSITIONS AND WEATHER USE THIS PLACE", hb);
        final boolean auto = Loc.auto(this);
        addMenuRow(hb[0], "USE PHONE LOCATION: " + (auto ? "ON" : "OFF"), d, new Runnable() {
            @Override
            public void run() {
                if (auto) {
                    Loc.setAuto(HomeActivity.this, false);
                    styleChanged();
                } else if (Loc.hasPermission(HomeActivity.this)) {
                    Loc.setAuto(HomeActivity.this, true);
                    styleChanged();
                } else {
                    requestPermissions(new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
                }
            }
        });
        String cur = Loc.name(this);
        for (int i = 0; i < Loc.CITIES.length; i++) {
            final int idx = i;
            final String nm = (String) Loc.CITIES[i][0];
            addMenuRow(hb[0], (!auto && nm.equals(cur) ? "> " : "") + nm.toUpperCase(Locale.getDefault()), d, new Runnable() {
                @Override
                public void run() {
                    Loc.choose(HomeActivity.this, idx);
                    styleChanged();
                }
            });
        }
        d.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOC) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Loc.setAuto(this, true);
                styleChanged();
                Toast.makeText(this, "USING PHONE LOCATION", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "LOCATION NOT ALLOWED: PICK A CITY INSTEAD", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void choosePreview() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        LinearLayout[] hb = new LinearLayout[1];
        final Dialog d = newMenu("PREVIEW", "SHOWS THE FESTIVAL LOOK FOR FIVE MINUTES", hb);
        for (final String n : Look.PREVIEW_NAMES) {
            addMenuRow(hb[0], n, d, new Runnable() {
                @Override
                public void run() {
                    sp.edit().putString("pv_name", n)
                            .putLong("pv_until", System.currentTimeMillis() + 5L * 60L * 1000L).apply();
                    styleChanged();
                }
            });
        }
        d.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PACK || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String msg = ContentPack.importFrom(HomeActivity.this, uri);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        poster.reloadPack();
                        styleChanged();
                        Toast.makeText(HomeActivity.this, msg, Toast.LENGTH_LONG).show();
                    }
                });
            }
        }).start();
    }

    private void applyDrawerTheme() {
        refreshTheme();
        drawer.setBackgroundColor(CREAM);
        root.setBackgroundColor(CREAM);
        titleView.setTextColor(INK);
        countView.setTextColor(RED);
        closeView.setTextColor(RED);
        ruleView.setBackgroundColor(INK);
        int sig = INK * 31 + CREAM * 17 + RED;
        if (sig != iconSig) {
            iconSig = sig;
            iconCache.clear();   // icons are drawn in today's ink, paper and red
        }
        gridFrameView.setBackgroundColor(Color.TRANSPARENT);
        grid.setBackgroundColor(Color.TRANSPARENT);
        styleSearch();
    }

    @Override
    public void openNotifications() {
        boolean ok = false;
        try {
            Object sb = getSystemService("statusbar");
            Class<?> cls = Class.forName("android.app.StatusBarManager");
            java.lang.reflect.Method m;
            try {
                m = cls.getMethod("expandNotificationsPanel");
            } catch (NoSuchMethodException e) {
                m = cls.getMethod("expand");
            }
            m.invoke(sb);
            ok = true;
        } catch (Throwable ignored) { }
        if (!ok) {
            android.widget.Toast.makeText(this, "PULL DOWN FROM THE VERY TOP EDGE FOR NOTIFICATIONS",
                    android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void openDrawer() {
        applyDrawerTheme();
        pickTarget = -1;
        resetSearch();
        loadApps();
        grid.setSelection(0);
        drawer.setVisibility(View.VISIBLE);
    }

    @Override
    public void pickApp(int target) {
        if (target < 0 || target >= TARGET_NAMES.length) return;
        applyDrawerTheme();
        pickTarget = target;
        resetSearch();
        loadApps();
        grid.setSelection(0);
        drawer.setVisibility(View.VISIBLE);
    }

    private void resetSearch() {
        query = "";
        searchBox.setText("");
        searchBox.clearFocus();
    }

    private void closeDrawer() {
        pickTarget = -1;
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        } catch (Exception ignored) { }
        resetSearch();
        drawer.setVisibility(View.GONE);
    }
}
