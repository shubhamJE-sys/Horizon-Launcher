package com.horizon.launcher;

import android.content.Context;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Imported sky themes. Each lives in its own folder (files/themes/id), apart from the built-in Classic and
 * New painted looks, which are never touched by an import. A zip holds any of: sky_sunny, sky_winter, sky_hot,
 * sky_dawn, sky_dusk, sky_overcast, sky_night, sun (png / webp / jpg) and an optional theme.json with a name.
 */
final class ThemePack {
    static final String[] PARTS = {"sky_sunny", "sky_winter", "sky_hot", "sky_dawn", "sky_dusk", "sky_overcast", "sky_night", "sun"};

    static File root(Context c) {
        File f = new File(c.getFilesDir(), "themes");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    static File dir(Context c, String id) {
        return new File(root(c), id);
    }

    /** Ids of the imported themes, sorted by name. */
    static ArrayList<String> list(Context c) {
        ArrayList<String> out = new ArrayList<String>();
        File[] fs = root(c).listFiles();
        if (fs != null) {
            for (File f : fs) if (f.isDirectory()) out.add(f.getName());
        }
        java.util.Collections.sort(out);
        return out;
    }

    static String displayName(Context c, String id) {
        try {
            File f = new File(dir(c, id), "name.txt");
            if (f.exists()) {
                java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(f));
                String s = r.readLine();
                r.close();
                if (s != null && s.trim().length() > 0) return s.trim();
            }
        } catch (Exception ignored) {
        }
        return id;
    }

    static void remove(Context c, String id) {
        File d = dir(c, id);
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        d.delete();
    }

    private static String clean(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toLowerCase(Locale.US).toCharArray()) {
            if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) b.append(ch);
            else if (b.length() > 0 && b.charAt(b.length() - 1) != '_') b.append('_');
        }
        String r = b.toString();
        while (r.endsWith("_")) r = r.substring(0, r.length() - 1);
        return r.length() > 30 ? r.substring(0, 30) : r;
    }

    private static String partOf(String entry) {
        String n = entry.replace('\\', '/');
        int s = n.lastIndexOf('/');
        if (s >= 0) n = n.substring(s + 1);
        String low = n.toLowerCase(Locale.US);
        int dot = low.lastIndexOf('.');
        if (dot < 0) return null;
        String ext = low.substring(dot + 1);
        if (!(ext.equals("png") || ext.equals("webp") || ext.equals("jpg") || ext.equals("jpeg"))) return null;
        String base = low.substring(0, dot);
        for (String p : PARTS) if (p.equals(base)) return p + "." + ext;
        return null;
    }

    /** Imports a zip. Returns a message for the user; the built-in looks are never replaced. */
    static String importFrom(Context c, Uri uri) {
        try {
            File tmp = new File(root(c), "_incoming");
            File[] old = tmp.listFiles();
            if (old != null) for (File f : old) f.delete();
            tmp.mkdirs();
            String name = null;
            int n = 0;
            InputStream in = c.getContentResolver().openInputStream(uri);
            ZipInputStream z = new ZipInputStream(in);
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                String ename = e.getName().replace('\\', '/');
                String base = ename.substring(ename.lastIndexOf('/') + 1).toLowerCase(Locale.US);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int r;
                long tot = 0;
                while ((r = z.read(buf)) > 0) {
                    tot += r;
                    if (tot > 14L * 1024 * 1024) break;
                    bo.write(buf, 0, r);
                }
                if (tot > 14L * 1024 * 1024) continue;
                if (base.equals("theme.json")) {
                    String js = bo.toString("UTF-8");
                    int k = js.indexOf("\"name\"");
                    if (k >= 0) {
                        int a = js.indexOf('"', js.indexOf(':', k) + 1);
                        int b = a < 0 ? -1 : js.indexOf('"', a + 1);
                        if (a >= 0 && b > a) name = js.substring(a + 1, b);
                    }
                    continue;
                }
                String part = partOf(ename);
                if (part == null) continue;
                FileOutputStream fo = new FileOutputStream(new File(tmp, part));
                fo.write(bo.toByteArray());
                fo.close();
                n++;
            }
            z.close();
            if (n == 0) return "NO THEME PICTURES FOUND IN THAT ZIP";
            if (name == null || name.trim().length() == 0) name = "IMPORTED THEME";
            name = name.trim();
            String id = clean(name);
            if (id.length() == 0 || id.equals("classic") || id.equals("new") || id.equals("new_painted")) {
                name = name + " (imported)";
                id = clean(name);
            }
            File dest = dir(c, id);
            if (dest.exists()) remove(c, id);   // same imported name: update that imported theme only
            dest.mkdirs();
            File[] fs = tmp.listFiles();
            if (fs != null) for (File f : fs) f.renameTo(new File(dest, f.getName()));
            tmp.delete();
            java.io.FileWriter w = new java.io.FileWriter(new File(dest, "name.txt"));
            w.write(name);
            w.close();
            return "THEME ADDED: " + name.toUpperCase(Locale.US) + " (" + n + " PICTURES)";
        } catch (Exception ex) {
            return "COULD NOT READ THAT ZIP";
        }
    }
}
