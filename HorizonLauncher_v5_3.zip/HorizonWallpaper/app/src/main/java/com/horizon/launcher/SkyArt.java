package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import java.io.InputStream;

/**
 * The painted sky layers (winter, overcast, dusk, dawn, night, sunny, hot) shared by every scene.
 * They are cross-faded by time of day, rain / cloud and temperature.
 */
final class SkyArt {
    static final String[] FILES = {"sky_sunny", "sky_winter", "sky_hot", "sky_dawn", "sky_dusk", "sky_overcast", "sky_night"};
    static final int SUNNY = 0, WINTER = 1, HOT = 2, DAWN = 3, DUSK = 4, OVER = 5, NIGHT = 6;

    /** Sampled colours (top, upper, lower, horizon) of each image, for text contrast. */
    static final int[][] COLS = {
            {Color.rgb(0, 47, 145), Color.rgb(5, 78, 173), Color.rgb(79, 153, 211), Color.rgb(246, 229, 183)},
            {Color.rgb(92, 126, 159), Color.rgb(123, 157, 188), Color.rgb(170, 191, 210), Color.rgb(241, 235, 220)},
            {Color.rgb(7, 90, 174), Color.rgb(49, 131, 200), Color.rgb(148, 188, 209), Color.rgb(251, 229, 172)},
            {Color.rgb(46, 23, 108), Color.rgb(83, 49, 140), Color.rgb(198, 110, 139), Color.rgb(252, 206, 115)},
            {Color.rgb(3, 22, 97), Color.rgb(31, 36, 131), Color.rgb(169, 55, 114), Color.rgb(251, 137, 56)},
            {Color.rgb(29, 42, 55), Color.rgb(50, 64, 77), Color.rgb(91, 102, 112), Color.rgb(178, 181, 184)},
            {Color.rgb(0, 4, 28), Color.rgb(0, 8, 42), Color.rgb(4, 28, 76), Color.rgb(51, 89, 144)},
    };

    static volatile float tempC = Float.NaN;
    static volatile int rain = 0;
    /** True when the NEW theme (painted sky pictures) is chosen; the classic theme is untouched. */
    static volatile boolean enabled = false;
    /** Folder id of an imported theme, or null for the built-in New painted look. */
    static volatile String customId = null;
    private static String loaded = "";
    private static Context app;
    private static final Bitmap[] BMP = new Bitmap[FILES.length];
    private static final Rect SRC = new Rect();

    static void set(float temp, int rainLevel) {
        tempC = temp;
        rain = rainLevel;
    }

    static void init(Context c) {
        if (c == null) return;
        if (app == null) app = c.getApplicationContext();
        try {
            String t = app.getSharedPreferences("horizon", Context.MODE_PRIVATE).getString("theme", "classic");
            enabled = "new".equals(t) || t.startsWith("imp:");
            customId = t.startsWith("imp:") ? t.substring(4) : null;
            if (!loaded.equals(t)) {
                loaded = t;
                for (int i = 0; i < BMP.length; i++) BMP[i] = null;
                sunBmp = null;
                sunTried = false;
            }
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private static float smooth(float a, float b, float v) {
        float t = clamp((v - a) / (b - a));
        return t * t * (3f - 2f * t);
    }

    /** Weights of the seven layers, in FILES order. Layers are painted in this order, each over the last. */
    static float[] weights(float nightK, float twiW, int nowMin, float cloud) {
        float t = Float.isNaN(tempC) ? 24f : tempC;
        float day = 1f - nightK;
        float[] w = new float[FILES.length];
        w[SUNNY] = 1f;
        w[WINTER] = clamp((20f - t) / 4f);
        w[HOT] = clamp((t - 30f) / 4f);
        float tw = smooth(0.15f, 0.9f, twiW);
        w[DAWN] = nowMin < 12 * 60 ? tw : 0f;
        w[DUSK] = nowMin < 12 * 60 ? 0f : tw;
        float over = Math.max(rain > 0 ? 1f : 0f, clamp((cloud - 0.35f) / 0.5f));
        w[OVER] = over * day * (1f - 0.6f * tw);
        w[NIGHT] = smooth(0.1f, 0.8f, nightK);
        return w;
    }

    /** The four sky colours that result from the weights (what the eye sees from the top to the horizon). */
    static int[] mix(float[] w) {
        int[] out = new int[4];
        for (int i = 0; i < 4; i++) {
            int c = COLS[SUNNY][i];
            for (int k = 1; k < FILES.length; k++) c = Sky.blend(c, COLS[k][i], w[k]);
            out[i] = c;
        }
        return out;
    }

    private static Bitmap get(int k) {
        if (BMP[k] != null) return BMP[k];
        if (app == null) return null;
        if (customId != null) {
            Bitmap cb = custom(FILES[k]);
            if (cb != null) {
                BMP[k] = cb;
                return cb;
            }
        }
        try {
            InputStream in = app.getAssets().open(FILES[k] + ".webp");
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            BMP[k] = BitmapFactory.decodeStream(in, null, o);
            in.close();
        } catch (Throwable ignored) {
        }
        return BMP[k];
    }

    private static Bitmap custom(String part) {
        try {
            String[] ext = {".png", ".webp", ".jpg", ".jpeg"};
            for (String e : ext) {
                java.io.File f = new java.io.File(ThemePack.dir(app, customId), part + e);
                if (f.exists()) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inPreferredConfig = part.equals("sun") ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565;
                    return BitmapFactory.decodeFile(f.getPath(), o);
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static Bitmap sunBmp;
    private static boolean sunTried;

    /**
     * The painted sun. An imported theme can bring its own sun picture; otherwise a soft painted disc is drawn:
     * cream centre, gold body, thin orange rim, a very fine horizontal grain like the sky pictures, no rays.
     * alpha 0..255, warm 0..1 (1 = low, orange sun).
     */
    static void drawSun(Canvas c, Paint p, float x, float y, float r, int alpha, float warm) {
        if (customId != null && !sunTried) {
            sunTried = true;
            sunBmp = custom("sun");
        }
        if (sunBmp != null) {
            p.setShader(null);
            p.setAlpha(Math.max(0, Math.min(255, alpha)));
            p.setFilterBitmap(true);
            c.drawBitmap(sunBmp, null, new android.graphics.RectF(x - r, y - r, x + r, y + r), p);
            p.setAlpha(255);
            return;
        }
        int core = Sky.blend(Color.rgb(255, 246, 214), Color.rgb(255, 214, 140), warm);
        int mid = Sky.blend(Color.rgb(255, 214, 96), Color.rgb(255, 160, 60), warm);
        int rim = Sky.blend(Color.rgb(242, 150, 40), Color.rgb(224, 92, 32), warm);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new android.graphics.RadialGradient(x - r * 0.12f, y - r * 0.12f, r * 1.08f,
                new int[]{core, mid, rim}, new float[]{0f, 0.72f, 1f}, android.graphics.Shader.TileMode.CLAMP));
        p.setAlpha(Math.max(0, Math.min(255, alpha)));
        c.drawCircle(x, y, r, p);
        p.setShader(null);
        // fine horizontal grain, clipped to the disc
        c.save();
        android.graphics.Path cp = new android.graphics.Path();
        cp.addCircle(x, y, r, android.graphics.Path.Direction.CW);
        c.clipPath(cp);
        p.setColor(Color.WHITE);
        float step = Math.max(1.2f, r / 14f);
        int i = 0;
        for (float yy = y - r; yy < y + r; yy += step, i++) {
            p.setAlpha(Math.max(0, Math.min(255, (int) (alpha * ((i % 2 == 0) ? 0.10f : 0.03f)))));
            c.drawRect(x - r, yy, x + r, yy + step * 0.45f, p);
        }
        c.restore();
        p.setAlpha(255);
    }

    /** A small four-point sparkle, for the brighter stars of the new sky. */
    static void sparkle(Canvas c, Paint p, float x, float y, float r) {
        android.graphics.Path s = new android.graphics.Path();
        s.moveTo(x, y - r);
        s.quadTo(x, y, x + r, y);
        s.quadTo(x, y, x, y + r);
        s.quadTo(x, y, x - r, y);
        s.quadTo(x, y, x, y - r);
        s.close();
        c.drawPath(s, p);
    }

    /** Paints the layers, stretched over the given rectangle (design units). */
    static void draw(Canvas c, Paint p, float[] w, float x0, float y0, float x1, float y1) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        for (int k = 0; k < FILES.length; k++) {
            if (w[k] < 0.01f) continue;
            Bitmap b = get(k);
            if (b == null) continue;
            p.setAlpha(Math.round(255 * Math.min(1f, w[k])));
            p.setFilterBitmap(true);
            SRC.set(0, 0, b.getWidth(), b.getHeight());
            c.drawBitmap(b, SRC, new android.graphics.RectF(x0, y0, x1, y1), p);
        }
        p.setAlpha(255);
    }
}
