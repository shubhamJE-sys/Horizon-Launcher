package com.horizon.launcher;

import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.pm.LauncherApps;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends Activity implements PosterView.Host {

    private static final int INK = Color.parseColor("#1B1B1A");
    private static final int RED = Color.parseColor("#C8382C");
    private static final int CREAM = Color.parseColor("#ECE3D0");

    private static final String[] TARGET_NAMES = {
            "PHONE BUTTON", "MESSAGES BUTTON", "BROWSER BUTTON", "GALLERY BUTTON",
            "CAMERA BUTTON", "PLAY STORE BUTTON", "MUSIC OPEN BUTTON", "CLOCK TAP", "CALENDAR TAP"};

    private static class AppEntry {
        String label;
        ComponentName component; // null = "reset to default" entry
    }

    private PosterView poster;
    private FrameLayout root;
    private LinearLayout drawer;
    private GridView grid;
    private TextView titleView, countView;
    private Typeface bebas, roboto;
    private final List<AppEntry> apps = new ArrayList<AppEntry>();
    private final List<AppEntry> shown = new ArrayList<AppEntry>();
    private BaseAdapter adapter;
    private int pickTarget = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(CREAM));
        try {
            bebas = Typeface.createFromAsset(getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(getAssets(), "Roboto-Regular.ttf");
        } catch (Exception e) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(CREAM);
        poster = new PosterView(this, this);
        root.addView(poster, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildDrawer();
        root.addView(drawer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawer.setVisibility(View.GONE);
        setContentView(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int bottom = insets.getSystemWindowInsetBottom();
                poster.setBottomInset(bottom);
                drawer.setPadding(dp(18), dp(52), dp(18), bottom + dp(8));
                return insets;
            }
        });
        root.requestApplyInsets();

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, new OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            // A launcher never exits: back closes the app grid or the music panel.
                            if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
                            else poster.closePanel();
                        }
                    });
        }
        hideBars();
        applyWallpapers();
    }

    /** One-time: make the system wallpaper plain cream (so transitions and recents match) and the lock screen the poster. */
    private void applyWallpapers() {
        final SharedPreferences sp = getSharedPreferences("horizon", MODE_PRIVATE);
        if (sp.getBoolean("wp_v2", false)) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    WallpaperManager wm = WallpaperManager.getInstance(HomeActivity.this);
                    Bitmap cream = Bitmap.createBitmap(720, 1608, Bitmap.Config.ARGB_8888);
                    cream.eraseColor(CREAM);
                    wm.setBitmap(cream, null, true, WallpaperManager.FLAG_SYSTEM);
                    try {
                        InputStream in = getAssets().open("lock.jpg");
                        Bitmap lock = BitmapFactory.decodeStream(in);
                        in.close();
                        if (lock != null) wm.setBitmap(lock, null, true, WallpaperManager.FLAG_LOCK);
                    } catch (Exception ignored) { }
                    sp.edit().putBoolean("wp_v2", true).apply();
                } catch (Exception ignored) { }
            }
        }).start();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onResume() {
        super.onResume();
        poster.start();
        hideBars();
    }

    @Override
    protected void onPause() {
        poster.stop();
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Pressing Home again returns to the poster.
        if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
        poster.closePanel();
    }

    // ---------- app grid ----------

    private View makeCell() {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER);
        cell.setBackgroundColor(CREAM);
        cell.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(88)));

        TextView tv = new TextView(this);
        tv.setTypeface(bebas);
        tv.setTextSize(21f);
        tv.setTextColor(INK);
        tv.setLetterSpacing(0.06f);
        tv.setGravity(Gravity.CENTER);
        tv.setMaxLines(2);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setPadding(dp(6), 0, dp(6), 0);
        cell.addView(tv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View bar = new View(this);
        bar.setBackgroundColor(RED);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(18), dp(2));
        bp.topMargin = dp(7);
        cell.addView(bar, bp);
        return cell;
    }

    private void buildDrawer() {
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(CREAM);
        drawer.setClickable(true);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.BOTTOM);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleView = new TextView(this);
        titleView.setTypeface(bebas);
        titleView.setTextSize(52f);
        titleView.setTextColor(INK);
        titleView.setLetterSpacing(0.03f);
        titleView.setIncludeFontPadding(false);
        titleBox.addView(titleView);
        countView = new TextView(this);
        countView.setTypeface(roboto);
        countView.setTextSize(10f);
        countView.setTextColor(RED);
        countView.setLetterSpacing(0.3f);
        titleBox.addView(countView);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("CLOSE");
        close.setTypeface(bebas);
        close.setTextSize(24f);
        close.setTextColor(RED);
        close.setLetterSpacing(0.1f);
        close.setPadding(dp(16), dp(12), 0, dp(6));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });
        header.addView(close, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        drawer.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View rule = new View(this);
        rule.setBackgroundColor(INK);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(2));
        rp.topMargin = dp(10);
        rp.bottomMargin = dp(12);
        drawer.addView(rule, rp);

        // grid lines come from the dark background showing through 1dp gaps, like the poster's button grid
        FrameLayout gridFrame = new FrameLayout(this);
        gridFrame.setBackgroundColor(INK);
        gridFrame.setPadding(dp(1), dp(1), dp(1), dp(1));

        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dp(1));
        grid.setVerticalSpacing(dp(1));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setBackgroundColor(INK);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setVerticalScrollBarEnabled(false);
        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return shown.size();
            }

            @Override
            public Object getItem(int position) {
                return shown.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View cell = convertView != null ? convertView : makeCell();
                TextView tv = (TextView) ((LinearLayout) cell).getChildAt(0);
                tv.setText(shown.get(position).label.toUpperCase(Locale.getDefault()));
                return cell;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                onEntryClicked(shown.get(position));
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AppEntry a = shown.get(position);
                if (pickTarget >= 0 || a.component == null) return false;
                showAppMenu(a);
                return true;
            }
        });
        gridFrame.addView(grid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawer.addView(gridFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        for (ResolveInfo r : found) {
            if (r.activityInfo == null) continue;
            if (getPackageName().equals(r.activityInfo.packageName)) continue;
            AppEntry a = new AppEntry();
            a.label = String.valueOf(r.loadLabel(pm));
            a.component = new ComponentName(r.activityInfo.packageName, r.activityInfo.name);
            apps.add(a);
        }
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry x, AppEntry y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });
        shown.clear();
        if (pickTarget >= 0) {
            AppEntry reset = new AppEntry();
            reset.label = "DEFAULT";
            reset.component = null;
            shown.add(reset);
        }
        shown.addAll(apps);
        if (pickTarget >= 0) {
            titleView.setText("CHOOSE APP");
            countView.setText("FOR: " + TARGET_NAMES[pickTarget]);
        } else {
            titleView.setText("ALL APPS");
            countView.setText(apps.size() + " APPS");
        }
        adapter.notifyDataSetChanged();
    }

    private void onEntryClicked(AppEntry a) {
        if (pickTarget >= 0) {
            poster.setCustom(pickTarget, a.component, a.component == null ? null : a.label);
            closeDrawer();
            return;
        }
        if (a.component == null) return;
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(a.component);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
        } catch (Exception ignored) { }
        closeDrawer();
    }

    // ---------- long-press menu (app shortcuts + app info) ----------

    private List<ShortcutInfo> loadShortcuts(String pkg) {
        List<ShortcutInfo> out = new ArrayList<ShortcutInfo>();
        try {
            LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
            if (la != null && la.hasShortcutHostPermission()) {
                LauncherApps.ShortcutQuery q = new LauncherApps.ShortcutQuery();
                q.setPackage(pkg);
                q.setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC
                        | LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST
                        | LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED);
                List<ShortcutInfo> l = la.getShortcuts(q, Process.myUserHandle());
                if (l != null) {
                    for (ShortcutInfo si : l) {
                        if (si.isEnabled() && si.getShortLabel() != null && out.size() < 6) out.add(si);
                    }
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    private boolean hasShortcutAccess() {
        try {
            LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
            return la != null && la.hasShortcutHostPermission();
        } catch (Exception e) {
            return false;
        }
    }

    private void addMenuRow(LinearLayout box, String label, final Dialog d, final Runnable action) {
        View line = new View(this);
        line.setBackgroundColor(Color.parseColor("#33000000"));
        box.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        TextView row = new TextView(this);
        row.setText(label.toUpperCase(Locale.getDefault()));
        row.setTypeface(bebas);
        row.setTextSize(22f);
        row.setTextColor(INK);
        row.setLetterSpacing(0.06f);
        row.setSingleLine(true);
        row.setEllipsize(TextUtils.TruncateAt.END);
        row.setPadding(0, dp(12), 0, dp(12));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                try {
                    action.run();
                } catch (Exception ignored) { }
            }
        });
        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void showAppMenu(final AppEntry a) {
        final String pkg = a.component.getPackageName();
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CREAM);
        bg.setStroke(dp(2), INK);
        box.setBackground(bg);
        box.setPadding(dp(22), dp(16), dp(22), dp(12));

        TextView head = new TextView(this);
        head.setText(a.label.toUpperCase(Locale.getDefault()));
        head.setTypeface(bebas);
        head.setTextSize(32f);
        head.setTextColor(INK);
        head.setLetterSpacing(0.04f);
        head.setSingleLine(true);
        head.setEllipsize(TextUtils.TruncateAt.END);
        box.addView(head);
        View bar = new View(this);
        bar.setBackgroundColor(RED);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(30), dp(2));
        bp.topMargin = dp(4);
        bp.bottomMargin = dp(6);
        box.addView(bar, bp);

        addMenuRow(box, "OPEN", d, new Runnable() {
            @Override
            public void run() {
                onEntryClicked(a);
            }
        });

        final LauncherApps la = (LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE);
        for (final ShortcutInfo si : loadShortcuts(pkg)) {
            addMenuRow(box, String.valueOf(si.getShortLabel()), d, new Runnable() {
                @Override
                public void run() {
                    closeDrawer();
                    la.startShortcut(si, null, null);
                }
            });
        }

        addMenuRow(box, "APP INFO / UNINSTALL", d, new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        });

        if (!hasShortcutAccess()) {
            TextView note = new TextView(this);
            note.setText("TO SEE APP SHORTCUTS, SET HORIZON LAUNCHER AS YOUR DEFAULT HOME APP");
            note.setTypeface(roboto);
            note.setTextSize(8f);
            note.setTextColor(RED);
            note.setLetterSpacing(0.12f);
            note.setPadding(0, dp(8), 0, dp(2));
            box.addView(note);
        }

        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.84f),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    @Override
    public void openDrawer() {
        pickTarget = -1;
        loadApps();
        grid.setSelection(0);
        drawer.setVisibility(View.VISIBLE);
    }

    @Override
    public void pickApp(int target) {
        if (target < 0 || target >= TARGET_NAMES.length) return;
        pickTarget = target;
        loadApps();
        grid.setSelection(0);
        drawer.setVisibility(View.VISIBLE);
    }

    private void closeDrawer() {
        pickTarget = -1;
        drawer.setVisibility(View.GONE);
    }
}
