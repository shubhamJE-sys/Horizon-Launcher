package com.horizon.launcher;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.HapticFeedbackConstants;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

/**
 * The poster home screen. Frames come from live_bg.jpg; everything inside the frames
 * (clock, sky, weather, battery, music remote, text buttons) is drawn here.
 */
public class PosterView extends View {

    public interface Host {
        void openDrawer();

        void pickApp(int target);
    }

    private static final float DW = 360f, DH = 804f;
    private static final int INK = Color.parseColor("#1B1B1A");
    private static final int RED = Color.parseColor("#C8382C");
    private static final int CREAM = Color.parseColor("#ECE3D0");
    private static final int WARM = Color.parseColor("#E9B58E");
    private static final int NIGHT = Color.parseColor("#1F2430");
    private static final int MOON = Color.parseColor("#EDE6D3");

    private static final float SC_L = 9.5f, SC_T = 241f, SC_R = 350.5f, SC_B = 477f;
    private static final float LAKE_Y = 241f + 236f * 0.66f;

    private static final float PANEL_L = 8f, PANEL_R = 352f, PANEL_T = 395f, PANEL_B = 553f;
    private static final float BTN_Y = 524f, PREV_X = 148f, PLAY_X = 204f, NEXT_X = 260f;

    private static final String WEATHER_URL =
            "https://api.open-meteo.com/v1/forecast?latitude=26.23&longitude=81.23"
                    + "&current=temperature_2m,weather_code,cloud_cover"
                    + "&daily=sunrise,sunset&timezone=auto&forecast_days=1";

    private static final String[] BUTTON_WORDS = {
            "PHONE", "MESSAGES", "BROWSER", "GALLERY", "CAMERA", "PLAY STORE"};

    private static final float[][] CLOUDS = {
            {.15f, .12f, 1.0f}, {.58f, .05f, 1.3f}, {.82f, .24f, 0.9f}, {.33f, .30f, 1.1f},
            {.70f, .40f, 1.0f}, {.06f, .42f, 0.8f}, {.92f, .02f, 0.8f}};

    private final Host host;
    private Bitmap bg, layer;
    private Typeface bebas, roboto;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint layerPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audio;

    private float scale = 1f, offX = 0f, offY = 0f;
    private int bottomInset = 0;
    private boolean receiving = false;
    private boolean started = false;
    private long lastTap = 0;

    private float downX, downY;
    private long downTime;
    private int touchSlop = 24;

    private int batteryPct = 100;
    private int pluggedType = 0;
    private float tempC = -1f;

    private boolean weatherOk = false;
    private volatile boolean fetching = false;
    private long lastFetch = 0;
    private int wCode = 0, wCloud = 0;
    private float wTemp = 0f;
    private int sunriseMin = 360, sunsetMin = 1080;

    private final float[] rainX = new float[120];
    private final float[] rainY = new float[120];
    private final float[] starX = new float[45];
    private final float[] starY = new float[45];
    private final float[] starR = new float[45];

    private boolean panelOpen = false;

    // user-chosen apps: 0-5 buttons, 6 music, 7 clock, 8 calendar
    private final ComponentName[] custom = new ComponentName[9];
    private final String[] customLabel = new String[9];
    private SharedPreferences prefs;
    private boolean longFired = false;
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            onLongPress();
        }
    };
    private static final String[] DEFAULT_CAPS = {
            "MAKE THE CALL", "SEND A MESSAGE", "BROWSE THE WEB",
            "SHARE YOUR MOMENTS", "CAPTURE THE MOMENT", "DISCOVER NEW APPS"};

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                readBattery(intent);
            }
            fetchWeather();
            invalidate();
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (started && panelOpen) handler.postDelayed(this, 1000);
        }
    };

    public PosterView(Context ctx, Host host) {
        super(ctx);
        this.host = host;
        setBackgroundColor(CREAM);
        try {
            touchSlop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        } catch (Exception ignored) { }
        try {
            InputStream in = ctx.getAssets().open("live_bg.jpg");
            bg = BitmapFactory.decodeStream(in);
            in.close();
        } catch (Exception ignored) { }
        try {
            InputStream in = ctx.getAssets().open("scene_layer.png");
            layer = BitmapFactory.decodeStream(in);
            in.close();
        } catch (Exception ignored) { }
        try {
            bebas = Typeface.createFromAsset(ctx.getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(ctx.getAssets(), "Roboto-Regular.ttf");
        } catch (Exception e) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }
        audio = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        prefs = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
        for (int i = 0; i < custom.length; i++) {
            String f = prefs.getString("app_" + i, null);
            if (f != null) {
                custom[i] = ComponentName.unflattenFromString(f);
                customLabel[i] = prefs.getString("label_" + i, "");
            }
        }

        Random r = new Random(11);
        for (int i = 0; i < rainX.length; i++) {
            rainX[i] = r.nextFloat() * 341f;
            rainY[i] = r.nextFloat() * 236f;
        }
        for (int i = 0; i < starX.length; i++) {
            starX[i] = SC_L + r.nextFloat() * 341f;
            starY[i] = SC_T + 6f + r.nextFloat() * 120f;
            starR[i] = 0.5f + r.nextFloat() * 0.9f;
        }
        Intent sticky = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (sticky != null) readBattery(sticky);
    }

    public void setBottomInset(int px) {
        bottomInset = Math.max(0, px);
        invalidate();
    }

    public void setCustom(int target, ComponentName cn, String label) {
        if (target < 0 || target >= custom.length) return;
        SharedPreferences.Editor ed = prefs.edit();
        if (cn == null) {
            custom[target] = null;
            customLabel[target] = null;
            ed.remove("app_" + target).remove("label_" + target);
        } else {
            custom[target] = cn;
            customLabel[target] = label;
            ed.putString("app_" + target, cn.flattenToString()).putString("label_" + target, label);
        }
        ed.apply();
        invalidate();
    }

    public void closePanel() {
        panelOpen = false;
        invalidate();
    }

    // ---------- lifecycle (called by the activity) ----------

    public void start() {
        started = true;
        if (!receiving) {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_TIME_TICK);
            f.addAction(Intent.ACTION_TIME_CHANGED);
            f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            f.addAction(Intent.ACTION_BATTERY_CHANGED);
            f.addAction(Intent.ACTION_POWER_CONNECTED);
            f.addAction(Intent.ACTION_POWER_DISCONNECTED);
            f.addAction("android.net.conn.CONNECTIVITY_CHANGE");
            f.addAction("android.net.wifi.RSSI_CHANGED");
            if (Build.VERSION.SDK_INT >= 33) {
                getContext().registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                getContext().registerReceiver(receiver, f);
            }
            receiving = true;
        }
        Intent sticky = getContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (sticky != null) readBattery(sticky);
        fetchWeather();
        invalidate();
        handler.removeCallbacks(ticker);
        if (panelOpen) handler.postDelayed(ticker, 1000);
    }

    public void stop() {
        started = false;
        handler.removeCallbacks(ticker);
        if (receiving) {
            try { getContext().unregisterReceiver(receiver); } catch (Exception ignored) { }
            receiving = false;
        }
    }

    // ---------- battery ----------

    private void readBattery(Intent i) {
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scaleVal = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (level >= 0 && scaleVal > 0) batteryPct = Math.round(level * 100f / scaleVal);
        pluggedType = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        tempC = t >= 0 ? t / 10f : -1f;
    }

    // ---------- weather ----------

    private void fetchWeather() {
        long now = SystemClock.elapsedRealtime();
        if (fetching) return;
        if (weatherOk && now - lastFetch < 30L * 60L * 1000L) return;
        if (!weatherOk && lastFetch != 0 && now - lastFetch < 2L * 60L * 1000L) return;
        fetching = true;
        lastFetch = now;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection con = (HttpURLConnection) new URL(WEATHER_URL).openConnection();
                    con.setConnectTimeout(8000);
                    con.setReadTimeout(8000);
                    InputStream in = con.getInputStream();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    con.disconnect();
                    JSONObject j = new JSONObject(bo.toString("UTF-8"));
                    JSONObject cur = j.getJSONObject("current");
                    final float temp = (float) cur.getDouble("temperature_2m");
                    final int code = cur.getInt("weather_code");
                    final int cloud = cur.getInt("cloud_cover");
                    JSONObject d = j.getJSONObject("daily");
                    final int sr = toMinutes(d.getJSONArray("sunrise").getString(0));
                    final int ss = toMinutes(d.getJSONArray("sunset").getString(0));
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            wTemp = temp;
                            wCode = code;
                            wCloud = cloud;
                            if (sr > 0 && ss > sr) {
                                sunriseMin = sr;
                                sunsetMin = ss;
                            }
                            weatherOk = true;
                            invalidate();
                        }
                    });
                } catch (Exception ignored) {
                } finally {
                    fetching = false;
                }
            }
        }).start();
    }

    private int toMinutes(String iso) {
        int h = Integer.parseInt(iso.substring(11, 13));
        int m = Integer.parseInt(iso.substring(14, 16));
        return h * 60 + m;
    }

    private float cloudFrac() {
        if (!weatherOk) return 0f;
        float c = wCloud / 100f;
        if (wCode >= 51) c = Math.max(c, 0.8f);
        else if (wCode == 45 || wCode == 48) c = Math.max(c, 0.6f);
        return Math.max(0f, Math.min(1f, c));
    }

    private int rainLevel() {
        if (!weatherOk) return 0;
        switch (wCode) {
            case 51: case 53: case 55: case 56: case 57:
                return 1;
            case 61: case 63: case 66: case 80: case 81:
                return 2;
            case 65: case 67: case 82: case 95: case 96: case 99:
                return 3;
            default:
                return 0;
        }
    }

    private boolean snowing() {
        return weatherOk && ((wCode >= 71 && wCode <= 77) || wCode == 85 || wCode == 86);
    }

    private String weatherLabel(boolean night) {
        switch (wCode) {
            case 0: return night ? "CLEAR NIGHT" : "CLEAR SKY";
            case 1: return "MOSTLY CLEAR";
            case 2: return "PARTLY CLOUDY";
            case 3: return "OVERCAST";
            case 45: case 48: return "FOG";
            case 51: case 53: case 55: case 56: case 57: return "DRIZZLE";
            case 61: case 63: case 65: case 66: case 67: return "RAIN";
            case 80: case 81: case 82: return "SHOWERS";
            case 71: case 73: case 75: case 77: case 85: case 86: return "SNOW";
            case 95: case 96: case 99: return "THUNDERSTORM";
            default: return "WEATHER";
        }
    }

    // ---------- music remote ----------

    private boolean musicActive() {
        try {
            return audio != null && audio.isMusicActive();
        } catch (Exception e) {
            return false;
        }
    }

    private void sendKey(int code) {
        try {
            long t = SystemClock.uptimeMillis();
            audio.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0));
            audio.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0));
        } catch (Exception ignored) { }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        }, 500);
    }

    private void transport(int which) {
        int key = which == 0 ? KeyEvent.KEYCODE_MEDIA_PREVIOUS
                : (which == 1 ? KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE : KeyEvent.KEYCODE_MEDIA_NEXT);
        sendKey(key);
    }

    private void launchComponent(ComponentName cn) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(cn);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }

    private void openMusicApp() {
        if (custom[6] != null) {
            launchComponent(custom[6]);
            return;
        }
        // No music app chosen yet: let the user pick one (BitChord and others that the system does not list).
        if (host != null) host.pickApp(6);
    }

    private void openClock() {
        if (custom[7] != null) {
            launchComponent(custom[7]);
            return;
        }
        try {
            Intent i = new Intent(AlarmClock.ACTION_SHOW_ALARMS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            return;
        } catch (Exception ignored) { }
        try {
            PackageManager pm = getContext().getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo r : pm.queryIntentActivities(main, 0)) {
                String lbl = String.valueOf(r.loadLabel(pm)).toLowerCase(Locale.ROOT);
                String pkg = r.activityInfo.packageName.toLowerCase(Locale.ROOT);
                if (lbl.contains("clock") || pkg.contains("deskclock") || pkg.contains("alarmclock")) {
                    launchComponent(new ComponentName(r.activityInfo.packageName, r.activityInfo.name));
                    return;
                }
            }
        } catch (Exception ignored) { }
    }

    private void openCalendar() {
        if (custom[8] != null) {
            launchComponent(custom[8]);
            return;
        }
        startIntent(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR));
    }

    private void startIntent(Intent i) {
        if (i == null) return;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }

    // ---------- touch ----------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                downTime = SystemClock.uptimeMillis();
                longFired = false;
                handler.removeCallbacks(longPress);
                handler.postDelayed(longPress, 450);
                return true;
            case MotionEvent.ACTION_MOVE: {
                float mx = e.getX() - downX, my = e.getY() - downY;
                if (mx * mx + my * my > (float) touchSlop * touchSlop * 2.5f) handler.removeCallbacks(longPress);
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                return true;
            case MotionEvent.ACTION_UP: {
                handler.removeCallbacks(longPress);
                if (longFired) return true;
                float dx = e.getX() - downX, dy = e.getY() - downY;
                if (dy < -touchSlop * 4f && Math.abs(dy) > Math.abs(dx)) {
                    if (host != null) host.openDrawer();
                } else if (dx * dx + dy * dy <= (float) touchSlop * touchSlop
                        && SystemClock.uptimeMillis() - downTime < 500) {
                    handleTap(e.getX(), e.getY());
                }
                return true;
            }
            default:
                return true;
        }
    }

    private void onLongPress() {
        float x = (downX - offX) / scale;
        float y = (downY - offY) / scale;
        int target = -1;
        if (!panelOpen && inRect(x, y, 240f, 480f, 350f, 552f)) {
            target = 6;
        } else if (inRect(x, y, 8f, 641f, 352f, 771f)) {
            int col = (int) ((x - 8f) / (344f / 3f));
            col = Math.max(0, Math.min(2, col));
            target = (y < 713f ? 0 : 3) + col;
        } else if (inRect(x, y, 8f, 34f, 108f, 196f)) {
            target = 7;
        } else if (inRect(x, y, 108f, 34f, 228f, 150f) || inRect(x, y, 228f, 34f, 352f, 240f)) {
            target = 8;
        }
        if (target >= 0 && host != null) {
            longFired = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            host.pickApp(target);
        }
    }

    private boolean inRect(float x, float y, float l, float t, float r, float b) {
        return x >= l && x <= r && y >= t && y <= b;
    }

    private boolean near(float x, float y, float cx, float cy, float r) {
        float dx = x - cx, dy = y - cy;
        return dx * dx + dy * dy <= r * r;
    }

    private void handleTap(float px, float py) {
        long now = SystemClock.uptimeMillis();
        if (now - lastTap < 300) return;
        float x = (px - offX) / scale;
        float y = (py - offY) / scale;

        if (panelOpen && inRect(x, y, PANEL_L, PANEL_T, PANEL_R, PANEL_B)) {
            lastTap = now;
            panelTap(x, y);
            return;
        }
        if (!panelOpen && inRect(x, y, 240f, 480f, 350f, 552f)) {
            lastTap = now;
            panelOpen = true;
            handler.removeCallbacks(ticker);
            handler.postDelayed(ticker, 1000);
            invalidate();
            return;
        }
        if (inRect(x, y, 8f, 34f, 108f, 196f)) {
            lastTap = now;
            openClock();
            return;
        }
        if (inRect(x, y, 108f, 34f, 228f, 150f) || inRect(x, y, 228f, 34f, 352f, 240f)) {
            lastTap = now;
            openCalendar();
            return;
        }
        if (inRect(x, y, 8f, 641f, 352f, 771f)) {
            lastTap = now;
            int col = (int) ((x - 8f) / (344f / 3f));
            col = Math.max(0, Math.min(2, col));
            int row = y < 713f ? 0 : 1;
            launchButton(row * 3 + col);
            return;
        }
        if (inRect(x, y, 90f, 771f, 270f, 800f)) {
            lastTap = now;
            if (host != null) host.openDrawer();
        }
    }

    private void panelTap(float x, float y) {
        if (near(x, y, 338f, 408f, 13f)) {
            panelOpen = false;
            handler.removeCallbacks(ticker);
            invalidate();
            return;
        }
        if (near(x, y, PREV_X, BTN_Y, 22f)) {
            transport(0);
        } else if (near(x, y, PLAY_X, BTN_Y, 24f)) {
            transport(1);
        } else if (near(x, y, NEXT_X, BTN_Y, 22f)) {
            transport(2);
        } else if (inRect(x, y, 288f, 508f, 346f, 540f)) {
            openMusicApp();
        }
    }

    private void launchButton(int idx) {
        if (idx >= 0 && idx < 6 && custom[idx] != null) {
            launchComponent(custom[idx]);
            return;
        }
        Intent i = null;
        switch (idx) {
            case 0:
                i = new Intent(Intent.ACTION_DIAL);
                break;
            case 1:
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING);
                break;
            case 2:
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
                break;
            case 3:
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY);
                break;
            case 4:
                i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                break;
            case 5:
                i = getContext().getPackageManager().getLaunchIntentForPackage("com.android.vending");
                break;
            default:
                break;
        }
        startIntent(i);
    }

    // ---------- drawing ----------

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        c.drawColor(CREAM);
        int availH = Math.max(1, h - bottomInset);
        scale = Math.min(w / DW, availH / DH);
        offX = (w - DW * scale) / 2f;
        offY = (availH - DH * scale) / 2f;

        if (bg != null) {
            Matrix m = new Matrix();
            float bs = scale * DW / bg.getWidth();
            m.postScale(bs, bs);
            m.postTranslate(offX, offY);
            c.drawBitmap(bg, m, bitmapPaint);
        }

        c.save();
        c.translate(offX, offY);
        c.scale(scale, scale);
        try { drawScene(c); } catch (Exception ignored) { }
        drawLive(c);
        c.restore();
    }

    private void text(Canvas c, String t, float x, float y, float size, int color,
                      Typeface tf, Paint.Align align, float spacingEm) {
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(tf);
        paint.setTextSize(size);
        paint.setColor(color);
        paint.setTextAlign(align);
        paint.setLetterSpacing(spacingEm);
        c.drawText(t, x, y, paint);
    }

    private int blend(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    private void drawScene(Canvas c) {
        Calendar cal = Calendar.getInstance();
        int nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        int sr = sunriseMin, ss = sunsetMin;
        boolean day = nowMin >= sr && nowMin <= ss;
        float cc = cloudFrac();

        float d = nowMin - sr, e = ss - nowMin;
        int edge = blend(CREAM, WARM, 0.8f);
        int sky;
        float nightK = 0f;
        if (day) {
            float w = Math.min(d, e);
            float f = Math.max(0f, Math.min(1f, 1f - w / 60f));
            sky = blend(CREAM, WARM, f * 0.8f);
        } else {
            float m = d < 0 ? -d : -e;
            nightK = Math.max(0f, Math.min(1f, m / 45f));
            sky = blend(edge, NIGHT, nightK);
        }
        int dimTarget = nightK > 0.5f ? Color.parseColor("#14171F") : Color.parseColor("#BBB5A8");
        sky = blend(sky, dimTarget, cc * 0.45f);

        c.save();
        c.clipRect(SC_L, SC_T, SC_R, SC_B);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(sky);
        c.drawRect(SC_L, SC_T, SC_R, SC_B, paint);

        if (nightK > 0.15f) {
            int a = (int) (255 * nightK * (1f - cc * 0.8f));
            paint.setColor(MOON);
            paint.setAlpha(Math.max(0, Math.min(255, a)));
            for (int i = 0; i < starX.length; i++) {
                c.drawCircle(starX[i], starY[i], starR[i], paint);
            }
            paint.setAlpha(255);
        }

        float bx, by, br;
        boolean bodyUp;
        if (day) {
            float t = (nowMin - sr) / (float) Math.max(1, ss - sr);
            bx = 40f + t * 270f;
            float base = LAKE_Y + 24f, peak = 292f;
            by = base - (float) Math.sin(Math.PI * t) * (base - peak);
            br = 33f;
            bodyUp = by < LAKE_Y - 6f;
            paint.setColor(RED);
            paint.setAlpha((int) (255 * (1f - 0.55f * cc)));
            c.drawCircle(bx, by, br, paint);
            paint.setAlpha(255);
        } else {
            int len = 1440 - (ss - sr);
            int m2 = nowMin >= ss ? nowMin - ss : nowMin + 1440 - ss;
            float t = m2 / (float) Math.max(1, len);
            bx = 40f + t * 270f;
            float base = LAKE_Y + 22f, peak = 288f;
            by = base - (float) Math.sin(Math.PI * t) * (base - peak);
            br = 24f;
            bodyUp = by < LAKE_Y - 6f;
            double phase = ((System.currentTimeMillis() - 947182440000L) / 86400000.0 % 29.530588853) / 29.530588853;
            float f = (float) ((1.0 - Math.cos(2.0 * Math.PI * phase)) / 2.0);
            float dd = 2f * br * f;
            paint.setColor(MOON);
            paint.setAlpha((int) (255 * (1f - 0.5f * cc)));
            c.drawCircle(bx, by, br, paint);
            paint.setAlpha(255);
            paint.setColor(sky);
            c.drawCircle(phase < 0.5 ? bx - dd : bx + dd, by, br + 0.5f, paint);
        }

        int nCl = Math.round(cc * CLOUDS.length);
        int cloudCol = nightK > 0.5f ? Color.parseColor("#3A4150")
                : (cc > 0.6f ? Color.parseColor("#B3AD9F") : Color.parseColor("#F6F0E3"));
        for (int i = 0; i < nCl && i < CLOUDS.length; i++) {
            float cx = SC_L + CLOUDS[i][0] * 341f;
            float cy = SC_T + 14f + CLOUDS[i][1] * 150f;
            float s = CLOUDS[i][2];
            paint.setColor(cloudCol);
            paint.setAlpha(235);
            c.drawOval(new RectF(cx - 26f * s, cy - 8f * s, cx + 26f * s, cy + 8f * s), paint);
            c.drawOval(new RectF(cx - 29f * s, cy - 13f * s, cx + 1f * s, cy + 3f * s), paint);
            c.drawOval(new RectF(cx - 8f * s, cy - 17f * s, cx + 27f * s, cy + 2f * s), paint);
            paint.setAlpha(255);
        }

        if (layer != null) {
            float a = 1f - 0.55f * nightK - 0.2f * cc;
            float bl = 16f * nightK;
            ColorMatrix cm = new ColorMatrix(new float[]{
                    a, 0, 0, 0, 0,
                    0, a, 0, 0, 0,
                    0, 0, a, 0, bl,
                    0, 0, 0, 1, 0});
            layerPaint.setColorFilter(new ColorMatrixColorFilter(cm));
            c.drawBitmap(layer, null, new RectF(SC_L, SC_T, SC_R, SC_B), layerPaint);
        }

        if (bodyUp) {
            int col = day ? RED : MOON;
            for (int i = 0; i < 9; i++) {
                float w = (30f - i * 2.8f) * (1f - 0.4f * cc);
                float yy = LAKE_Y + 5f + i * 8f;
                paint.setColor(col);
                paint.setAlpha(150 - i * 8);
                c.drawRect(bx - w, yy, bx + w, yy + 1.8f, paint);
            }
            paint.setAlpha(255);
        }

        if (weatherOk && (wCode == 45 || wCode == 48)) {
            int fog = nightK > 0.5f ? Color.parseColor("#2A2F3B") : Color.parseColor("#E4DCC8");
            paint.setShader(new LinearGradient(0, 320f, 0, LAKE_Y + 30f,
                    Color.argb(0, Color.red(fog), Color.green(fog), Color.blue(fog)),
                    Color.argb(190, Color.red(fog), Color.green(fog), Color.blue(fog)),
                    Shader.TileMode.CLAMP));
            c.drawRect(SC_L, 320f, SC_R, SC_B, paint);
            paint.setShader(null);
        }

        int rl = rainLevel();
        if (rl > 0) {
            int n = rl == 1 ? 40 : (rl == 2 ? 75 : 115);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(0.9f);
            paint.setColor(nightK > 0.5f ? MOON : INK);
            paint.setAlpha(120);
            for (int i = 0; i < n; i++) {
                float x0 = SC_L + rainX[i];
                float y0 = SC_T + rainY[i];
                c.drawLine(x0, y0, x0 - 2.5f, y0 + 9f, paint);
            }
            paint.setAlpha(255);
            paint.setStyle(Paint.Style.FILL);
        }
        if (snowing()) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(nightK > 0.5f ? MOON : Color.parseColor("#FFFFFF"));
            for (int i = 0; i < 80; i++) {
                c.drawCircle(SC_L + rainX[i], SC_T + rainY[i], 1.5f, paint);
            }
        }

        int txt = (nightK > 0.5f || cc > 0.85f && nightK > 0.2f) ? CREAM : INK;
        String[] left = {"LESS", "SCROLLING", "MORE", "HORIZONS"};
        String[] right = {"DISCONNECT", "EXPLORE BREATHE", "REPEAT"};
        for (int i = 0; i < left.length; i++) {
            text(c, left[i], 18f, 257f + i * 9.4f, 6.5f, txt, roboto, Paint.Align.LEFT, 0.46f);
        }
        for (int i = 0; i < right.length; i++) {
            text(c, right[i], 344f, 257f + i * 9.4f, 6.5f, txt, roboto, Paint.Align.RIGHT, 0.46f);
        }
        if (weatherOk) {
            String w = weatherLabel(!day) + " • " + Math.round(wTemp) + "°C";
            text(c, w, 344f, 470f, 7f, nightK > 0.5f ? CREAM : INK, roboto, Paint.Align.RIGHT, 0.2f);
        }

        c.restore();
    }

    private void drawLive(Canvas c) {
        Calendar cal = Calendar.getInstance();
        boolean h24 = DateFormat.is24HourFormat(getContext());
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int hh = h24 ? hour : ((hour % 12 == 0) ? 12 : hour % 12);
        int mm = cal.get(Calendar.MINUTE);

        text(c, String.format(Locale.US, "%02d", hh), 14, 108, 96, INK, bebas, Paint.Align.LEFT, 0f);
        text(c, String.format(Locale.US, "%02d", mm), 14, 182, 96, RED, bebas, Paint.Align.LEFT, 0f);

        String mon = cal.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
        text(c, mon, 112, 62, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
        text(c, String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), 112, 88, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
        text(c, String.valueOf(cal.get(Calendar.YEAR)), 112, 114, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(INK);
        paint.setStrokeWidth(1.5f);
        c.drawLine(112, 126, 160, 126, paint);
        if (!h24) {
            text(c, hour < 12 ? "AM" : "PM", 112, 144, 10, RED, roboto, Paint.Align.LEFT, 0.25f);
        }

        String day = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
        float size = 62f;
        paint.setTypeface(bebas);
        paint.setTextSize(size);
        paint.setLetterSpacing(0.02f);
        float wdt = paint.measureText(day);
        if (wdt > 182f) size = size * 182f / wdt;
        float cap = size * 0.70f;
        c.save();
        c.translate(266f + cap / 2f, 228f);
        c.rotate(-90f);
        text(c, day, 0, 0, size, INK, bebas, Paint.Align.LEFT, 0.02f);
        c.restore();

        String greet = hour < 12 ? "GOOD MORNING" : (hour < 17 ? "GOOD AFTERNOON" : (hour < 21 ? "GOOD EVENING" : "GOOD NIGHT"));
        float gs = 40f;
        paint.setTypeface(bebas);
        paint.setTextSize(gs);
        paint.setLetterSpacing(0.03f);
        float gw = paint.measureText(greet);
        if (gw > 215f) gs = gs * 215f / gw;
        text(c, greet, 18, 524, gs, INK, bebas, Paint.Align.LEFT, 0.03f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(RED);
        c.drawRect(18, 534, 54, 536.5f, paint);

        try { drawMusicButton(c); } catch (Exception ignored) { }

        text(c, String.valueOf(cal.get(Calendar.DAY_OF_YEAR)), 16, 590, 42, INK, bebas, Paint.Align.LEFT, 0f);
        text(c, "DAY OF THE YEAR", 16, 603, 5.6f, INK, roboto, Paint.Align.LEFT, 0.25f);

        try { drawBattery(c); } catch (Exception ignored) { }
        try { drawSignal(c); } catch (Exception ignored) { }
        try { drawButtons(c); } catch (Exception ignored) { }
        try { if (panelOpen) drawMusic(c); } catch (Exception ignored) { }

        text(c, "SWIPE UP • ALL APPS", 180f, 782f, 7f, INK, roboto, Paint.Align.CENTER, 0.3f);
        text(c, "L3", 346f, 781f, 5.5f, INK, roboto, Paint.Align.RIGHT, 0.2f);
    }

    private void drawCassette(Canvas c, float cx, float cy, float s, boolean spin) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(INK);
        paint.setStrokeWidth(1.7f * Math.max(0.8f, s));
        c.drawRoundRect(new RectF(cx - 30f * s, cy - 20f * s, cx + 30f * s, cy + 20f * s), 4f * s, 4f * s, paint);
        paint.setStrokeWidth(1.2f * Math.max(0.8f, s));
        c.drawRoundRect(new RectF(cx - 22f * s, cy - 14f * s, cx + 22f * s, cy + 3f * s), 3f * s, 3f * s, paint);
        float[] rx = {cx - 10f * s, cx + 10f * s};
        float ry = cy - 5.5f * s, rr = 5.2f * s;
        double base = spin ? ((System.currentTimeMillis() / 1000L) % 6L) * 60.0 : 0.0;
        for (int i = 0; i < 2; i++) {
            c.drawCircle(rx[i], ry, rr, paint);
            for (int k = 0; k < 3; k++) {
                double a = Math.toRadians(base + k * 120.0);
                c.drawLine(rx[i], ry, rx[i] + (float) Math.cos(a) * rr, ry + (float) Math.sin(a) * rr, paint);
            }
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(RED);
        c.drawRect(cx - 20f * s, cy + 9f * s, cx + 20f * s, cy + 12f * s, paint);
        paint.setColor(INK);
        c.drawCircle(cx - 25f * s, cy - 15f * s, 1.1f * s, paint);
        c.drawCircle(cx + 25f * s, cy - 15f * s, 1.1f * s, paint);
        c.drawCircle(cx - 25f * s, cy + 15f * s, 1.1f * s, paint);
        c.drawCircle(cx + 25f * s, cy + 15f * s, 1.1f * s, paint);
    }

    private void drawMusicButton(Canvas c) {
        if (panelOpen) return;
        boolean playing = musicActive();
        drawCassette(c, 292f, 506f, 0.95f, playing);
        text(c, "MUSIC", 292f, 546f, 13f, INK, bebas, Paint.Align.CENTER, 0.14f);
        if (playing) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(RED);
            c.drawCircle(326f, 489f, 3f, paint);
        }
    }

    private void drawButtons(Canvas c) {
        float cw = 344f / 3f;
        float maxW = cw - 12f;
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 3; col++) {
                int idx = row * 3 + col;
                float cx = 8f + cw * (col + 0.5f);
                float baseline = row == 0 ? 678f : 744f;
                String word;
                String cap;
                if (custom[idx] != null && customLabel[idx] != null && customLabel[idx].length() > 0) {
                    word = customLabel[idx].toUpperCase(Locale.getDefault());
                    cap = "YOUR CHOICE";
                } else {
                    word = BUTTON_WORDS[idx];
                    cap = DEFAULT_CAPS[idx];
                }
                float size = 22f;
                paint.setTypeface(bebas);
                paint.setLetterSpacing(0.06f);
                paint.setTextSize(size);
                float w = paint.measureText(word);
                if (w > maxW) size = Math.max(11f, size * maxW / w);
                paint.setTextSize(size);
                CharSequence shown = word;
                if (paint.measureText(word) > maxW) {
                    TextPaint tp = new TextPaint(paint);
                    shown = TextUtils.ellipsize(word, tp, maxW, TextUtils.TruncateAt.END);
                }
                text(c, shown.toString(), cx, baseline, size, INK, bebas, Paint.Align.CENTER, 0.06f);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(RED);
                c.drawRect(cx - 9, baseline + 6, cx + 9, baseline + 8, paint);
                text(c, cap, cx, row == 0 ? 707f : 766f, 6.5f, INK, roboto, Paint.Align.CENTER, 0.31f);
            }
        }
    }

    private void drawSignal(Canvas c) {
        int type = 0; // 0 offline, 1 wifi, 2 mobile, 3 other
        float frac = 0f;
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n != null) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                    if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) type = 1;
                    else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) type = 2;
                    else type = 3;
                    frac = 1f;
                    if (Build.VERSION.SDK_INT >= 29) {
                        int ss = nc.getSignalStrength();
                        if (ss != NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED) {
                            if (ss <= 0) {
                                frac = type == 1 ? (ss + 95f) / 55f : (ss + 120f) / 60f;
                            } else {
                                frac = ss / 100f;
                            }
                            frac = Math.max(0.1f, Math.min(1f, frac));
                        }
                    }
                }
            }
        } catch (Exception ignored) { }

        int filled = Math.round(frac * 40f);
        paint.setStyle(Paint.Style.FILL);
        for (int row = 0; row < 2; row++) {
            for (int i = 0; i < 40; i++) {
                paint.setColor(INK);
                paint.setAlpha(i < filled ? 255 : 38);
                float x = 16f + i * 6.2f;
                float y = 618f + row * 8f;
                c.drawRect(x, y, x + 5f, y + 6f, paint);
            }
        }
        paint.setAlpha(255);
        String l1 = type == 0 ? "NO" : (type == 1 ? "WI-FI" : (type == 2 ? "MOBILE" : "NETWORK"));
        String l2 = type == 0 ? "SIGNAL" : (type == 2 ? "DATA" : "CONNECTED");
        text(c, l1, 278f, 625f, 6.5f, INK, roboto, Paint.Align.LEFT, 0.23f);
        text(c, l2, 278f, 634f, 6.5f, INK, roboto, Paint.Align.LEFT, 0.23f);
    }

    private void drawBattery(Canvas c) {
        float x = 146, y = 562, w = 52, h = 22;
        boolean charging = pluggedType != 0;

        paint.setColor(INK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.8f);
        c.drawRoundRect(x, y, x + w, y + h, 3, 3, paint);
        paint.setStyle(Paint.Style.FILL);
        c.drawRect(x + w, y + 6, x + w + 4, y + h - 6, paint);

        int segs = Math.max(batteryPct > 0 ? 1 : 0, Math.round(batteryPct / 20f));
        paint.setColor(RED);
        float sw = (w - 8) / 5f;
        for (int i = 0; i < segs && i < 5; i++) {
            float sx = x + 3 + i * sw;
            c.drawRect(sx, y + 3, sx + sw - 2, y + h - 3, paint);
        }

        if (charging) {
            float cx = x + w / 2f, top = y + 2f;
            Path bolt = new Path();
            bolt.moveTo(cx + 3f, top);
            bolt.lineTo(cx - 6f, top + 11f);
            bolt.lineTo(cx - 0.5f, top + 11f);
            bolt.lineTo(cx - 3f, top + 18f);
            bolt.lineTo(cx + 6f, top + 7f);
            bolt.lineTo(cx + 0.5f, top + 7f);
            bolt.close();
            paint.setColor(CREAM);
            paint.setStyle(Paint.Style.FILL_AND_STROKE);
            paint.setStrokeWidth(1.6f);
            c.drawPath(bolt, paint);
            paint.setColor(INK);
            paint.setStyle(Paint.Style.FILL);
            c.drawPath(bolt, paint);
        }

        text(c, batteryPct + "%", 342, 592, 44, INK, bebas, Paint.Align.RIGHT, 0f);

        String status;
        if (charging) {
            String src = pluggedType == BatteryManager.BATTERY_PLUGGED_WIRELESS ? "WIRELESS"
                    : (pluggedType == BatteryManager.BATTERY_PLUGGED_USB ? "USB" : "CABLE");
            status = "CHARGING • " + src;
        } else {
            status = "ON BATTERY";
        }
        if (tempC >= 0) status += " • " + Math.round(tempC) + "°C";
        text(c, status, 146, 593, 6.2f, charging ? RED : INK, roboto, Paint.Align.LEFT, 0.16f);
    }

    private void drawMusic(Canvas c) {
        boolean playing = musicActive();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(CREAM);
        c.drawRect(PANEL_L, PANEL_T, PANEL_R, PANEL_B - 1f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(INK);
        paint.setStrokeWidth(1.5f);
        c.drawRect(PANEL_L, PANEL_T, PANEL_R, PANEL_B - 1f, paint);

        paint.setStrokeWidth(1.8f);
        c.drawLine(333f, 403f, 343f, 413f, paint);
        c.drawLine(343f, 403f, 333f, 413f, paint);

        text(c, playing ? "NOW PLAYING" : "MUSIC REMOTE", 126, 410, 6f, RED, roboto, Paint.Align.LEFT, 0.3f);
        drawCassette(c, 66f, 453f, 1.4f, playing);
        text(c, "MUSIC PLAYER", 126, 440, 30f, INK, bebas, Paint.Align.LEFT, 0.03f);
        text(c, "CONTROLS YOUR CURRENT SONG", 126, 456, 7f, INK, roboto, Paint.Align.LEFT, 0.2f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(RED);
        c.drawRect(126, 464, 150, 466.5f, paint);
        text(c, "BACK • PLAY/PAUSE • NEXT", 126, 486, 7f, INK, roboto, Paint.Align.LEFT, 0.2f);
        text(c, custom[6] != null ? "OPEN STARTS: " + customLabel[6].toUpperCase(Locale.getDefault()) : "OPEN LETS YOU CHOOSE YOUR MUSIC APP", 126, 497, 6f, INK, roboto, Paint.Align.LEFT, 0.2f);

        float cy = BTN_Y;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(INK);
        c.drawRect(PREV_X - 9, cy - 7, PREV_X - 7, cy + 7, paint);
        Path prev = new Path();
        prev.moveTo(PREV_X + 8, cy - 7);
        prev.lineTo(PREV_X - 5, cy);
        prev.lineTo(PREV_X + 8, cy + 7);
        prev.close();
        c.drawPath(prev, paint);

        c.drawRect(NEXT_X + 7, cy - 7, NEXT_X + 9, cy + 7, paint);
        Path next = new Path();
        next.moveTo(NEXT_X - 8, cy - 7);
        next.lineTo(NEXT_X + 5, cy);
        next.lineTo(NEXT_X - 8, cy + 7);
        next.close();
        c.drawPath(next, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(RED);
        paint.setStrokeWidth(2.2f);
        c.drawCircle(PLAY_X, cy, 17, paint);
        paint.setStyle(Paint.Style.FILL);
        if (playing) {
            c.drawRect(PLAY_X - 5, cy - 7, PLAY_X - 2, cy + 7, paint);
            c.drawRect(PLAY_X + 2, cy - 7, PLAY_X + 5, cy + 7, paint);
        } else {
            Path play = new Path();
            play.moveTo(PLAY_X - 4, cy - 8);
            play.lineTo(PLAY_X - 4, cy + 8);
            play.lineTo(PLAY_X + 8, cy);
            play.close();
            c.drawPath(play, paint);
        }

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(INK);
        paint.setStrokeWidth(1.5f);
        c.drawRect(292f, 510f, 342f, 538f, paint);
        text(c, "OPEN", 317f, 529f, 15f, INK, bebas, Paint.Align.CENTER, 0.1f);
    }
}
