package com.horizon.launcher;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Everything that changes from one day to the next: colour scheme, festival, scene and the text of every message spot. */
final class Look {

    /** Scenes that take part in the daily rotation. */
    static final String[] SCENE_IDS = {"lake", "peaks", "dunes", "sea", "city", "palms",
            "himalaya", "andaman", "taj", "jalmahal", "mehrangarh", "highway"};
    static final String[] SCENE_NAMES = {"LAKE", "PEAKS", "DESERT OASIS", "ISLANDS", "CITY", "PALMS",
            "HIMALAYA LAKE", "ANDAMAN BEACH", "TAJ MAHAL", "JAL MAHAL", "MEHRANGARH FORT", "MOUNTAIN HIGHWAY"};
    /** Scenes that can be picked by hand and appear by themselves only on their own day. */
    static final String[] DAY_IDS = {"redfort", "indiagate"};
    static final String[] DAY_NAMES = {"RED FORT", "INDIA GATE"};
    static final String[] PREVIEW_NAMES = {"DIWALI", "INDEPENDENCE DAY", "REPUBLIC DAY", "GANDHI JAYANTI",
            "MAKAR SANKRANTI", "HOLI", "EID AL-FITR", "CHRISTMAS", "NEW YEAR", "PONGAL", "GURU NANAK JAYANTI"};

    Palette pal = Palette.HORIZON;
    Festivals.Fest fest;
    String sceneId = "lake";
    String slogan1 = "", slogan2 = "", tagline = "", cornerL = "", cornerR = "", dayNote = "";
    int dayN;
    ContentPack pack;
    String key = "";
    long previewUntil = 0L;

    static Look compute(Context ctx, ContentPack pack, Calendar cal) {
        SharedPreferences sp = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
        Look l = new Look();
        l.pack = pack;
        l.dayN = Texts.dayNumber(cal);
        // every phone gets its own random starting point, so two phones show different picks on the same day
        int seed = sp.getInt("seed", 0);
        if (seed == 0) {
            seed = 1 + new java.util.Random().nextInt(1000000);
            sp.edit().putInt("seed", seed).apply();
        }
        final int off = seed % 997;

        boolean festOn = sp.getBoolean("fest", true);
        long until = sp.getLong("pv_until", 0L);
        String pvName = sp.getString("pv_name", null);
        if (pvName != null && System.currentTimeMillis() < until) {
            l.fest = Festivals.byName(pvName);
            if (l.fest != null) l.previewUntil = until;
        } else if (festOn) {
            l.fest = Festivals.find(cal, pack.festivals());
        }
        String want0 = sp.getString("pal", "AUTO");
        if (l.fest != null) {
            l.pal = Palette.byId(l.fest.palette);
        } else if ("AUTO".equals(want0)) {
            l.pal = Palette.DAILY[Math.floorMod(l.dayN + off, Palette.DAILY.length)];
        } else {
            l.pal = Palette.byId(want0);
        }

        // low battery: plain ink and paper (festival messages and scenes stay)
        if (sp.getBoolean("ink", false)) l.pal = Palette.INK;

        List<String> ids = new ArrayList<String>();
        for (String s : SCENE_IDS) ids.add(s);
        for (String[] ps : pack.scenes()) {
            if (!ids.contains(ps[0])) ids.add(ps[0]);
        }
        String want = sp.getString("scene", "AUTO");
        boolean wantDay = false;
        for (String s : DAY_IDS) if (s.equals(want)) wantDay = true;
        if (!"AUTO".equals(want) && (ids.contains(want) || wantDay)) {
            l.sceneId = want;
        } else {
            l.sceneId = ids.get(Math.floorMod(l.dayN + off * 3, ids.size()));
        }
        // the two national days always show their own scene (unless a scene was picked by hand)
        if (l.fest != null && "AUTO".equals(want)) {
            if ("INDEPENDENCE DAY".equals(l.fest.name)) l.sceneId = "redfort";
            else if ("REPUBLIC DAY".equals(l.fest.name)) l.sceneId = "indiagate";
        }

        int n = l.dayN + off;
        l.slogan1 = Texts.pick(Texts.SLOGAN1, pack.quotes("slogan1"), n, 1);
        l.slogan2 = Texts.pick(Texts.SLOGAN2, pack.quotes("slogan2"), n, 2);
        l.tagline = Texts.pick(Texts.TAGLINE, pack.quotes("tagline"), n, 3);
        l.cornerL = Texts.pick(Texts.CORNER_ALL, pack.quotes("cornerL"), n, 4);
        l.cornerR = Texts.pick(Texts.CORNER_ALL, pack.quotes("cornerR"), n, 5);
        l.dayNote = Texts.dayNote(cal, pack.quotes("dayNote"));

        if (l.fest != null) {
            if (l.fest.s1.length() > 0) l.slogan1 = l.fest.s1;
            if (l.fest.s2.length() > 0) l.slogan2 = l.fest.s2;
            if (l.fest.tagline.length() > 0) l.tagline = l.fest.tagline;
        }
        l.key = l.dayN + "|" + l.pal.id + "|" + l.sceneId + "|" + (l.fest == null ? "-" : l.fest.name);
        return l;
    }

    /** All scene choices as {id, name}: built-in first, then imported ones. */
    static List<String[]> allScenes(ContentPack pack) {
        List<String[]> out = new ArrayList<String[]>();
        for (int i = 0; i < SCENE_IDS.length; i++) out.add(new String[]{SCENE_IDS[i], SCENE_NAMES[i]});
        for (int i = 0; i < DAY_IDS.length; i++) out.add(new String[]{DAY_IDS[i], DAY_NAMES[i]});
        for (String[] ps : pack.scenes()) {
            boolean dup = false;
            for (String[] o : out) {
                if (o[0].equals(ps[0])) dup = true;
            }
            if (!dup) out.add(new String[]{ps[0], ps[1]});
        }
        return out;
    }
}
