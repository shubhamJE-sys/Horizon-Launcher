package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;

import java.io.InputStream;

/**
 * Draws a scene from three layers (land above the water line, clean water or ground, foreground shore).
 * Water scenes get a reflection: the land flipped at the water line, so every tree and building touches its own
 * reflection; it leans away from the sun or moon like a shadow, is longer when the body is low, and ripples slowly.
 * Dry scenes (no water) get long cast shadows on the ground instead.
 */
final class SceneRender {

    static final class Layers {
        Bitmap land, water, fg, cast;
        /** art scenes: a separate reflection layer (laid over the bare water) and a boat sprite */
        Bitmap refl, boat, tail;
        boolean art;
        int artW, shore;
        boolean dry;
        /** The lake (with its mirror image) is already part of the picture, so no reflection is drawn on top. */
        boolean baked;
        String id = "";
        Bitmap waterOnly() { return water; }
    }

    private static final int IMG_W = 1364, IMG_H = 944, WATER_ROW = 623;

    private SceneRender() { }

    /**
     * Fits the picture to the box without stretching: it is scaled until it covers the box, the shore line stays where the
     * sun and moon expect it, and whatever sticks out at the sides or the bottom is cut off by the caller's clip.
     * Returns {left, right, top, pixelScaleY, waterLineY}.
     */
    static float[] geo(float l, float r, float top, float bottom) {
        float bw = r - l, bh = bottom - top;
        float s = Math.max(bw / IMG_W, bh / IMG_H);
        float wy = top + WATER_ROW * (bh / IMG_H);
        float dw = IMG_W * s;
        float dl = l - (dw - bw) / 2f;
        float dtop = wy - WATER_ROW * s;
        return new float[]{dl, dl + dw, dtop, s, wy};
    }

    private static Bitmap decode(Context ctx, String name) throws Exception {
        InputStream in = ctx.getAssets().open(name);
        try {
            Bitmap b = BitmapFactory.decodeStream(in);
            if (b == null) throw new Exception("bad " + name);
            return b;
        } finally {
            in.close();
        }
    }

    /** The three layers of a built-in scene, or null (content-pack scenes are single pictures and are drawn the old way). */
    static Layers load(Context ctx, String id) {
        try {
            Layers l = new Layers();
            l.id = id;
            l.land = decode(ctx, "scene_" + id + "_land.webp");
            l.water = decode(ctx, "scene_" + id + "_water.webp");
            l.fg = decode(ctx, "scene_" + id + "_fg.webp");
            l.dry = l.fg.getWidth() < 20;
            l.baked = false;
            if ("himalaya".equals(id)) {
                l.art = true;
                l.refl = decode(ctx, "scene_himalaya_refl.webp");
                l.boat = decode(ctx, "scene_himalaya_boat.webp");
                l.artW = l.land.getWidth();
                l.shore = l.land.getHeight();
                l.dry = false;
                // the last rows of the lake as it looks with its reflection: the water below the picture is made from it
                int th = Math.min(40, l.water.getHeight());
                Bitmap t = Bitmap.createBitmap(l.water.getWidth(), th, Bitmap.Config.ARGB_8888);
                Canvas tc = new Canvas(t);
                Rect sr = new Rect(0, l.water.getHeight() - th, l.water.getWidth(), l.water.getHeight());
                Rect dr = new Rect(0, 0, l.water.getWidth(), th);
                tc.drawBitmap(l.water, sr, dr, null);
                tc.drawBitmap(l.refl, sr, dr, null);
                l.tail = t;
            }
            try { l.cast = decode(ctx, "scene_" + id + "_cast.webp"); } catch (Throwable ignored) { l.cast = null; }
            return l;
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * @param lean    sideways lean of the reflection per unit of depth (negative = leans left, i.e. sun on the right)
     * @param stretch how much longer than the object the reflection is (1 = same length, about 1.45 = sun on the horizon)
     * @param boat    this hour's boat, or null
     */
    static void draw(Canvas c, Layers L, Paint tinted, float l, float r, float top, float bottom,
                     float lean, float stretch, float nightK, long now, Boats.Spot boat) {
        draw(c, L, tinted, l, r, top, bottom, lean, stretch, nightK, now, boat, 76f);
    }

    /** @param fadeLen art scenes: how far the lake carries on below the box before it has faded to nothing */
    static void draw(Canvas c, Layers L, Paint tinted, float l, float r, float top, float bottom,
                     float lean, float stretch, float nightK, long now, Boats.Spot boat, float fadeLen) {
        if (L.art) {
            drawArt(c, L, tinted, l, r, top, bottom, lean, nightK, now, fadeLen);
            return;
        }
        float[] g = geo(l, r, top, bottom);
        final float ol = l, or = r;
        l = g[0];
        r = g[1];
        top = g[2];
        float sy = g[3];
        float wy = g[4];
        bottom = wy + (IMG_H - WATER_ROW) * sy;
        Paint bp = new Paint(tinted);
        bp.setFilterBitmap(true);

        c.drawBitmap(L.land, null, new RectF(l, top, r, wy), bp);
        c.drawBitmap(L.water, null, new RectF(l, wy, r, bottom), bp);
        if (L.baked) {
            c.drawBitmap(L.fg, null, new RectF(l, wy, r, bottom), bp);
            return;
        }

        if (L.dry) {
            castShadows(c, L.land, l, r, wy, bottom, lean, stretch, sy, nightK);
            return;
        }

        // reflection: the land flipped, in thin slices that are shifted sideways (lean + gentle ripple)
        int sv = c.saveLayer(l, wy, r, bottom, null);
        final int slice = 5;
        Rect src = new Rect();
        RectF dst = new RectF();
        for (int t = 0; t < WATER_ROW - 1; t += slice) {
            float d0 = t * stretch * sy;
            if (wy + d0 >= bottom) break;
            float y0 = wy + d0, y1 = wy + (t + slice) * stretch * sy;
            float wob = 0.8f * (float) Math.sin(now / 1500.0 + t * 0.05) * (0.3f + t / 330f);
            float dx = lean * d0 + wob;
            int s1 = WATER_ROW - 1 - t;
            int s0 = Math.max(0, s1 - slice);
            if (s1 <= 0) break;
            src.set(0, s0, IMG_W, s1);
            dst.set(l + dx, y0, r + dx, y1);
            c.save();
            c.scale(1f, -1f, 0f, (y0 + y1) / 2f);
            c.drawBitmap(L.land, src, dst, bp);
            c.restore();
        }
        Paint mask = new Paint();
        mask.setShader(new LinearGradient(0f, wy, 0f, bottom, 0xB8000000, 0x30000000, Shader.TileMode.CLAMP));
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawRect(l, wy, r, bottom, mask);
        c.restoreToCount(sv);

        ripples(c, l, r, wy, bottom, nightK, now);
        if (boat != null) {
            float x = l + boat.u * (r - l);
            float y = wy + boat.v * (bottom - wy);
            Boats.draw(c, tinted, boat, x, y, lean, nightK);
        }
        c.drawBitmap(L.fg, null, new RectF(l, wy, r, bottom), bp);
        if (L.cast != null) {
            // sandy scenes: palms and camels throw shadows on the sand (never into the pond, which has reflections)
            int sv2 = c.saveLayer(l, wy, r, bottom, null);
            castShadows(c, L.cast, l, r, wy, bottom, lean, stretch, sy, nightK);
            Paint keep = new Paint();
            keep.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawBitmap(L.fg, null, new RectF(l, wy, r, bottom), keep);
            c.restoreToCount(sv2);
        }
    }

    // ---------- art scenes (Himalaya): land, bare lake, reflection, boat and a full-height foreground ----------

    /** {left, right, landTop, scale, waterLineY, lakeBottom}: the picture fills the width, the shore stays where the sun expects it. */
    static float[] artGeo(Layers L, float l, float r, float top, float bottom) {
        float s = (r - l) / L.artW;
        float wy = top + WATER_ROW * ((bottom - top) / IMG_H);
        return new float[]{l, r, wy - L.shore * s, s, wy, wy + L.water.getHeight() * s};
    }

    private static void drawArt(Canvas c, Layers L, Paint tinted, float l, float r, float top, float bottom,
                                float lean, float nightK, long now, float fadeLen) {
        float[] g = artGeo(L, l, r, top, bottom);
        float s = g[3], wy = g[4], ab = g[5], lt = g[2];
        Paint bp = new Paint(tinted);
        bp.setFilterBitmap(true);
        float end = bottom + fadeLen;
        int sv = c.saveLayer(l, Math.min(top, lt), r, end, null);
        c.drawBitmap(L.land, null, new RectF(l, lt, r, wy + 0.6f), bp);
        c.drawBitmap(L.water, null, new RectF(l, wy, r, ab), bp);
        // the reflection leans away from the sun or moon like a shadow, in thin slices that also sway a little
        final int slice = 4;
        Rect src = new Rect();
        RectF dst = new RectF();
        int h = L.refl.getHeight();
        for (int t = 0; t < h; t += slice) {
            float y0 = wy + t * s, y1 = wy + Math.min(h, t + slice) * s + 0.35f;
            float wob = 0.7f * (float) Math.sin(now / 1500.0 + t * 0.05) * (0.3f + t / (float) h);
            float dx = lean * 0.5f * (t * s) + wob;
            src.set(0, t, L.artW, Math.min(h, t + slice));
            dst.set(l + dx, y0, r + dx, y1);
            c.drawBitmap(L.refl, src, dst, bp);
        }
        c.drawBitmap(L.fg, null, new RectF(l, lt, r, ab), bp);
        float ext = end - ab;
        if (ext > 1f) WaterExt.draw(c, L.tail, tinted, l, r, ab, ext, nightK, 0xFFF1E9D8, false);
        // the lake melts away below the picture box, well before the music deck and the greeting
        Paint mask = new Paint();
        float f0 = bottom - 6f, f1 = end - 2f;
        // short fade that keeps the lake strong for most of it and drops away only at the very end
        mask.setShader(new LinearGradient(0f, f0, 0f, f1, new int[]{0xFF000000, 0xC8000000, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawRect(l, f0, r, end, mask);
        c.restoreToCount(sv);
    }

    /** Where the boat is this hour: {u across the picture, v down the lake}; never in the glint. */
    static float[] boatSpot(long hourKey, float glintU) {
        java.util.Random rnd = new java.util.Random(hourKey * 7919L + 17L);
        float u = 0.5f, v = 0.2f;
        for (int i = 0; i < 24; i++) {
            u = 0.28f + rnd.nextFloat() * 0.46f;
            v = 0.08f + rnd.nextFloat() * 0.30f;
            if (glintU < 0f || Math.abs(u - glintU) > 0.10f) break;
        }
        return new float[]{u, v};
    }

    static void drawBoat(Canvas c, Layers L, Paint tinted, float l, float r, float top, float bottom,
                         float u, float v, long now, float nightK) {
        if (!L.art || L.boat == null) return;
        float[] g = artGeo(L, l, r, top, bottom);
        float s = g[3];
        float bw = L.boat.getWidth() * s, bh = L.boat.getHeight() * s;
        float x = l + u * (r - l);
        float y = g[4] + v * (g[5] - g[4]) + (float) Math.sin(now / 1300.0 + u * 9.0) * 0.45f;
        Paint bp = new Paint(tinted);
        bp.setFilterBitmap(true);
        float anchorY = bh * 0.84f;
        c.save();
        c.rotate((float) Math.sin(now / 1700.0 + u * 5.0) * 1.1f, x, y);
        // a faint upside-down shadow on the water
        c.save();
        c.scale(1f, -0.55f, x, y);
        Paint sp = new Paint(bp);
        sp.setAlpha(70);
        c.drawBitmap(L.boat, null, new RectF(x - bw / 2f, y - anchorY, x + bw / 2f, y - anchorY + bh), sp);
        c.restore();
        c.drawBitmap(L.boat, null, new RectF(x - bw / 2f, y - anchorY, x + bw / 2f, y - anchorY + bh), bp);
        c.restore();
    }

    /** 0 = open sky at this point, 1 = land in front of it: the sun or moon is hidden behind the mountains. */
    static float landCover(Layers L, float l, float r, float top, float bottom, float x, float y, float rad) {
        if (!L.art) return 0f;
        float[] g = artGeo(L, l, r, top, bottom);
        float s = g[3];
        float sum = 0f;
        int n = 0;
        for (int k = 0; k < 9; k++) {
            float dx = k == 0 ? 0f : (float) Math.cos(k * 0.785398) * rad;
            float dy = k == 0 ? 0f : (float) Math.sin(k * 0.785398) * rad;
            int px = (int) ((x + dx - l) / s), py = (int) ((y + dy - g[2]) / s);
            n++;
            if (px < 0 || py < 0 || px >= L.land.getWidth()) continue;
            if (py >= L.land.getHeight()) { sum += 1f; continue; }
            sum += ((L.land.getPixel(px, py) >>> 24) & 0xFF) / 255f;
        }
        return n == 0 ? 0f : sum / n;
    }

    /** Where the water is: draws the shimmer only through the holes of the foreground (never over sand or shore). */
    static void clipToWater(Canvas c, Layers L, float l, float r, float top, float bottom, float lo, float hi, Runnable drawGlint) {
        if (L.art) {
            float[] a = artGeo(L, l, r, top, bottom);
            int sv0 = c.saveLayer(l, lo, r, hi, null);
            drawGlint.run();
            Paint out0 = new Paint();
            out0.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            c.drawBitmap(L.fg, null, new RectF(l, a[2], r, a[5]), out0);
            c.restoreToCount(sv0);
            return;
        }
        float[] g = geo(l, r, top, bottom);
        float wy = g[4];
        float fgBottom = wy + (IMG_H - WATER_ROW) * g[3];
        int sv = c.saveLayer(l, lo, r, hi, null);
        drawGlint.run();
        Paint out = new Paint();
        out.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        c.drawBitmap(L.fg, null, new RectF(g[0], wy, g[1], fgBottom), out);
        if (L.baked) {
            // the lake is drawn in ink: the shimmer only shows where the ink leaves the water bare
            Paint ink = new Paint();
            ink.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            ink.setAlpha(205);
            c.drawBitmap(L.water, null, new RectF(g[0], wy, g[1], fgBottom), ink);
        }
        c.restoreToCount(sv);
    }

    /** Dry scenes: the base of everything standing on the ground throws a long, soft shadow away from the light. */
    private static void castShadows(Canvas c, Bitmap srcBmp, float l, float r, float wy, float bottom,
                                    float lean, float stretch, float sy, float nightK) {
        final int depthRows = 190;
        // shadows are longest when the sun is low and shorter towards noon; none at night
        float lowK = Math.max(0f, Math.min(1f, (stretch - 1f) / 0.45f));
        float lenK = 0.4f + 0.6f * lowK;
        float shade = 1f - nightK;
        if (shade < 0.05f) return;
        stretch = stretch * lenK;
        float reach = Math.min(bottom - wy, depthRows * stretch * sy * 1.4f);
        int sv = c.saveLayer(l, wy, r, wy + reach, null);
        Paint sp = new Paint();
        sp.setFilterBitmap(true);
        ColorMatrix cm = new ColorMatrix(new float[]{
                0.10f, 0, 0, 0, 6,
                0, 0.10f, 0, 0, 6,
                0, 0, 0.12f, 0, 10,
                0, 0, 0, 0.55f * shade, 0});
        sp.setColorFilter(new ColorMatrixColorFilter(cm));
        final int slice = 5;
        Rect src = new Rect();
        RectF dst = new RectF();
        for (int t = 0; t < depthRows; t += slice) {
            float d0 = t * stretch * sy * 1.4f;
            if (d0 >= reach) break;
            float y0 = wy + d0, y1 = wy + (t + slice) * stretch * sy * 1.4f;
            float dx = lean * 2.6f * d0;
            int s1 = WATER_ROW - 1 - t;
            int s0 = Math.max(0, s1 - slice);
            if (s1 <= 0) break;
            src.set(0, s0, IMG_W, s1);
            dst.set(l + dx, y0, r + dx, y1);
            c.save();
            c.scale(1f, -1f, 0f, (y0 + y1) / 2f);
            c.drawBitmap(srcBmp, src, dst, sp);
            c.restore();
        }
        Paint mask = new Paint();
        mask.setShader(new LinearGradient(0f, wy, 0f, wy + reach, 0xFF000000, 0x00000000, Shader.TileMode.CLAMP));
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawRect(l, wy, r, wy + reach, mask);
        c.restoreToCount(sv);
    }

    /** Faint light dashes on the water; they drift very slowly so the surface never looks frozen. */
    static void ripples(Canvas c, float l, float r, float top, float bottom, float nightK, long now) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF3EBDC);
        float k = 1f - 0.55f * nightK;
        float span = r - l;
        int rows = (int) ((bottom - top) / 3.3f);
        for (int i = 0; i < rows; i++) {
            float y = top + 1.5f + i * 3.3f + (float) Math.sin(i * 2.7) * 0.6f;
            float depth = i / (float) rows;
            for (int j = 0; j < 2; j++) {
                double h = Math.abs(Math.sin(i * 12.9898 + j * 78.233) * 43758.5453) % 1.0;
                double h2 = Math.abs(Math.sin(i * 4.1414 + j * 9.7) * 24634.6345) % 1.0;
                float len = 8f + (float) h2 * 46f;
                float x = l + (float) h * (span - len) + 3.5f * (float) Math.sin(now / 2600.0 + i * 1.7 + j);
                p.setAlpha((int) ((95 - 45 * depth) * k * (0.55f + 0.45f * (float) h2)));
                c.drawRect(x, y, x + len, y + 0.9f, p);
            }
        }
    }
}
