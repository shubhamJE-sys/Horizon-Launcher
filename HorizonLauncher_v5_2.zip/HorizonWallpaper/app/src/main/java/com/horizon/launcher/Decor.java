package com.horizon.launcher;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.Random;

/** Festival touches drawn into the sky (and, for lamps, along the water). All coordinates are design units. */
final class Decor {

    private Decor() { }

    private static final float[][] SPARK = {
            {40, 22, 5}, {318, 14, 4}, {150, 70, 3.5f}, {215, 120, 4.5f}, {84, 150, 3.5f}, {335, 205, 4},
            {18, 248, 4.5f}, {260, 262, 3.5f}, {120, 290, 5}, {318, 318, 4}, {60, 350, 3.5f}, {200, 340, 4.5f},
            {300, 120, 3}, {30, 118, 3}, {180, 20, 3}, {250, 200, 3}};

    private static void sparkle(Canvas c, Paint p, float cx, float cy, float r) {
        Path s = new Path();
        s.moveTo(cx, cy - r);
        s.quadTo(cx, cy, cx + r, cy);
        s.quadTo(cx, cy, cx, cy + r);
        s.quadTo(cx, cy, cx - r, cy);
        s.quadTo(cx, cy, cx, cy - r);
        s.close();
        p.setStyle(Paint.Style.FILL);
        c.drawPath(s, p);
    }

    /** Festival drawing behind the mountains. t = top of the scene box, lakeY = water line. */
    static void sky(Canvas c, Paint p, Sky sky, String decor, float t, float lakeY, long now) {
        if (decor == null || decor.length() == 0 || "NONE".equals(decor)) return;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        int minute = (int) (now / 60000L);
        float lift = 0.5f + 0.5f * sky.nightK;

        if ("SPARKLE".equals(decor) || "DIYA".equals(decor)) {
            int n = "DIYA".equals(decor) ? 9 : SPARK.length;
            for (int i = 0; i < n; i++) {
                float tw = 0.55f + 0.45f * (float) Math.sin((minute + i * 3) * 0.9);
                p.setColor(Color.parseColor("#F4C542"));
                p.setAlpha((int) (200 * lift * tw + 40));
                sparkle(c, p, SPARK[i][0], t - 241f + SPARK[i][1], SPARK[i][2] * (0.8f + 0.5f * tw));
            }
            p.setAlpha(255);
        } else if ("TRICOLOUR".equals(decor)) {
            p.setColor(Color.parseColor("#FF9933"));
            p.setAlpha(46);
            c.drawRect(-60f, -60f, 420f, 130f, p);
            p.setColor(Color.WHITE);
            p.setAlpha(40);
            c.drawRect(-60f, 130f, 420f, 264f, p);
            p.setColor(Color.parseColor("#138808"));
            p.setAlpha(44);
            c.drawRect(-60f, 264f, 420f, lakeY, p);
            p.setAlpha(255);
            // Ashoka chakra
            float cx = 44f, cy = t + 66f, r = 11f;
            p.setStyle(Paint.Style.STROKE);
            p.setColor(Color.parseColor("#1B3F94"));
            p.setAlpha(220);
            p.setStrokeWidth(1.2f);
            c.drawCircle(cx, cy, r, p);
            for (int i = 0; i < 12; i++) {
                double a = Math.PI * 2 * i / 12.0;
                c.drawLine(cx, cy, cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, p);
            }
            p.setAlpha(255);
            p.setStyle(Paint.Style.FILL);
        } else if ("CRESCENT".equals(decor)) {
            Path moon = new Path();
            moon.addCircle(298f, t + 52f, 17f, Path.Direction.CW);
            Path cut = new Path();
            cut.addCircle(305f, t + 47f, 14.5f, Path.Direction.CW);
            moon.op(cut, Path.Op.DIFFERENCE);
            p.setColor(Color.parseColor("#F4D26B"));
            c.drawPath(moon, p);
            sparkle(c, p, 322f, t + 40f, 6f);
            p.setAlpha(170);
            sparkle(c, p, 270f, t + 80f, 4f);
            p.setAlpha(255);
        } else if ("COLOURS".equals(decor)) {
            String[] cols = {"#E91E63", "#FFC107", "#4CAF50", "#2196F3", "#FF5722", "#9C27B0", "#00BCD4"};
            Random r = new Random(5);
            for (int i = 0; i < 16; i++) {
                float x = 10f + r.nextFloat() * 340f;
                float y = t - 190f + r.nextFloat() * 300f;
                float rad = 10f + r.nextFloat() * 22f;
                p.setColor(Color.parseColor(cols[i % cols.length]));
                p.setAlpha(64 + (int) (r.nextFloat() * 40f));
                c.drawCircle(x, y, rad, p);
                p.setAlpha(120);
                c.drawCircle(x + rad * 0.5f, y - rad * 0.4f, rad * 0.22f, p);
            }
            p.setAlpha(255);
        } else if ("KITES".equals(decor)) {
            String[] cols = {"#F57C00", "#E91E63", "#00897B", "#FBC02D", "#5E35B1"};
            float[][] pos = {{60, 40}, {250, 70}, {140, 18}, {312, 28}, {200, 110}};
            for (int i = 0; i < pos.length; i++) {
                float cx = pos[i][0], cy = t + pos[i][1], s = 0.8f + 0.1f * (i % 3);
                Path k = new Path();
                k.moveTo(cx, cy - 12f * s);
                k.lineTo(cx + 8f * s, cy);
                k.lineTo(cx, cy + 16f * s);
                k.lineTo(cx - 8f * s, cy);
                k.close();
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.parseColor(cols[i % cols.length]));
                p.setAlpha(225);
                c.drawPath(k, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(0.8f);
                p.setColor(Sky.INK);
                p.setAlpha(150);
                c.drawLine(cx, cy - 12f * s, cx, cy + 16f * s, p);
                c.drawLine(cx - 8f * s, cy, cx + 8f * s, cy, p);
                Path tail = new Path();
                tail.moveTo(cx, cy + 16f * s);
                tail.quadTo(cx + 9f * s, cy + 24f * s, cx - 3f * s, cy + 34f * s);
                c.drawPath(tail, p);
            }
            p.setAlpha(255);
            p.setStyle(Paint.Style.FILL);
        } else if ("SNOW".equals(decor)) {
            Random r = new Random(9);
            p.setColor(Color.WHITE);
            for (int i = 0; i < 70; i++) {
                float x = r.nextFloat() * 360f;
                float y = t - 200f + r.nextFloat() * (lakeY - t + 200f);
                p.setAlpha(150 + (int) (r.nextFloat() * 90f));
                c.drawCircle(x, y, 1f + r.nextFloat() * 1.5f, p);
            }
            p.setAlpha(255);
        }
    }

    private static android.graphics.Bitmap[] DIYAS, FLAMES;
    private static float[][] TIPS;

    private static android.graphics.Bitmap load(android.content.Context ctx, String n) {
        try {
            java.io.InputStream in = ctx.getAssets().open(n);
            try { return android.graphics.BitmapFactory.decodeStream(in); } finally { in.close(); }
        } catch (Throwable t) { return null; }
    }

    private static void ensure(android.content.Context ctx) {
        if (DIYAS != null) return;
        android.graphics.Bitmap[] d = new android.graphics.Bitmap[6], f = new android.graphics.Bitmap[6];
        float[][] tips = new float[6][2];
        for (int i = 0; i < 6; i++) {
            d[i] = load(ctx, "diya_" + i + ".webp");
            f[i] = load(ctx, "flame_" + i + ".webp");
            // the wick's tip: the highest solid pixels, as a share of the picture
            tips[i][0] = 0.5f; tips[i][1] = 0.1f;
            if (d[i] != null) {
                int w = d[i].getWidth(), h = d[i].getHeight();
                outer:
                for (int y = 0; y < h; y++) {
                    long sx = 0; int n = 0;
                    for (int x = 0; x < w; x++) {
                        if (Color.alpha(d[i].getPixel(x, y)) > 140) { sx += x; n++; }
                    }
                    if (n > 0) { tips[i][0] = sx / (float) n / w; tips[i][1] = (y + 2) / (float) h; break outer; }
                }
            }
        }
        DIYAS = d; FLAMES = f; TIPS = tips;
    }

    /** Lamps per row, from the far shore to the rocks: more and smaller far away, fewer and bigger near. */
    private static final float[] ROW_DY = {3f, 10f, 18f, 27f, 37f, 48f, 60f, 70f};
    private static final float[] ROW_SC = {0.30f, 0.36f, 0.44f, 0.54f, 0.66f, 0.80f, 0.94f, 1.0f};
    private static final int[] ROW_N = {6, 5, 4, 4, 3, 2, 1, 1};
    private static final float[] ROW_X0 = {92f, 80f, 66f, 54f, 42f, 34f, 30f, 30f};

    /** Festival drawing in front of the water: lamps floating all over the lake, with light, haze and reflections. */
    static void front(android.content.Context ctx, Canvas c, Paint p, Sky sky, String decor, float lakeY, long now, String scene, boolean dry, float floorY) {
        if (floorY > 0f) {
            // lamps, ripples, reflections and glow stop at the pavement edge
            c.save();
            c.clipRect(-400f, -400f, 800f, floorY);
            try { frontInner(ctx, c, p, sky, decor, lakeY, now, scene, dry, floorY); } finally { c.restore(); }
            return;
        }
        frontInner(ctx, c, p, sky, decor, lakeY, now, scene, dry, floorY);
    }

    private static void frontInner(android.content.Context ctx, Canvas c, Paint p, Sky sky, String decor, float lakeY, long now, String scene, boolean dry, float floorY) {
        if (!"DIYA".equals(decor)) return;
        ensure(ctx);
        if (DIYAS == null || DIYAS[0] == null) return;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        // warm light in the middle of the valley, haze at the far shore
        RadialGradient valley = new RadialGradient(180f, lakeY - 6f, 150f,
                Color.argb(70, 255, 196, 90), Color.argb(0, 255, 196, 90), Shader.TileMode.CLAMP);
        p.setShader(valley);
        c.drawRect(30f, lakeY - 150f, 330f, lakeY + 70f, p);
        p.setShader(null);
        Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        Random r = new Random(11);
        int k = 0;
        // each scene has its own water: a valley that narrows far away, a long pool, an open lake, or dry ground
        float dyk = floorY > 0f ? Math.min(1f, Math.max(0.3f, (floorY - lakeY - 16f) / 70f)) : 1f;
        boolean narrowV = "himalaya".equals(scene) || "peaks".equals(scene);
        boolean pool = "indiagate".equals(scene);
        for (int row = 0; row < ROW_N.length; row++) {
            if (dry && row < 5) continue;                  // dry ground: only the near rows, lined along the foreground
            float sc = ROW_SC[row];
            int n = dry ? ROW_N[row] * 3 : ROW_N[row];
            for (int j = 0; j < n; j++, k++) {
                float u = (j + 0.5f + (r.nextFloat() - 0.5f) * 0.55f) / n;
                float rx0 = narrowV ? ROW_X0[row] : (pool ? 78f + row * 1.5f : 14f);   // a mountain valley narrows far away; a city river or open lake spans the whole width
                float x = rx0 + u * (360f - 2f * rx0);
                float y = lakeY + ROW_DY[row] * dyk + (r.nextFloat() - 0.5f) * 4f + (float) Math.sin(now / 1900.0 + k) * 0.5f;
                int si = k % 6;
                android.graphics.Bitmap dy = DIYAS[si];
                android.graphics.Bitmap fl = FLAMES[(int) ((now / 130L + k * 3) % 6)];
                float dw = 18f * sc;                      // 10 percent smaller than before
                float dh = dw * dy.getHeight() / dy.getWidth();
                float flick = 0.85f + 0.15f * (float) Math.sin(now / 95.0 + k * 1.7) * (float) Math.sin(now / 210.0 + k);
                // glow pool on the water
                p.setShader(new RadialGradient(x, y, 26f * sc + 8f, Color.argb((int) (95 * flick), 255, 190, 70),
                        Color.argb(0, 255, 190, 70), Shader.TileMode.CLAMP));
                c.drawOval(new RectF(x - 30f * sc - 8f, y - 6f * sc, x + 30f * sc + 8f, y + 10f * sc), p);
                p.setShader(null);
                // ripple rings and reflection
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(0.6f);
                p.setColor(Color.argb(110, 255, 225, 150));
                float rp = (now / 2600f + k * 0.37f) % 1f;
                c.drawOval(new RectF(x - dw * (0.6f + rp * 0.7f), y + dh * 0.45f - 1f * sc, x + dw * (0.6f + rp * 0.7f), y + dh * 0.45f + 2.4f * sc), p);
                p.setStyle(Paint.Style.FILL);
                bp.setAlpha(70);
                c.save();
                c.scale(1f, -0.55f, x, y + dh * 0.5f);
                c.drawBitmap(dy, null, new RectF(x - dw / 2f, y - dh * 0.5f, x + dw / 2f, y + dh * 0.5f), bp);
                c.restore();
                bp.setAlpha(255);
                // the lamp
                RectF dr = new RectF(x - dw / 2f, y - dh * 0.5f, x + dw / 2f, y + dh * 0.5f);
                c.drawBitmap(dy, null, dr, bp);
                // the flame stands on the wick's tip
                float tx = dr.left + TIPS[si][0] * dw, ty = dr.top + TIPS[si][1] * dh;
                float fh = 15f * sc * (0.9f + 0.1f * flick), fw = fh * fl.getWidth() / fl.getHeight();
                p.setShader(new RadialGradient(tx, ty - fh * 0.4f, fh * 1.3f, Color.argb((int) (150 * flick), 255, 210, 110),
                        Color.argb(0, 255, 190, 70), Shader.TileMode.CLAMP));
                c.drawCircle(tx, ty - fh * 0.4f, fh * 1.3f, p);
                p.setShader(null);
                c.drawBitmap(fl, null, new RectF(tx - fw / 2f, ty - fh + 1f, tx + fw / 2f, ty + 1f), bp);
            }
        }
        p.setAlpha(255);
    }
}
