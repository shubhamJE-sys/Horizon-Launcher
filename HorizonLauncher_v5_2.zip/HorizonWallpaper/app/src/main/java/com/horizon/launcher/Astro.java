package com.horizon.launcher;

import java.util.Calendar;

/**
 * Low-precision sun and moon positions (accurate to a fraction of a degree, plenty for a poster).
 * Everything is computed on the phone from the date and the place; no internet needed.
 */
final class Astro {

    private Astro() { }

    static final double RAD = Math.PI / 180.0;

    /** Result for one body for "now": whether it is above the horizon and how far along its arc it is. */
    static final class Arc {
        boolean up;
        float t;            // 0 at rising, 1 at setting
        float maxAlt;       // highest altitude of this arc, degrees
        double phase;       // moon only: 0 new, 0.5 full, below 0.5 waxing
        double distKm;      // moon only
    }

    private static double jd(long ms) {
        return ms / 86400000.0 + 2440587.5;
    }

    private static double norm360(double d) {
        d = d % 360.0;
        return d < 0 ? d + 360.0 : d;
    }

    private static double kepler(double mDeg, double e) {
        double E = mDeg + e / RAD * Math.sin(mDeg * RAD) * (1.0 + e * Math.cos(mDeg * RAD));
        for (int i = 0; i < 6; i++) {
            double dE = (E - e / RAD * Math.sin(E * RAD) - mDeg) / (1.0 - e * Math.cos(E * RAD));
            E -= dE;
            if (Math.abs(dE) < 1e-5) break;
        }
        return E;
    }

    /** {ecliptic longitude deg, ra deg, dec deg, mean longitude of the sun deg} */
    private static double[] sunEq(double d) {
        double w = 282.9404 + 4.70935e-5 * d;
        double e = 0.016709 - 1.151e-9 * d;
        double M = norm360(356.0470 + 0.9856002585 * d);
        double ecl = 23.4393 - 3.563e-7 * d;
        double E = kepler(M, e);
        double xv = Math.cos(E * RAD) - e;
        double yv = Math.sqrt(1.0 - e * e) * Math.sin(E * RAD);
        double v = Math.atan2(yv, xv) / RAD;
        double lon = norm360(v + w);
        double xs = Math.cos(lon * RAD), ys = Math.sin(lon * RAD);
        double ye = ys * Math.cos(ecl * RAD), ze = ys * Math.sin(ecl * RAD);
        double ra = norm360(Math.atan2(ye, xs) / RAD);
        double dec = Math.atan2(ze, Math.sqrt(xs * xs + ye * ye)) / RAD;
        return new double[]{lon, ra, dec, norm360(M + w)};
    }

    /** {ra deg, dec deg, distance in earth radii, ecliptic longitude deg} */
    private static double[] moonEq(double d) {
        double N = norm360(125.1228 - 0.0529538083 * d);
        double i = 5.1454;
        double w = norm360(318.0634 + 0.1643573223 * d);
        double a = 60.2666, e = 0.054900;
        double M = norm360(115.3654 + 13.0649929509 * d);
        double E = kepler(M, e);
        double xv = a * (Math.cos(E * RAD) - e);
        double yv = a * Math.sqrt(1.0 - e * e) * Math.sin(E * RAD);
        double v = Math.atan2(yv, xv) / RAD;
        double r = Math.sqrt(xv * xv + yv * yv);
        double vw = (v + w) * RAD;
        double xh = r * (Math.cos(N * RAD) * Math.cos(vw) - Math.sin(N * RAD) * Math.sin(vw) * Math.cos(i * RAD));
        double yh = r * (Math.sin(N * RAD) * Math.cos(vw) + Math.cos(N * RAD) * Math.sin(vw) * Math.cos(i * RAD));
        double zh = r * Math.sin(vw) * Math.sin(i * RAD);
        double lon = Math.atan2(yh, xh) / RAD;
        double lat = Math.atan2(zh, Math.sqrt(xh * xh + yh * yh)) / RAD;

        double ws = 282.9404 + 4.70935e-5 * d;
        double Ms = norm360(356.0470 + 0.9856002585 * d);
        double Ls = Ms + ws;
        double Lm = M + w + N;
        double D = Lm - Ls;
        double F = Lm - N;
        double Mm = M;
        lon += -1.274 * s(Mm - 2 * D) + 0.658 * s(2 * D) - 0.186 * s(Ms) - 0.059 * s(2 * Mm - 2 * D)
                - 0.057 * s(Mm - 2 * D + Ms) + 0.053 * s(Mm + 2 * D) + 0.046 * s(2 * D - Ms) + 0.041 * s(Mm - Ms)
                - 0.035 * s(D) - 0.031 * s(Mm + Ms) - 0.015 * s(2 * F - 2 * D) + 0.011 * s(Mm - 4 * D);
        lat += -0.173 * s(F - 2 * D) - 0.055 * s(Mm - F - 2 * D) - 0.046 * s(Mm + F - 2 * D)
                + 0.033 * s(F + 2 * D) + 0.017 * s(2 * Mm + F);
        r += -0.58 * Math.cos((Mm - 2 * D) * RAD) - 0.46 * Math.cos(2 * D * RAD);
        double ecl = 23.4393 - 3.563e-7 * d;
        double xg = r * Math.cos(lon * RAD) * Math.cos(lat * RAD);
        double yg = r * Math.sin(lon * RAD) * Math.cos(lat * RAD);
        double zg = r * Math.sin(lat * RAD);
        double ye = yg * Math.cos(ecl * RAD) - zg * Math.sin(ecl * RAD);
        double ze = yg * Math.sin(ecl * RAD) + zg * Math.cos(ecl * RAD);
        double ra = norm360(Math.atan2(ye, xg) / RAD);
        double dec = Math.atan2(ze, Math.sqrt(xg * xg + ye * ye)) / RAD;
        return new double[]{ra, dec, r, norm360(lon)};
    }

    private static double s(double deg) {
        return Math.sin(deg * RAD);
    }

    private static double altitude(double raDeg, double decDeg, long ms, double lat, double lon) {
        double j = jd(ms);
        double gmst = norm360(280.46061837 + 360.98564736629 * (j - 2451545.0));
        double ha = (gmst + lon - raDeg) * RAD;
        double sa = Math.sin(lat * RAD) * Math.sin(decDeg * RAD)
                + Math.cos(lat * RAD) * Math.cos(decDeg * RAD) * Math.cos(ha);
        return Math.asin(Math.max(-1.0, Math.min(1.0, sa))) / RAD;
    }

    static double sunAlt(long ms, double lat, double lon) {
        double[] q = sunEq(jd(ms) - 2451543.5);
        return altitude(q[1], q[2], ms, lat, lon) + 0.0;
    }

    /** Altitude of the moon's upper limb seen from the ground (parallax, refraction and size taken into account). */
    static double moonAlt(long ms, double lat, double lon) {
        double[] q = moonEq(jd(ms) - 2451543.5);
        double geo = altitude(q[0], q[1], ms, lat, lon);
        double par = Math.asin(1.0 / q[2]) / RAD;
        return geo - par * Math.cos(geo * RAD);
    }

    static double moonDistanceKm(long ms) {
        return moonEq(jd(ms) - 2451543.5)[2] * 6378.14;
    }

    /** 0 = new moon, 0.5 = full moon; below 0.5 the right side is lit (waxing). */
    static double moonPhase(long ms) {
        double d = jd(ms) - 2451543.5;
        double el = norm360(moonEq(d)[3] - sunEq(d)[0]);
        return el / 360.0;
    }

    private static final double SUN_H0 = -0.833;
    private static final double MOON_H0 = -0.83;

    /** Where is the sun (or moon) on its arc right now. */
    static Arc arc(boolean moon, long now, double lat, double lon) {
        Arc a = new Arc();
        double h0 = moon ? MOON_H0 : SUN_H0;
        double alt = moon ? moonAlt(now, lat, lon) : sunAlt(now, lat, lon);
        if (moon) {
            a.phase = moonPhase(now);
            a.distKm = moonDistanceKm(now);
        }
        a.up = alt > h0;
        if (!a.up) return a;
        final long step = 5L * 60000L;
        long rise = now, set = now;
        for (int k = 0; k < 330; k++) {
            long t = now - k * step;
            double v = moon ? moonAlt(t, lat, lon) : sunAlt(t, lat, lon);
            if (v <= h0) {
                rise = t + step / 2;
                break;
            }
            rise = t;
        }
        for (int k = 0; k < 330; k++) {
            long t = now + k * step;
            double v = moon ? moonAlt(t, lat, lon) : sunAlt(t, lat, lon);
            if (v <= h0) {
                set = t - step / 2;
                break;
            }
            set = t;
        }
        if (set <= rise) set = rise + step;
        a.t = (float) Math.max(0.0, Math.min(1.0, (now - rise) / (double) (set - rise)));
        long mid = (rise + set) / 2L;
        a.maxAlt = (float) (moon ? moonAlt(mid, lat, lon) : sunAlt(mid, lat, lon));
        return a;
    }

    /** Sunrise and sunset of the calendar day of cal, as minutes since local midnight; null if the sun never crosses. */
    static int[] sunTimes(Calendar cal, double lat, double lon) {
        Calendar c = (Calendar) cal.clone();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long t0 = c.getTimeInMillis();
        int rise = -1, set = -1;
        double prev = sunAlt(t0, lat, lon);
        for (int m = 1; m <= 1440; m++) {
            double v = sunAlt(t0 + m * 60000L, lat, lon);
            if (prev <= SUN_H0 && v > SUN_H0 && rise < 0) rise = m;
            if (prev > SUN_H0 && v <= SUN_H0 && rise >= 0 && set < 0) set = m;
            prev = v;
        }
        if (rise < 0 || set < 0) return null;
        return new int[]{rise, Math.min(1439, set)};
    }

    /** Moonrise and moonset of the calendar day of cal (minutes since midnight, -1 when it does not happen that day). */
    static int[] moonTimes(Calendar cal, double lat, double lon) {
        Calendar c = (Calendar) cal.clone();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long t0 = c.getTimeInMillis();
        int rise = -1, set = -1;
        double prev = moonAlt(t0, lat, lon);
        for (int m = 1; m <= 1440; m += 2) {
            double v = moonAlt(t0 + m * 60000L, lat, lon);
            if (prev <= MOON_H0 && v > MOON_H0 && rise < 0) rise = m;
            if (prev > MOON_H0 && v <= MOON_H0 && set < 0) set = m;
            prev = v;
        }
        return new int[]{rise < 0 ? -1 : Math.min(1439, rise), set < 0 ? -1 : Math.min(1439, set)};
    }

    /** Can the moon be seen from this place? {headline, detail} for the next 36 hours; cloud is 0..1. */
    static String[] moonView(long now, double lat, double lon, float cloud, boolean h24) {
        double ill = illumination(moonPhase(now));
        if (ill < 0.03) return new String[]{"NOT VISIBLE", "NEW MOON: TOO THIN TO SEE"};
        final long step = 5L * 60000L;
        long from = -1, to = -1;
        boolean nowVis = false;
        for (int k = 0; k <= 432; k++) {
            long t = now + k * step;
            double ma = moonAlt(t, lat, lon), sa = sunAlt(t, lat, lon);
            boolean vis = ma > 4.0 && (sa < -4.0 || (ill >= 0.25 && ma > 10.0));
            if (k == 0) nowVis = vis;
            if (vis) {
                if (from < 0) from = t;
                to = t;
            } else if (from >= 0) {
                break;
            }
        }
        if (from < 0) return new String[]{"NOT VISIBLE", "IT IS NOT UP IN A DARK SKY FOR THE NEXT 36 HOURS"};
        String span = whenText(from, now, h24) + " TO " + whenText(to, now, h24);
        String cl = cloud >= 0.7f ? "  (CLOUDS MAY HIDE IT)" : "";
        if (nowVis) return new String[]{"YES, VISIBLE NOW", "UNTIL " + whenText(to, now, h24) + cl};
        boolean later = !whenText(from, now, h24).endsWith("TOMORROW");
        return new String[]{later ? "NOT NOW, BUT LATER TODAY" : "NOT TODAY, BUT TOMORROW", "SEEN " + span + cl};
    }

    private static String whenText(long t, long now, boolean h24) {
        Calendar a = Calendar.getInstance(), b = Calendar.getInstance();
        a.setTimeInMillis(now);
        b.setTimeInMillis(t);
        int mins = b.get(Calendar.HOUR_OF_DAY) * 60 + b.get(Calendar.MINUTE);
        String c = InfoCards.clock(mins, h24);
        return a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR) ? c : c + " TOMORROW";
    }

    /** Name of the moon phase for a phase value (0 new, 0.5 full). */
    static String phaseName(double ph) {
        double p = ph - Math.floor(ph);
        if (p < 0.03 || p > 0.97) return "NEW MOON";
        if (p < 0.22) return "WAXING CRESCENT";
        if (p < 0.28) return "FIRST QUARTER";
        if (p < 0.47) return "WAXING GIBBOUS";
        if (p < 0.53) return "FULL MOON";
        if (p < 0.72) return "WANING GIBBOUS";
        if (p < 0.78) return "LAST QUARTER";
        return "WANING CRESCENT";
    }

    /** Lit part of the moon's disc, 0..1. */
    static double illumination(double ph) {
        return (1.0 - Math.cos(2.0 * Math.PI * ph)) / 2.0;
    }
}
