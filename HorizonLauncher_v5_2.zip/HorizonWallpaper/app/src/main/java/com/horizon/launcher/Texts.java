package com.horizon.launcher;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Message pools. Every pool uses '|' for line breaks. A pick stays the same all day and changes at midnight. */
final class Texts {

    static final String[] SLOGAN1 = {
            "SAME SKY|DIFFERENT|STORY", "NEW DAY|NEW|CHAPTER", "BREATHE IN|BREATHE|OUT",
            "STAY|CURIOUS|STAY KIND", "SMALL STEPS|BIG|HORIZONS", "BE HERE|BE NOW|BE WELL",
            "FOLLOW|THE|LIGHT", "MAKE|TODAY|COUNT", "QUIET MIND|LOUD|DREAMS", "ONE DAY|AT A|TIME",
            "KEEP|GOING|GENTLY", "WALK|WITHOUT|HURRY", "CHASE|THE|SUNRISE", "TRUST|THE|PROCESS",
            "LET GO|LIGHTEN|UP", "SLOW IS|STILL|FORWARD", "FIND|YOUR|PACE", "GROW|QUIETLY",
            "LIVE|LIGHT", "RISE|AND|SHINE", "DREAM|IN|COLOUR", "STAY|WILD|AT HEART",
            "LESS|NOISE|MORE SKY", "BE THE|CALM|IN IT", "COUNT|SUNSETS|NOT HOURS",
            "HOME IS|A STATE|OF MIND", "WORK|HARD|REST WELL", "SEE|THE GOOD|TODAY",
            "START|BEFORE|READY", "FIX|ONE|THING", "STAY CLOSE|TO|NATURE", "BE A|LITTLE|BRAVER"};

    static final String[] SLOGAN2 = {
            "A CALMER|WIND A|BRIGHTER|DAY", "MORE SKY|LESS|SCREEN", "LET THE|LIGHT IN|TODAY",
            "GOOD VIBES|ONLY|LOADING", "SOFT|MORNINGS|BOLD|DAYS", "EASY|DOES IT|TODAY",
            "BE|GENTLE|WITH|YOURSELF", "TAKE|THE|LONG|WAY ROUND", "LOOK UP|THE SKY|IS FREE",
            "NOTHING|TO PROVE|JUST TO|BE", "WIND|DOWN|WARM|UP", "KEEP|YOUR|FACE TO|THE SUN",
            "THE BEST|VIEW|COMES AFTER|THE CLIMB", "SLOW|DOWN|YOU ARE|DOING FINE",
            "TODAY|IS A|GOOD DAY|TO START", "COLLECT|MOMENTS|NOT|THINGS", "BREATHE|DEEP|SMILE|SOFT",
            "FRESH|AIR|FRESH|MIND", "WHAT YOU|SEEK|IS SEEKING|YOU", "SMALL|JOYS|MATTER",
            "LET IT|BE|LIGHT", "RIDE|THE|WIND", "STILL|WATERS|DEEP|THOUGHTS", "ONE|STEP|IS|ENOUGH",
            "MAKE|SPACE|FOR|SILENCE", "STAY|GROUNDED|REACH|HIGH", "BLUE|HOURS|GOLDEN|HOURS",
            "THE WORLD|IS WIDE|GO SEE", "DO IT|WITH|LOVE", "BETTER|DAYS|ARE|COMING"};

    static final String[] TAGLINE = {
            "GOOD THINGS STILL HAPPEN HERE", "TODAY IS A FRESH PAGE", "YOU ARE EXACTLY ON TIME",
            "BE KIND TO YOUR FUTURE SELF", "THE BEST IS YET TO COME", "MAKE SMALL MOMENTS BIG",
            "LET TODAY BE ENOUGH", "SOMEWHERE THE SUN IS RISING", "YOUR PACE IS PERFECT",
            "BREATHE. YOU ARE DOING FINE", "KEEP THE FAITH, KEEP WALKING",
            "EVERY SUNSET PROMISES A SUNRISE", "SEE THE GOOD IN TODAY", "STAY CURIOUS, STAY KIND",
            "DREAM BIG, START SMALL", "PEACE BEGINS WITH A PAUSE", "NOTICE THE LITTLE THINGS",
            "TODAY, CHOOSE JOY", "LOOK UP, THE SKY IS LISTENING", "ENJOY THE QUIET BETWEEN HOURS",
            "HAPPINESS IS A QUIET HABIT", "WELCOME THE UNEXPECTED", "WHAT YOU WATER, GROWS",
            "THE SKY IS ALWAYS THERE FOR YOU", "SLOW MORNINGS, STEADY DAYS",
            "THANK THE DAY BEFORE IT ENDS", "A GOOD DAY STARTS WITH A SMILE",
            "BE THE REASON SOMEONE SMILES", "LIGHT AFTER EVERY NIGHT",
            "WORK WITH PURPOSE, REST WITH PEACE", "LET GO OF WHAT WEIGHS YOU DOWN",
            "LIFE IS HAPPENING RIGHT NOW", "FOLLOW YOUR OWN HORIZON", "BRING A LITTLE KINDNESS TODAY",
            "SMALL STEPS, BIG VIEWS", "YOU HAVE COME SO FAR"};

    static final String[] CORNER_L = {
            "LESS|SCROLLING|MORE|HORIZONS", "LOOK UP|MORE|OFTEN", "SLOW|DOWN|BREATHE|IN",
            "CHASE|LIGHT|NOT|LIKES", "FEWER|TABS|MORE|TREES", "TOUCH|GRASS|TODAY", "PAUSE|SIP|SMILE",
            "GO|OUTSIDE|SOON", "WANDER|WONDER|REPEAT", "STAY|LOCAL|THINK|WIDE",
            "SOFT|LIGHT|LONG|SHADOWS", "LISTEN|TO THE|WIND", "WALK|A LITTLE|FURTHER",
            "TRADE|NOISE|FOR|BIRDS", "FIND|THE|QUIET", "MORE|SKY|PLEASE", "WATCH|THE|CLOUDS|DRIFT",
            "KEEP|YOUR|EYES|OPEN", "HEAD|FOR|THE|HILLS", "BE|WHERE|YOUR|FEET ARE",
            "RIVERS|KNOW|THE WAY", "FOLLOW|THE|BIRDS", "MAKE|TIME|FOR|WATER", "SUN|SALT|SKY",
            "EVERY|DAY|A SMALL|ESCAPE", "ROAD|WIDE|OPEN", "NATURE|NEEDS|NO|WIFI", "STEP|OUTSIDE",
            "LIVE|SLOW|SEE|MORE", "BREATHE|THE|MORNING"};

    static final String[] CORNER_R = {
            "DISCONNECT|EXPLORE BREATHE|REPEAT", "LOOK UP|SLOW DOWN|BREATHE", "WANDER|WONDER|RETURN",
            "LISTEN|NOTICE|APPRECIATE", "REST|RESET|RISE", "UNPLUG|UNWIND|UNFOLD",
            "BREATHE|STRETCH|SMILE", "ARRIVE|LINGER|LEAVE LIGHT", "PAUSE|REFLECT|BEGIN AGAIN",
            "GATHER|GROW|GIVE", "STAY|WATCH|WAIT", "CLIMB|REST|REPEAT", "SEEK|FIND|SHARE",
            "WALK|THINK|LET GO", "SUNRISE|SUNSET|REPEAT", "BE STILL|BE OPEN|BE HERE",
            "FOCUS|FLOW|FINISH", "LIGHT|AIR|WATER", "BREATHE IN|BREATHE OUT|BEGIN",
            "WORK|WALK|WONDER", "EARTH|SKY|YOU", "TODAY|IS|A GIFT", "SLOW|STEADY|SURE",
            "NOTICE|NAME|LET GO", "CALM|CLEAR|KIND", "ROOTED|RISING|RADIANT",
            "SMILE|BREATHE|GO ON", "OPEN SKY|OPEN HEART|OPEN ROAD", "MOVE|BREATHE|CREATE",
            "ASK|LISTEN|GROW"};

    /** The left and right corner pools joined into one. */
    static final String[] CORNER_ALL = joinPools(CORNER_L, CORNER_R);

    private static String[] joinPools(String[] a, String[] b) {
        String[] r = new String[a.length + b.length];
        System.arraycopy(a, 0, r, 0, a.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        return r;
    }

    static final String[] BAT_CHARGING = {
            "Charging up — good things take a little time.", "Plugged in and powering back.",
            "Recharge now, shine later.", "Energy is on its way — hold tight.",
            "Rest is part of the process, even for batteries.", "Filling up on fresh energy.",
            "A little charge goes a long way.", "Slow charge, steady glow."};
    static final String[] BAT_FULL = {
            "Fully charged — go make something happen.", "Full power. Use it well.",
            "100% ready for the day ahead.", "Brimming with energy, like you after a good rest.",
            "Charged up and ready to go.", "Unplug and go — you are all set."};
    static final String[] BAT_HIGH = {
            "Life is like a battery — limited in time.", "Plenty of power left — spend it wisely.",
            "Energy well spent is energy well earned.", "Good charge, good day.",
            "Keep going, there is plenty in the tank.", "Use your power, but not all at once.",
            "Power is a gift — share some.", "Strong charge, strong day."};
    static final String[] BAT_MID = {
            "Half full, half empty — all useful.", "Pace yourself, there is a long road.",
            "Halfway through — keep it steady.", "Mind the energy, mind the day.",
            "Time to look out for a charger soon.", "Spend it on what matters.",
            "Moderate charge, moderate speed.", "Plan your plug-in."};
    static final String[] BAT_LOW = {
            "Running lower — find a charger soon.", "Low power: save the best for what matters.",
            "Even the strongest need a recharge.", "Time to slow down and recharge.",
            "Dim the screen, brighten the mind.", "Charger o'clock is coming.", "Not empty yet — but close."};
    static final String[] BAT_CRIT = {
            "Almost empty — plug in now.", "Last drops of power — charge up.",
            "Running on fumes. Find a charger.", "Rest needed. Please charge.",
            "Power is nearly out — wrap things up.", "Low battery, big heart. Plug in."};

    // ---------- selection helpers ----------

    static int dayNumber(Calendar cal) {
        long ms = cal.getTimeInMillis() + TimeZone.getDefault().getOffset(cal.getTimeInMillis());
        return (int) Math.floorDiv(ms, 86400000L);
    }

    private static int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    private static int stepFor(int n) {
        int s = 7;
        while (gcd(s, n) != 1) s++;
        return s;
    }

    static String pick(String[] builtin, List<String> extra, int dayN, int salt) {
        int n = builtin.length + (extra == null ? 0 : extra.size());
        if (n == 0) return "";
        int idx = Math.floorMod(dayN * stepFor(n) + salt * 5, n);
        if (idx < builtin.length) return builtin[idx];
        return extra.get(idx - builtin.length);
    }

    static String battery(int pct, boolean charging, List<String> extraCharging, List<String> extraFull,
                          List<String> extraHigh, List<String> extraMid, List<String> extraLow,
                          List<String> extraCrit, int dayN, int hour) {
        int salt = dayN * 3 + hour / 4;
        if (charging) {
            if (pct >= 95) return pick(BAT_FULL, extraFull, salt, 1);
            return pick(BAT_CHARGING, extraCharging, salt, 2);
        }
        if (pct >= 95) return pick(BAT_FULL, extraFull, salt, 3);
        if (pct >= 60) return pick(BAT_HIGH, extraHigh, salt, 4);
        if (pct >= 30) return pick(BAT_MID, extraMid, salt, 5);
        if (pct >= 15) return pick(BAT_LOW, extraLow, salt, 6);
        return pick(BAT_CRIT, extraCrit, salt, 7);
    }

    // ---------- the note next to the day-of-year number ----------

    private static final String[][] WEEK = {
            // index = Calendar.DAY_OF_WEEK - 1  (Sunday first)
            {"SUNDAY|RESET", "REST|REFLECT|RENEW", "EASY|SUNDAY|VIBES", "SLOW|SUNDAY|SOFT|LIGHT"},
            {"MONDAY|MODE:|FRESH|START", "NEW WEEK|NEW|WINS", "BEGIN|WITH A|SMILE", "MONDAY|YOU GOT|THIS"},
            {"TAKE|IT|STEADY", "TUESDAY|KEEP|THE|MOMENTUM", "ONE|STEP|AT A|TIME", "TWO|DAYS|IN|GOOD GOING"},
            {"HALF|WAY|THERE", "MID|WEEK|MAGIC", "WEDNESDAY|KEEP|GOING", "MIDDLE|OF THE|WEEK|BREATHE"},
            {"ALMOST|THERE", "PUSH|A BIT|MORE", "THURSDAY|STAY|STRONG", "ONE MORE|DAY TO|FRIDAY"},
            {"FRIDAY|FEELS", "FINISH|STRONG", "WEEKEND|IS|NEAR", "FRIDAY|SMILE|ON"},
            {"SLOW|SATURDAY", "REST|AND|RECHARGE", "EXPLORE|SOMETHING|NEW", "SATURDAY|SUN|SKY"}};

    private static final String[] MONTH = {
            "JANUARY|NEW|YEAR|NEW YOU", "FEBRUARY|SHORT|AND|SWEET", "MARCH|SPRING|IS IN|THE AIR",
            "APRIL|BRIGHT|AND|WARM", "MAY|LONG|SUNNY|DAYS", "JUNE|HEAT|WAVES|STAY COOL",
            "JULY|RAIN|IS ON|ITS WAY", "AUGUST|MONSOON|MOODS", "SEPTEMBER|SOFT|SKIES|RETURN",
            "OCTOBER|FESTIVE|SEASON|BEGINS", "NOVEMBER|COOL|AIR|SOFT SUN", "DECEMBER|WINTER|WARMTH|AND LIGHT"};

    static double moonPhase(long ms) {
        return ((ms - 947182440000L) / 86400000.0 % 29.530588853) / 29.530588853;
    }

    static String dayNote(Calendar cal, List<String> extra) {
        int dayN = dayNumber(cal);
        int dow = cal.get(Calendar.DAY_OF_WEEK) - 1;
        int doy = cal.get(Calendar.DAY_OF_YEAR);
        int total = cal.getActualMaximum(Calendar.DAY_OF_YEAR);
        int month = cal.get(Calendar.MONTH);
        int dom = cal.get(Calendar.DAY_OF_MONTH);

        List<String> c = new ArrayList<String>();
        // weekday notes come first so most days read as "about this day of the week"
        for (String s : WEEK[dow]) c.add(s);
        c.add(String.format(Locale.US, "%d DAYS|LEFT IN|THE YEAR", total - doy));
        c.add(String.format(Locale.US, "WEEK|%d OF|THE YEAR", cal.get(Calendar.WEEK_OF_YEAR)));
        c.add(MONTH[month]);
        if (dom == 1) c.add("A NEW|MONTH|BEGINS");
        if (doy == 1) c.add("DAY ONE|OF THE|YEAR");
        if (doy == total) c.add("LAST|DAY OF|THE YEAR");

        double ph = moonPhase(cal.getTimeInMillis());
        if (ph < 0.025 || ph > 0.975) c.add("NEW|MOON|TONIGHT");
        if (Math.abs(ph - 0.5) < 0.025) c.add("FULL|MOON|TONIGHT");
        if (extra != null) c.addAll(extra);

        int n = c.size();
        return c.get(Math.floorMod(dayN * stepFor(n) + 3, n));
    }
}
