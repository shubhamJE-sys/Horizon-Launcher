package com.horizon.launcher;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.List;

/**
 * The three small poster cards that open when you tap the weather label, the sun or moon, or the day number:
 * a 5-day forecast, rise and set times with the moon phase, and the next holidays with a countdown.
 * Drawn in the same ink, paper and accent as the home screen, in design units (360 wide).
 */
final class InfoCards {

    static final int NONE = 0, FORECAST = 1, SUNMOON = 2, HOLIDAYS = 3;

    private InfoCards() { }

    /** Everything the cards show; filled by the home view. */
    static final class Data {
        String place = "";
        // forecast (up to five days)
        int days;
        String[] dayName = new String[5];
        int[] code = new int[5];
        float[] max = new float[5], min = new float[5];
        int[] rain = new int[5];
        // sun and moon
        int sunrise, sunset, moonrise = -1, moonset = -1;
        double phase, distKm;
        boolean moonUp, h24;
        String moonSee1 = "", moonSee2 = "";
        // holidays
        List<String[]> holidays;
    }

    static void draw(Canvas c, Paint p, int mode, Typeface bebas, Typeface roboto, Sky sky,
                     float vx0, float vx1, Data d) {
        boolean night = sky.nightK > 0.5f;
        int paper = night ? 0xFF1B1E27 : 0xFFF3EBDA;
        int ink = night ? 0xFFEDE6D3 : 0xFF1B1B1A;
        int soft = night ? 0xFFA9A596 : 0xFF6A665C;
        int acc = sky.accent();
        // dim the poster behind the card
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xA0000000);
        c.drawRect(vx0, 0f, vx1, 804f, p);

        float top, h;
        String title;
        switch (mode) {
            case FORECAST: top = 150f; h = 392f; title = "5-DAY FORECAST"; break;
            case SUNMOON: top = 150f; h = 500f; title = "SUN AND MOON"; break;
            default: top = 150f; h = 392f; title = "UPCOMING HOLIDAYS"; break;
        }
        RectF card = new RectF(20f, top, 340f, top + h);
        p.setColor(paper);
        c.drawRect(card, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.2f);
        p.setColor(ink);
        c.drawRect(card, p);
        p.setStyle(Paint.Style.FILL);

        text(c, p, title, 36f, top + 40f, 30f, ink, bebas, Paint.Align.LEFT, 0.03f);
        p.setColor(acc);
        c.drawRect(36f, top + 48f, 72f, top + 50.5f, p);
        text(c, p, d.place.toUpperCase(), 324f, top + 38f, 6.5f, soft, roboto, Paint.Align.RIGHT, 0.25f);

        if (mode == FORECAST) forecast(c, p, bebas, roboto, d, top + 62f, ink, soft, acc);
        else if (mode == SUNMOON) sunMoon(c, p, bebas, roboto, d, top + 62f, ink, soft, acc, paper);
        else holidays(c, p, bebas, roboto, d, top + 62f, ink, soft, acc);
        text(c, p, "TAP ANYWHERE TO CLOSE", 180f, top + h - 10f, 5.4f, soft, roboto, Paint.Align.CENTER, 0.3f);
    }

    // ---------- forecast ----------

    private static void forecast(Canvas c, Paint p, Typeface bebas, Typeface roboto, Data d, float y0,
                                 int ink, int soft, int acc) {
        if (d.days <= 0) {
            text(c, p, "FORECAST NOT LOADED YET", 180f, y0 + 120f, 9f, soft, roboto, Paint.Align.CENTER, 0.25f);
            return;
        }
        for (int i = 0; i < d.days; i++) {
            float y = y0 + i * 62f;
            if (i > 0) hair(c, p, y - 6f, soft);
            text(c, p, d.dayName[i], 36f, y + 34f, 26f, i == 0 ? acc : ink, bebas, Paint.Align.LEFT, 0.03f);
            glyph(c, p, d.code[i], 118f, y + 24f, 13f, ink, acc);
            text(c, p, label(d.code[i]), 142f, y + 22f, 6.8f, ink, roboto, Paint.Align.LEFT, 0.2f);
            text(c, p, d.rain[i] >= 0 ? "RAIN CHANCE " + d.rain[i] + "%" : "", 142f, y + 34f, 5.6f, soft, roboto, Paint.Align.LEFT, 0.2f);
            text(c, p, Math.round(d.max[i]) + "°", 322f, y + 25f, 26f, ink, bebas, Paint.Align.RIGHT, 0f);
            text(c, p, "LOW " + Math.round(d.min[i]) + "°", 322f, y + 36f, 6f, soft, roboto, Paint.Align.RIGHT, 0.2f);
        }
    }

    static String label(int code) {
        switch (code) {
            case 0: return "CLEAR SKY";
            case 1: return "MOSTLY CLEAR";
            case 2: return "PARTLY CLOUDY";
            case 3: return "OVERCAST";
            case 45: case 48: return "FOG";
            case 51: case 53: case 55: case 56: case 57: return "DRIZZLE";
            case 61: case 63: case 65: case 66: case 67: return "RAIN";
            case 71: case 73: case 75: case 77: return "SNOW";
            case 80: case 81: case 82: return "SHOWERS";
            case 85: case 86: return "SNOW SHOWERS";
            case 95: case 96: case 99: return "THUNDERSTORM";
            default: return "";
        }
    }

    /** A small line-drawn weather symbol. */
    private static void glyph(Canvas c, Paint p, int code, float cx, float cy, float r, int ink, int acc) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f);
        p.setStrokeCap(Paint.Cap.ROUND);
        boolean sun = code <= 1, partly = code == 2;
        boolean cloudy = code >= 2;
        if (sun || partly) {
            float sx = partly ? cx + r * 0.35f : cx, sy = partly ? cy - r * 0.35f : cy;
            p.setColor(acc);
            c.drawCircle(sx, sy, r * 0.5f, p);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4.0;
                c.drawLine(sx + (float) Math.cos(a) * r * 0.72f, sy + (float) Math.sin(a) * r * 0.72f,
                        sx + (float) Math.cos(a) * r * 0.98f, sy + (float) Math.sin(a) * r * 0.98f, p);
            }
        }
        if (cloudy) {
            p.setColor(ink);
            Path cl = new Path();
            float bx = cx - r * 0.9f, by = cy + r * 0.45f;
            cl.moveTo(bx, by);
            cl.lineTo(bx + r * 1.8f, by);
            cl.cubicTo(bx + r * 2.15f, by, bx + r * 2.15f, by - r * 0.75f, bx + r * 1.6f, by - r * 0.8f);
            cl.cubicTo(bx + r * 1.5f, by - r * 1.35f, bx + r * 0.7f, by - r * 1.35f, bx + r * 0.6f, by - r * 0.8f);
            cl.cubicTo(bx + r * 0.1f, by - r * 0.9f, bx - r * 0.3f, by, bx, by);
            c.drawPath(cl, p);
        }
        boolean rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95;
        boolean snow = (code >= 71 && code <= 77) || code == 85 || code == 86;
        if (rain) {
            p.setColor(acc);
            for (int i = 0; i < 3; i++) {
                float x = cx - r * 0.5f + i * r * 0.5f;
                c.drawLine(x, cy + r * 0.75f, x - r * 0.18f, cy + r * 1.1f, p);
            }
        }
        if (snow) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(acc);
            for (int i = 0; i < 3; i++) c.drawCircle(cx - r * 0.5f + i * r * 0.5f, cy + r * 0.95f, 1.3f, p);
        }
        if (code == 45 || code == 48) {
            p.setColor(ink);
            p.setStyle(Paint.Style.STROKE);
            for (int i = 0; i < 3; i++) c.drawLine(cx - r * 0.9f, cy - r * 0.5f + i * r * 0.55f, cx + r * 0.9f, cy - r * 0.5f + i * r * 0.55f, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    // ---------- sun and moon ----------

    private static void sunMoon(Canvas c, Paint p, Typeface bebas, Typeface roboto, Data d, float y0,
                                int ink, int soft, int acc, int paper) {
        text(c, p, "SUN", 36f, y0 + 12f, 9f, acc, roboto, Paint.Align.LEFT, 0.35f);
        float cy = y0 + 46f;
        stat(c, p, bebas, roboto, "RISES", clock(d.sunrise, d.h24), 36f, cy, ink, soft);
        stat(c, p, bebas, roboto, "SETS", clock(d.sunset, d.h24), 138f, cy, ink, soft);
        int len = d.sunset - d.sunrise;
        stat(c, p, bebas, roboto, "DAYLIGHT", (len / 60) + "H " + String.format(java.util.Locale.US, "%02d", len % 60) + "M", 240f, cy, ink, soft);
        hair(c, p, y0 + 74f, soft);

        text(c, p, "MOON", 36f, y0 + 96f, 9f, acc, roboto, Paint.Align.LEFT, 0.35f);
        // the moon itself, with today's phase
        float mx = 80f, my = y0 + 166f, mr = 38f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.6f);
        p.setColor(ink);
        c.drawCircle(mx, my, mr, p);
        Moon.draw(c, p, mx, my, mr - 1f, d.phase, ink, 255);
        p.setStyle(Paint.Style.FILL);
        text(c, p, Astro.phaseName(d.phase), 140f, y0 + 150f, 24f, ink, bebas, Paint.Align.LEFT, 0.03f);
        text(c, p, Math.round(Astro.illumination(d.phase) * 100) + "% LIT" + (d.moonUp ? " • UP NOW" : " • BELOW THE HORIZON"),
                140f, y0 + 166f, 6.4f, soft, roboto, Paint.Align.LEFT, 0.22f);
        text(c, p, "DISTANCE " + String.format(java.util.Locale.US, "%,d", Math.round(d.distKm / 1000.0) * 1000L) + " KM",
                140f, y0 + 178f, 6.4f, soft, roboto, Paint.Align.LEFT, 0.22f);
        float cy2 = y0 + 236f;
        stat(c, p, bebas, roboto, "MOONRISE", d.moonrise < 0 ? "NONE TODAY" : clock(d.moonrise, d.h24), 36f, cy2, ink, soft);
        stat(c, p, bebas, roboto, "MOONSET", d.moonset < 0 ? "NONE TODAY" : clock(d.moonset, d.h24), 190f, cy2, ink, soft);
        if (d.moonSee1 != null && d.moonSee1.length() > 0) {
            hair(c, p, y0 + 256f, soft);
            text(c, p, "WILL I SEE IT FROM HERE?", 36f, y0 + 276f, 5.8f, soft, roboto, Paint.Align.LEFT, 0.3f);
            text(c, p, d.moonSee1, 36f, y0 + 300f, 26f, d.moonSee1.startsWith("YES") ? acc : ink, bebas, Paint.Align.LEFT, 0.03f);
            text(c, p, d.moonSee2, 36f, y0 + 314f, 6.2f, soft, roboto, Paint.Align.LEFT, 0.2f);
        }
    }

    private static void stat(Canvas c, Paint p, Typeface bebas, Typeface roboto, String label, String value,
                             float x, float y, int ink, int soft) {
        text(c, p, label, x, y - 20f, 5.8f, soft, roboto, Paint.Align.LEFT, 0.3f);
        text(c, p, value, x, y + 6f, value.length() > 7 ? 19f : 26f, ink, bebas, Paint.Align.LEFT, 0.03f);
    }

    static String clock(int min, boolean h24) {
        int h = (min / 60) % 24, m = min % 60;
        if (h24) return String.format(java.util.Locale.US, "%02d:%02d", h, m);
        int hh = h % 12 == 0 ? 12 : h % 12;
        return String.format(java.util.Locale.US, "%d:%02d %s", hh, m, h < 12 ? "AM" : "PM");
    }

    // ---------- holidays ----------

    private static void holidays(Canvas c, Paint p, Typeface bebas, Typeface roboto, Data d, float y0,
                                 int ink, int soft, int acc) {
        if (d.holidays == null || d.holidays.isEmpty()) {
            text(c, p, "NO HOLIDAYS LISTED", 180f, y0 + 120f, 9f, soft, roboto, Paint.Align.CENTER, 0.25f);
            return;
        }
        int n = Math.min(6, d.holidays.size());
        for (int i = 0; i < n; i++) {
            String[] h = d.holidays.get(i);
            float y = y0 + i * 52f;
            if (i > 0) hair(c, p, y - 6f, soft);
            int days = Integer.parseInt(h[2]);
            text(c, p, fit(h[0], 22f, 196f, bebas, p), 36f, y + 26f, size(h[0], 22f, 196f, bebas, p), ink, bebas, Paint.Align.LEFT, 0.03f);
            text(c, p, h[1], 36f, y + 38f, 6f, soft, roboto, Paint.Align.LEFT, 0.22f);
            String when = days == 0 ? "TODAY" : (days == 1 ? "TOMORROW" : days + " DAYS");
            text(c, p, when, 322f, y + 28f, days <= 1 ? 22f : 24f, days <= 7 ? acc : ink, bebas, Paint.Align.RIGHT, 0.03f);
            if (days > 1) text(c, p, "TO GO", 322f, y + 38f, 5.6f, soft, roboto, Paint.Align.RIGHT, 0.3f);
        }
    }

    private static String fit(String s, float size, float maxW, Typeface tf, Paint p) {
        return s;
    }

    private static float size(String s, float size, float maxW, Typeface tf, Paint p) {
        p.setTypeface(tf);
        p.setLetterSpacing(0.03f);
        p.setTextSize(size);
        float w = p.measureText(s);
        return w > maxW ? Math.max(11f, size * maxW / w) : size;
    }

    // ---------- helpers ----------

    private static void hair(Canvas c, Paint p, float y, int col) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        p.setAlpha(110);
        c.drawRect(36f, y, 324f, y + 0.8f, p);
        p.setAlpha(255);
    }

    private static void text(Canvas c, Paint p, String t, float x, float y, float size, int color,
                             Typeface tf, Paint.Align a, float spacing) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(tf);
        p.setTextSize(size);
        p.setColor(color);
        p.setTextAlign(a);
        p.setLetterSpacing(spacing);
        c.drawText(t, x, y, p);
        p.setLetterSpacing(0f);
        p.setTextAlign(Paint.Align.LEFT);
    }
}
