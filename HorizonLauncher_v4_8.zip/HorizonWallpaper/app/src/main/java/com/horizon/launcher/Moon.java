package com.horizon.launcher;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Draws only the lit part of the moon for the real phase; nothing is painted over the sky (no dark second disc). */
final class Moon {
    private Moon() { }

    /**
     * @param phase 0 = new moon, 0.5 = full moon, below 0.5 the right side is lit (waxing, northern sky)
     */
    static void draw(Canvas c, Paint p, float cx, float cy, float r, double phase, int color, int alpha) {
        float f = (float) ((1.0 - Math.cos(2.0 * Math.PI * phase)) / 2.0);   // lit fraction 0..1
        boolean waxing = phase < 0.5;
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        // the dark side is only hinted at, so the whole round shape of the moon can still be read
        p.setColor(color);
        p.setAlpha(Math.max(0, Math.min(255, alpha / 7)));
        c.drawCircle(cx, cy, r, p);
        if (f < 0.015f) return;
        p.setColor(color);
        p.setAlpha(Math.max(0, Math.min(255, alpha)));
        if (f > 0.985f) {
            c.drawCircle(cx, cy, r, p);
            return;
        }
        float rx = r * Math.abs(1f - 2f * f);
        Path path = new Path();
        // lit limb on the right (mirrored below for a waning moon)
        path.arcTo(new RectF(cx - r, cy - r, cx + r, cy + r), -90f, 180f, true);
        // terminator back from the bottom to the top: bulges to the lit side for a crescent, to the dark side for gibbous
        RectF term = new RectF(cx - rx, cy - r, cx + rx, cy + r);
        if (f < 0.5f) path.arcTo(term, 90f, -180f, false);
        else path.arcTo(term, 90f, 180f, false);
        path.close();
        c.save();
        if (!waxing) c.scale(-1f, 1f, cx, cy);
        c.drawPath(path, p);
        c.restore();
    }
}
