package com.horizon.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * Carries the water of a scene on below its bottom edge and melts it into the page.
 * It does NOT flip the picture (the bottom of the scene is already a reflection): it takes the average colour
 * of the last rows of the picture and adds a few faint ripple lines.
 */
final class WaterExt {
    private static Bitmap lastSrc, lastStrip;
    private static boolean lastDry;

    private WaterExt() { }

    /** One-pixel-high strip with the smoothed average colour of the last rows of the scene. */
    private static synchronized Bitmap strip(Bitmap src, boolean dry) {
        if (src == lastSrc && lastStrip != null && lastDry == dry) return lastStrip;
        int w = src.getWidth(), h = src.getHeight();
        int rows = Math.min(36, h), cols = 96;
        int[] px = new int[w * rows];
        src.getPixels(px, 0, w, 0, h - rows, w, rows);
        float[][] acc = new float[cols][4];
        for (int col = 0; col < cols; col++) {
            int x0 = col * w / cols, x1 = Math.max(x0 + 1, (col + 1) * w / cols);
            double sa = 0, sr = 0, sg = 0, sb = 0;
            int n = 0;
            for (int y = 0; y < rows; y++) {
                for (int x = x0; x < x1; x++) {
                    int p = px[y * w + x];
                    int a = Color.alpha(p);
                    // dark shore pixels would smear down into the water, so only water-coloured pixels count
                    if (!dry && Color.red(p) * 0.3 + Color.green(p) * 0.59 + Color.blue(p) * 0.11 < 115) continue;
                    sa += a;
                    sr += Color.red(p) * (double) a;
                    sg += Color.green(p) * (double) a;
                    sb += Color.blue(p) * (double) a;
                    n++;
                }
            }
            if (sa > 0) {
                acc[col][0] = (float) (sr / sa);
                acc[col][1] = (float) (sg / sa);
                acc[col][2] = (float) (sb / sa);
            }
            acc[col][3] = (float) (sa / Math.max(1, n));
            acc[col][3] = n == 0 ? -1f : acc[col][3];
        }
        // columns that were all shore take the colour of the nearest water column
        for (int col = 0; col < cols; col++) {
            if (acc[col][3] >= 0f) continue;
            int best = -1;
            for (int d = 1; d < cols && best < 0; d++) {
                if (col + d < cols && acc[col + d][3] >= 0f) best = col + d;
                else if (col - d >= 0 && acc[col - d][3] >= 0f) best = col - d;
            }
            if (best >= 0) acc[col] = acc[best].clone();
            else acc[col][3] = 0f;
        }
        // smooth sideways so the end of the shore melts into the water
        for (int pass = 0; pass < 3; pass++) {
            float[][] nx = new float[cols][4];
            for (int i = 0; i < cols; i++) {
                int a = Math.max(0, i - 1), b = Math.min(cols - 1, i + 1);
                for (int k = 0; k < 4; k++) nx[i][k] = acc[a][k] * 0.25f + acc[i][k] * 0.5f + acc[b][k] * 0.25f;
            }
            acc = nx;
        }
        int[] out = new int[cols];
        for (int i = 0; i < cols; i++) {
            out[i] = Color.argb(clamp(acc[i][3]), clamp(acc[i][0]), clamp(acc[i][1]), clamp(acc[i][2]));
        }
        Bitmap s = Bitmap.createBitmap(out, cols, 1, Bitmap.Config.ARGB_8888);
        lastSrc = src;
        lastDry = dry;
        lastStrip = s;
        return s;
    }

    private static int clamp(float v) {
        return v < 0 ? 0 : (v > 255 ? 255 : Math.round(v));
    }

    /** Draws the extension in [l, r] x [top, top + ext]; tint is the colour filter used for the scene itself. */
    static void draw(Canvas c, Bitmap scene, Paint tinted, float l, float r, float top, float ext,
                     float nightK, int rippleCol, boolean dry) {
        if (scene == null) return;
        try {
            Bitmap s = strip(scene, dry);
            top = top - 6f;
            ext = ext + 6f;
            int sv = c.saveLayer(l, top, r, top + ext, null);
            Paint bp = new Paint(tinted);
            bp.setFilterBitmap(true);
            c.drawBitmap(s, null, new RectF(l, top, r, top + ext), bp);
            Paint rp = new Paint(Paint.ANTI_ALIAS_FLAG);
            rp.setStyle(Paint.Style.FILL);
            float k = 1f - 0.6f * nightK;
            float span = r - l;
            for (int i = 0; i < (dry ? 0 : 9); i++) {
                float y = top + 3f + i * (ext - 10f) / 9f;
                for (int j = 0; j < 3; j++) {
                    float f = (float) ((Math.sin(i * 12.9898 + j * 78.233) * 43758.5453) % 1.0);
                    if (f < 0) f = -f;
                    float len = 22f + 70f * (float) Math.abs(Math.sin(i * 3.7 + j * 1.9));
                    float x = l + f * (span - len);
                    rp.setColor(rippleCol);
                    rp.setAlpha((int) ((95 - i * 8) * k));
                    c.drawRect(x, y, x + len, y + 1.3f, rp);
                }
            }
            Paint mask = new Paint();
            mask.setShader(new LinearGradient(0f, top, 0f, top + ext, new int[]{0x00000000, 0xFF000000, 0xFF000000, 0x00000000},
                    new float[]{0f, 6f / ext, 6.5f / ext, 1f}, Shader.TileMode.CLAMP));
            mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawRect(l, top, r, top + ext, mask);
            c.restoreToCount(sv);
        } catch (Throwable ignored) { }
    }
}
