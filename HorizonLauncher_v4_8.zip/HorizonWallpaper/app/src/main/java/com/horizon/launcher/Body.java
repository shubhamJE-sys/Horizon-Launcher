package com.horizon.launcher;

import android.content.Context;

/**
 * Where the sun and the moon are in the picture right now, worked out from the real sky for the chosen place.
 * They only appear while they are above the horizon; the moon is drawn at its true relative size.
 */
final class Body {
    boolean sunUp, moonUp;
    float sx, sy, sr;
    float mx, my, mr;
    double phase;
    float t;

    /** Primary body for the water glint and the reflection lean: the sun by day, else the moon when it is up. */
    boolean anyUp() {
        return sunUp || moonUp;
    }

    float px() {
        return sunUp ? sx : (moonUp ? mx : 180f);
    }

    float py() {
        return sunUp ? sy : (moonUp ? my : 9999f);
    }

    private static Body cache;
    private static long cacheKey = Long.MIN_VALUE;

    /**
     * @param lakeY  y of the water line in the caller's coordinates
     * @param sceneT y of the top of the scene box in the caller's coordinates
     */
    static synchronized Body compute(Context ctx, long now, float lakeY, float sceneT) {
        double[] ll = Loc.get(ctx);
        long key = (now / 60000L) * 31L + Math.round(ll[0] * 10) * 7L + Math.round(ll[1] * 10) * 13L
                + Math.round(lakeY) * 3L + Math.round(sceneT);
        if (cache != null && key == cacheKey) return cache;
        Body b = new Body();
        Astro.Arc sun = Astro.arc(false, now, ll[0], ll[1]);
        Astro.Arc moon = Astro.arc(true, now, ll[0], ll[1]);
        b.phase = moon.phase;
        if (sun.up) {
            b.sunUp = true;
            b.sx = 40f + sun.t * 270f;
            float base = lakeY + 24f, peak = sceneT + 51f;
            b.sy = base - (float) Math.sin(Math.PI * sun.t) * (base - peak) * height(sun.maxAlt);
            b.sr = 33f;
            b.t = sun.t;
        }
        if (moon.up) {
            b.moonUp = true;
            b.mx = 40f + moon.t * 270f;
            float base = lakeY + 22f, peak = sceneT + 47f;
            b.my = base - (float) Math.sin(Math.PI * moon.t) * (base - peak) * height(moon.maxAlt);
            // true relative size: about 14% wider at its closest than at its farthest
            b.mr = (float) (24.0 * 384400.0 / Math.max(340000.0, moon.distKm));
        }
        cache = b;
        cacheKey = key;
        return b;
    }

    /** The highest point of the arc follows the season: a low winter sun stays lower in the picture. */
    private static float height(float maxAlt) {
        float f = Math.max(0f, Math.min(1f, (maxAlt - 25f) / 65f));
        return 0.62f + 0.38f * f;
    }

    /**
     * Brightness of the sun for the day's temperature, 0 to 1 (0.5 is the normal sun):
     * below 20 very low, 20-25 low, 25-35 medium, above 35 high, above 45 very high.
     */
    static float brightness(float tempC) {
        if (Float.isNaN(tempC)) return 0.5f;
        if (tempC <= 20f) return 0.0f + 0.1f * Math.max(0f, (tempC - 10f) / 10f);
        if (tempC <= 25f) return 0.1f + 0.2f * (tempC - 20f) / 5f;
        if (tempC <= 35f) return 0.3f + 0.2f * (tempC - 25f) / 10f;
        if (tempC <= 45f) return 0.5f + 0.38f * (tempC - 35f) / 10f;
        return Math.min(1f, 0.88f + 0.12f * (tempC - 45f) / 4f);
    }
}
