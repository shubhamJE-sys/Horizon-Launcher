package com.horizon.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;

/**
 * Turns an app's own icon into the poster print style: ink, cream and red dots in a coarse halftone,
 * done on the phone from the installed icon. Nothing is copied or shipped with the launcher.
 */
final class IconStyler {

    private IconStyler() { }

    /** Size of the converted bitmap in pixels; it is shown enlarged without smoothing so the dots stay chunky. */
    static final int S = 72;

    private static final int[][] BAYER = {{0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};

    static Bitmap style(Drawable d, int ink, int cream, int red) {
        Bitmap src = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(src);
        boolean mono = false;
        if (Build.VERSION.SDK_INT >= 33 && d instanceof AdaptiveIconDrawable) {
            Drawable m = ((AdaptiveIconDrawable) d).getMonochrome();
            if (m != null) {
                // the themed (one-colour) layer is the cleanest source; its visible part is the middle two thirds
                int pad = Math.round(S * 0.25f);
                m.setBounds(-pad, -pad, S + pad, S + pad);
                m.draw(c);
                mono = true;
            }
        }
        if (!mono) {
            d.setBounds(0, 0, S, S);
            d.draw(c);
        }
        int[] px = new int[S * S];
        src.getPixels(px, 0, S, 0, 0, S, S);
        if (mono) {
            for (int y = 0; y < S; y++) {
                for (int x = 0; x < S; x++) {
                    float th = (BAYER[y & 3][x & 3] + 0.5f) / 16f;
                    px[y * S + x] = (Color.alpha(px[y * S + x]) / 255f) > th ? ink : cream;
                }
            }
        } else {
            convert(px, ink, cream, red);
        }
        src.recycle();
        Bitmap res = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        res.setPixels(px, 0, S, 0, 0, S, S);
        return res;
    }

    private static float lum(int p) {
        return (0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)) / 255f;
    }

    private static int dist(int a, int b) {
        return Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b))
                + Math.abs(Color.blue(a) - Color.blue(b));
    }

    /**
     * Three kinds of icon get three treatments: a shape on a flat background (the shape is found by comparing it
     * with the icon's own background, so it can never vanish), a shape on nothing, and a busy picture (stretched
     * to full contrast and printed with bigger dots so it reads as a print, not as noise).
     */
    private static void convert(int[] px, int ink, int cream, int red) {
        // background colour: the most common opaque colour along the border
        int[] ring = new int[S * 4];
        int n = 0;
        for (int i = 0; i < S; i += 1) {
            ring[n++] = px[i];
            ring[n++] = px[(S - 1) * S + i];
            ring[n++] = px[i * S];
            ring[n++] = px[i * S + S - 1];
        }
        int opaque = 0;
        for (int i = 0; i < n; i++) if (Color.alpha(ring[i]) > 200) opaque++;
        boolean hasBg = opaque > n * 0.7f;
        int bg = 0;
        if (hasBg) {
            int best = 0;
            for (int i = 0; i < n; i++) {
                if (Color.alpha(ring[i]) <= 200) continue;
                int cnt = 0;
                for (int k = 0; k < n; k += 3) if (dist(ring[i], ring[k]) < 40) cnt++;
                if (cnt > best) {
                    best = cnt;
                    bg = ring[i];
                }
            }
        }
        // is it a busy picture? count the strong colour changes between neighbours
        int edges = 0, tot = 0;
        for (int y = 0; y < S - 1; y += 2) {
            for (int x = 0; x < S - 1; x += 2) {
                int p = px[y * S + x];
                if (Color.alpha(p) < 110) continue;
                tot++;
                if (dist(p, px[y * S + x + 1]) > 90 || dist(p, px[(y + 1) * S + x]) > 90) edges++;
            }
        }
        boolean busy = tot > 0 && edges > tot * 0.30f;
        int[] out = new int[S * S];
        if (busy) {
            // stretch brightness to the full range, then print with 2x2 pixel dots
            float lo = 1f, hi = 0f;
            float[] l = new float[S * S];
            for (int i = 0; i < S * S; i++) {
                l[i] = Color.alpha(px[i]) < 110 ? 1f : lum(px[i]);
            }
            float[] sorted = l.clone();
            java.util.Arrays.sort(sorted);
            lo = sorted[(int) (S * S * 0.08f)];
            hi = sorted[(int) (S * S * 0.92f)];
            if (hi - lo < 0.15f) hi = lo + 0.15f;
            for (int y = 0; y < S; y++) {
                for (int x = 0; x < S; x++) {
                    int i = y * S + x;
                    int p = px[i];
                    float v = Math.max(0f, Math.min(1f, (l[i] - lo) / (hi - lo)));
                    float th = (BAYER[(y >> 1) & 3][(x >> 1) & 3] + 0.5f) / 16f;
                    if (Color.alpha(p) < 110) {
                        out[i] = cream;
                        continue;
                    }
                    int mx = Math.max(Color.red(p), Math.max(Color.green(p), Color.blue(p)));
                    int mn = Math.min(Color.red(p), Math.min(Color.green(p), Color.blue(p)));
                    float sat = mx == 0 ? 0f : (mx - mn) / (float) mx;
                    if (sat > 0.5f && v > 0.3f && v < 0.85f) {
                        out[i] = th < 0.7f ? red : (v > th ? cream : ink);
                    } else {
                        out[i] = v > th ? cream : ink;
                    }
                }
            }
        } else if (hasBg) {
            float bgl = lum(bg);
            for (int y = 0; y < S; y++) {
                for (int x = 0; x < S; x++) {
                    int p = px[y * S + x];
                    float th = (BAYER[y & 3][x & 3] + 0.5f) / 16f;
                    if (Color.alpha(p) < 110) {
                        out[y * S + x] = cream;
                    } else if (dist(p, bg) < 60) {
                        // the background: a red halftone tile (lighter backgrounds get a lighter tile)
                        out[y * S + x] = th < 0.50f + 0.35f * (1f - bgl) ? red : cream;
                    } else {
                        // the shape: light shapes print cream, dark shapes print ink, so it always stands out
                        out[y * S + x] = lum(p) > bgl ? cream : ink;
                    }
                }
            }
        } else {
            // a shape on nothing: solid ink-or-cream by its own brightness, red for strong colours
            for (int y = 0; y < S; y++) {
                for (int x = 0; x < S; x++) {
                    int p = px[y * S + x];
                    float th = (BAYER[y & 3][x & 3] + 0.5f) / 16f;
                    if (Color.alpha(p) < 110) {
                        out[y * S + x] = cream;
                        continue;
                    }
                    int mx = Math.max(Color.red(p), Math.max(Color.green(p), Color.blue(p)));
                    int mn = Math.min(Color.red(p), Math.min(Color.green(p), Color.blue(p)));
                    float sat = mx == 0 ? 0f : (mx - mn) / (float) mx;
                    float lm = lum(p);
                    if (sat > 0.45f && mx > 90) out[y * S + x] = th < 0.85f - 0.2f * (1f - lm) ? red : cream;
                    else out[y * S + x] = lm > th ? cream : ink;
                }
            }
        }
        System.arraycopy(out, 0, px, 0, S * S);
    }

    /** Fallback tile: a cream square with the app's first letter in ink and a red bar. */
    static Bitmap letterTile(String label, int ink, int cream, int red, Typeface tf) {
        Bitmap bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(cream);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(tf);
        p.setColor(ink);
        p.setTextSize(S * 0.62f);
        p.setTextAlign(Paint.Align.CENTER);
        String ch = label == null || label.length() == 0 ? "?" : label.substring(0, 1).toUpperCase();
        c.drawText(ch, S / 2f, S * 0.66f, p);
        p.setColor(red);
        c.drawRect(S * 0.32f, S * 0.78f, S * 0.68f, S * 0.84f, p);
        return bmp;
    }

    // ---------- v4.6: black-and-white picture, tinted in the day's colour, framed by a gold ring ----------

    /** Size of the tinted icon bitmaps. */
    static final int T = 112;

    private static int mix(int a, int b, float t) {
        return Color.rgb(Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t),
                Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t),
                Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    /** The app's own icon in greyscale, stretched to full contrast, then tinted dark-to-light with the day's colour. */
    static Bitmap tinted(Drawable d, int accent, String label, Typeface tf) {
        int dark = mix(accent, Color.BLACK, 0.80f), light = mix(accent, Color.WHITE, 0.50f);
        Bitmap src = Bitmap.createBitmap(T, T, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(src);
        c.drawColor(dark);
        d.setBounds(0, 0, T, T);
        d.draw(c);
        int[] px = new int[T * T];
        src.getPixels(px, 0, T, 0, 0, T, T);
        src.recycle();
        float[] l = new float[T * T];
        int[] hist = new int[256];
        for (int i = 0; i < px.length; i++) {
            float v = lum(px[i]);
            l[i] = v;
            hist[Math.min(255, (int) (v * 255f))]++;
        }
        int acc = 0, lo = 0, hi = 255;
        boolean gotLo = false;
        for (int i = 0; i < 256; i++) {
            acc += hist[i];
            if (!gotLo && acc > px.length * 0.04f) {
                lo = i;
                gotLo = true;
            }
            if (acc > px.length * 0.96f) {
                hi = i;
                break;
            }
        }
        if (hi - lo < 34) return null;       // flat picture: the caller uses a letter tile instead
        float flo = lo / 255f, fhi = hi / 255f;
        Bitmap out = Bitmap.createBitmap(T, T, Bitmap.Config.ARGB_8888);
        int[] o = new int[T * T];
        for (int i = 0; i < o.length; i++) {
            float v = Math.max(0f, Math.min(1f, (l[i] - flo) / (fhi - flo)));
            v = (float) Math.pow(v, 0.9);
            o[i] = mix(dark, light, v);
        }
        out.setPixels(o, 0, T, 0, 0, T, T);
        return ring(out);
    }

    /** Fallback: two letters on a tinted tile with a small pattern chosen from the name, so no two look the same. */
    static Bitmap letterTinted(String label, int accent, Typeface tf) {
        int dark = mix(accent, Color.BLACK, 0.78f), light = mix(accent, Color.WHITE, 0.55f);
        Bitmap bmp = Bitmap.createBitmap(T, T, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(dark);
        String name = label == null ? "" : label.trim();
        String[] words = name.split("[\\s._-]+");
        String two;
        if (words.length >= 2 && words[0].length() > 0 && words[1].length() > 0) {
            two = ("" + words[0].charAt(0) + words[1].charAt(0));
        } else if (name.length() >= 2) {
            two = name.substring(0, 2);
        } else {
            two = name.length() == 1 ? name : "?";
        }
        two = two.toUpperCase();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(mix(dark, light, 0.16f));
        int kind = Math.floorMod(name.toLowerCase().hashCode(), 4);
        if (kind == 0) {
            p.setStrokeWidth(T * 0.07f);
            for (int k = -T; k < T * 2; k += T / 7) c.drawLine(k, T, k + T, 0, p);
        } else if (kind == 1) {
            for (int y = T / 12; y < T; y += T / 6) {
                for (int x = T / 12 + ((y / (T / 6)) % 2) * T / 12; x < T; x += T / 6) c.drawCircle(x, y, T * 0.035f, p);
            }
        } else if (kind == 2) {
            int cell = T / 8;
            for (int y = 0; y < T; y += cell) for (int x = 0; x < T; x += cell) {
                if (((x / cell) + (y / cell)) % 2 == 0) c.drawRect(x, y, x + cell, y + cell, p);
            }
        } else {
            for (int y = T / 10; y < T; y += T / 8) c.drawRect(0, y, T, y + T * 0.03f, p);
        }
        p.setColor(light);
        p.setTypeface(tf);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(T * (two.length() > 1 ? 0.52f : 0.66f));
        p.setLetterSpacing(0.04f);
        c.drawText(two, T / 2f, T * 0.66f, p);
        return ring(bmp);
    }

    /** Rounded corners plus a thin gold ring, like the rings on the speakers of the player. */
    private static Bitmap ring(Bitmap inner) {
        final int w = inner.getWidth();
        Bitmap out = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        float r = w * 0.22f, band = w * 0.055f, gap = w * 0.014f;
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new android.graphics.LinearGradient(0, 0, w, w,
                new int[]{0xFFF5D778, 0xFF96691E, 0xFFFFECAA, 0xFF96691E, 0xFFF5D778}, null,
                android.graphics.Shader.TileMode.CLAMP));
        c.drawRoundRect(new android.graphics.RectF(0, 0, w, w), r, r, g);
        Paint dk = new Paint(Paint.ANTI_ALIAS_FLAG);
        dk.setColor(0xFF14100A);
        c.drawRoundRect(new android.graphics.RectF(band, band, w - band, w - band), r - band, r - band, dk);
        float in = band + gap;
        android.graphics.Path clip = new android.graphics.Path();
        clip.addRoundRect(new android.graphics.RectF(in, in, w - in, w - in), r - in, r - in, android.graphics.Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        Paint ip = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        c.drawBitmap(inner, 0, 0, ip);
        c.restore();
        inner.recycle();
        return out;
    }
}
