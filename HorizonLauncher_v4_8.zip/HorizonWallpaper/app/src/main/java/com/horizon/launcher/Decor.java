package com.horizon.launcher;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.Random;

/** Festival touches drawn into the sky (and, for lamps, along the water). All coordinates are design units. */
final class Decor {

    private Decor() { }

    private static final float[][] SPARK = {
            {40, 22, 5}, {318, 14, 4}, {150, 70, 3.5f}, {215, 120, 4.5f}, {84, 150, 3.5f}, {335, 205, 4},
            {18, 248, 4.5f}, {260, 262, 3.5f}, {120, 290, 5}, {318, 318, 4}, {60, 350, 3.5f}, {200, 340, 4.5f},
            {300, 120, 3}, {30, 118, 3}, {180, 20, 3}, {250, 200, 3}};

    private static void sparkle(Canvas c, Paint p, float cx, float cy, float r) {
        Path s = new Path();
        s.moveTo(cx, cy - r);
        s.quadTo(cx, cy, cx + r, cy);
        s.quadTo(cx, cy, cx, cy + r);
        s.quadTo(cx, cy, cx - r, cy);
        s.quadTo(cx, cy, cx, cy - r);
        s.close();
        p.setStyle(Paint.Style.FILL);
        c.drawPath(s, p);
    }

    /** Festival drawing behind the mountains. t = top of the scene box, lakeY = water line. */
    static void sky(Canvas c, Paint p, Sky sky, String decor, float t, float lakeY, long now) {
        if (decor == null || decor.length() == 0 || "NONE".equals(decor)) return;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        int minute = (int) (now / 60000L);
        float lift = 0.5f + 0.5f * sky.nightK;

        if ("SPARKLE".equals(decor) || "DIYA".equals(decor)) {
            int n = "DIYA".equals(decor) ? 9 : SPARK.length;
            for (int i = 0; i < n; i++) {
                float tw = 0.55f + 0.45f * (float) Math.sin((minute + i * 3) * 0.9);
                p.setColor(Color.parseColor("#F4C542"));
                p.setAlpha((int) (200 * lift * tw + 40));
                sparkle(c, p, SPARK[i][0], t - 241f + SPARK[i][1], SPARK[i][2] * (0.8f + 0.5f * tw));
            }
            p.setAlpha(255);
        } else if ("TRICOLOUR".equals(decor)) {
            p.setColor(Color.parseColor("#FF9933"));
            p.setAlpha(46);
            c.drawRect(-60f, -60f, 420f, 130f, p);
            p.setColor(Color.WHITE);
            p.setAlpha(40);
            c.drawRect(-60f, 130f, 420f, 264f, p);
            p.setColor(Color.parseColor("#138808"));
            p.setAlpha(44);
            c.drawRect(-60f, 264f, 420f, lakeY, p);
            p.setAlpha(255);
            // Ashoka chakra
            float cx = 44f, cy = t + 66f, r = 11f;
            p.setStyle(Paint.Style.STROKE);
            p.setColor(Color.parseColor("#1B3F94"));
            p.setAlpha(220);
            p.setStrokeWidth(1.2f);
            c.drawCircle(cx, cy, r, p);
            for (int i = 0; i < 12; i++) {
                double a = Math.PI * 2 * i / 12.0;
                c.drawLine(cx, cy, cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, p);
            }
            p.setAlpha(255);
            p.setStyle(Paint.Style.FILL);
        } else if ("CRESCENT".equals(decor)) {
            Path moon = new Path();
            moon.addCircle(298f, t + 52f, 17f, Path.Direction.CW);
            Path cut = new Path();
            cut.addCircle(305f, t + 47f, 14.5f, Path.Direction.CW);
            moon.op(cut, Path.Op.DIFFERENCE);
            p.setColor(Color.parseColor("#F4D26B"));
            c.drawPath(moon, p);
            sparkle(c, p, 322f, t + 40f, 6f);
            p.setAlpha(170);
            sparkle(c, p, 270f, t + 80f, 4f);
            p.setAlpha(255);
        } else if ("COLOURS".equals(decor)) {
            String[] cols = {"#E91E63", "#FFC107", "#4CAF50", "#2196F3", "#FF5722", "#9C27B0", "#00BCD4"};
            Random r = new Random(5);
            for (int i = 0; i < 16; i++) {
                float x = 10f + r.nextFloat() * 340f;
                float y = t - 190f + r.nextFloat() * 300f;
                float rad = 10f + r.nextFloat() * 22f;
                p.setColor(Color.parseColor(cols[i % cols.length]));
                p.setAlpha(64 + (int) (r.nextFloat() * 40f));
                c.drawCircle(x, y, rad, p);
                p.setAlpha(120);
                c.drawCircle(x + rad * 0.5f, y - rad * 0.4f, rad * 0.22f, p);
            }
            p.setAlpha(255);
        } else if ("KITES".equals(decor)) {
            String[] cols = {"#F57C00", "#E91E63", "#00897B", "#FBC02D", "#5E35B1"};
            float[][] pos = {{60, 40}, {250, 70}, {140, 18}, {312, 28}, {200, 110}};
            for (int i = 0; i < pos.length; i++) {
                float cx = pos[i][0], cy = t + pos[i][1], s = 0.8f + 0.1f * (i % 3);
                Path k = new Path();
                k.moveTo(cx, cy - 12f * s);
                k.lineTo(cx + 8f * s, cy);
                k.lineTo(cx, cy + 16f * s);
                k.lineTo(cx - 8f * s, cy);
                k.close();
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.parseColor(cols[i % cols.length]));
                p.setAlpha(225);
                c.drawPath(k, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(0.8f);
                p.setColor(Sky.INK);
                p.setAlpha(150);
                c.drawLine(cx, cy - 12f * s, cx, cy + 16f * s, p);
                c.drawLine(cx - 8f * s, cy, cx + 8f * s, cy, p);
                Path tail = new Path();
                tail.moveTo(cx, cy + 16f * s);
                tail.quadTo(cx + 9f * s, cy + 24f * s, cx - 3f * s, cy + 34f * s);
                c.drawPath(tail, p);
            }
            p.setAlpha(255);
            p.setStyle(Paint.Style.FILL);
        } else if ("SNOW".equals(decor)) {
            Random r = new Random(9);
            p.setColor(Color.WHITE);
            for (int i = 0; i < 70; i++) {
                float x = r.nextFloat() * 360f;
                float y = t - 200f + r.nextFloat() * (lakeY - t + 200f);
                p.setAlpha(150 + (int) (r.nextFloat() * 90f));
                c.drawCircle(x, y, 1f + r.nextFloat() * 1.5f, p);
            }
            p.setAlpha(255);
        }
    }

    /** Festival drawing in front of the water: a row of lamps for Diwali. */
    static void front(Canvas c, Paint p, Sky sky, String decor, float lakeY, long now) {
        if (!"DIYA".equals(decor)) return;
        p.setShader(null);
        int minute = (int) (now / 60000L);
        for (int i = 0; i < 7; i++) {
            float x = 36f + i * 48f;
            float y = lakeY + 40f + (i % 2) * 7f;
            float flick = 0.8f + 0.2f * (float) Math.sin((minute + i * 2) * 1.3);
            RadialGradient g = new RadialGradient(x, y - 7f, 24f,
                    Color.argb((int) (120 * flick), 255, 190, 60), Color.argb(0, 255, 190, 60), Shader.TileMode.CLAMP);
            p.setShader(g);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(x, y - 7f, 24f, p);
            p.setShader(null);
            // reflection
            p.setColor(Color.parseColor("#FFC83D"));
            p.setAlpha(70);
            c.drawOval(new RectF(x - 3f, y + 6f, x + 3f, y + 16f), p);
            // bowl
            Path bowl = new Path();
            bowl.moveTo(x - 10f, y - 3f);
            bowl.quadTo(x, y + 9f, x + 10f, y - 3f);
            bowl.close();
            p.setColor(Color.parseColor("#B5471D"));
            p.setAlpha(255);
            c.drawPath(bowl, p);
            p.setColor(Color.parseColor("#7A2A10"));
            c.drawRect(x - 10f, y - 4f, x + 10f, y - 2.2f, p);
            // flame
            Path fl = new Path();
            fl.moveTo(x, y - 17f * flick);
            fl.quadTo(x + 5f, y - 8f, x, y - 3.5f);
            fl.quadTo(x - 5f, y - 8f, x, y - 17f * flick);
            fl.close();
            p.setColor(Color.parseColor("#FFC83D"));
            c.drawPath(fl, p);
            p.setColor(Color.parseColor("#FFF3B0"));
            c.drawCircle(x, y - 7f, 1.6f, p);
        }
        p.setAlpha(255);
    }
}
