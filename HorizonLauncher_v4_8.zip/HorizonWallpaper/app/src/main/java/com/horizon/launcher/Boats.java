package com.horizon.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.Random;

/**
 * A small boat that sits in a new place on the water every hour (the place is stable within the hour).
 * Each scene has its own kind of boat. The boat never sits on the shore or in the sun/moon glint,
 * and has its own leaning reflection.
 */
final class Boats {

    static final int NONE = 0, SAIL = 1, ROW = 2, FISH = 3, YACHT = 4;

    private Boats() { }

    static int typeFor(String sceneId) {
        if ("lake".equals(sceneId)) return SAIL;
        if ("peaks".equals(sceneId) || "himalaya".equals(sceneId) || "jalmahal".equals(sceneId)) return ROW;
        if ("palms".equals(sceneId) || "sea".equals(sceneId) || "andaman".equals(sceneId)) return FISH;
        if ("city".equals(sceneId)) return YACHT;
        return NONE;
    }

    /** Position and size of the boat: u across the picture (0..1), v down the water (0 = water line, 1 = bottom). */
    static final class Spot {
        float u, v, scale;
        int type;
    }

    private static String lastKey = "";
    private static Spot lastSpot;

    /**
     * @param hourKey  changes once an hour
     * @param glintU   horizontal place (0..1) of the sun or moon glint, or -1 when there is none
     * @param fg       the foreground (shore) layer, used so the boat never sits on it
     */
    static synchronized Spot pick(String sceneId, long hourKey, float glintU, Bitmap fg) {
        int type = typeFor(sceneId);
        if (type == NONE) return null;
        String key = sceneId + "|" + hourKey + "|" + Math.round(glintU * 20f);
        if (key.equals(lastKey) && lastSpot != null) return lastSpot;
        Random r = new Random(hourKey * 7919L + sceneId.hashCode() * 31L);
        Spot best = null;
        for (int i = 0; i < 24; i++) {
            Spot s = new Spot();
            s.type = type;
            s.u = 0.10f + r.nextFloat() * 0.80f;
            s.v = 0.20f + r.nextFloat() * 0.62f;
            s.scale = 0.62f + 0.55f * s.v;
            best = s;
            if (glintU >= 0f && Math.abs(s.u - glintU) < 0.13f) continue;
            if (onShore(fg, s)) continue;
            break;
        }
        lastKey = key;
        lastSpot = best;
        return best;
    }

    private static boolean onShore(Bitmap fg, Spot s) {
        if (fg == null || fg.getWidth() < 20) return false;
        try {
            int w = fg.getWidth(), h = fg.getHeight();
            float halfW = 0.10f * s.scale + 0.02f;     // boat width as a share of the picture width
            float halfH = 0.16f * s.scale;             // and of the water depth
            for (int ix = -2; ix <= 2; ix++) {
                for (int iy = -2; iy <= 2; iy++) {
                    float u = s.u + ix * halfW / 2f, v = s.v + iy * halfH / 2f;
                    int x = Math.max(0, Math.min(w - 1, Math.round(u * w)));
                    int y = Math.max(0, Math.min(h - 1, Math.round(v * h)));
                    if ((fg.getPixel(x, y) >>> 24) > 40) return true;
                }
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private static final int INK = 0xFF1C1B1A;

    /**
     * Draws the boat and its reflection. The canvas is in design units; (x, y) is the middle of the boat at the
     * water line, lean is the reflection's sideways lean per unit of depth.
     */
    static void draw(Canvas c, Paint tinted, Spot s, float x, float y, float lean, float nightK) {
        if (s == null) return;
        Paint p = new Paint(tinted);
        p.setStyle(Paint.Style.FILL);
        p.setAntiAlias(true);
        // reflection first (flipped, fainter, leaning away from the light)
        c.save();
        c.translate(x, y);
        c.scale(s.scale, -s.scale);
        c.skew(-lean * 6f, 0f);
        p.setColor(INK);
        p.setAlpha((int) (96 * (1f - 0.3f * nightK)));
        shape(c, p, s.type);
        c.restore();
        c.save();
        c.translate(x, y);
        c.scale(s.scale, s.scale);
        p.setColor(INK);
        p.setAlpha(255);
        shape(c, p, s.type);
        c.restore();
    }

    private static Path poly(float... pts) {
        Path pa = new Path();
        pa.moveTo(pts[0], pts[1]);
        for (int i = 2; i + 1 < pts.length; i += 2) pa.lineTo(pts[i], pts[i + 1]);
        pa.close();
        return pa;
    }

    /** The silhouette in a unit-less box about 50 wide, sitting on y = 0 (up is negative). */
    private static void shape(Canvas c, Paint p, int type) {
        switch (type) {
            case SAIL:
                c.drawPath(poly(-14f, -1f, 15f, -1f, 10f, 4f, -9f, 4f), p);
                c.drawPath(poly(0f, -2f, 0f, -26f, 12f, -3f), p);
                c.drawPath(poly(-2f, -2f, -2f, -19f, -13f, -3f), p);
                p.setStrokeWidth(0.9f);
                c.drawLine(0f, -2f, 0f, -28f, p);
                break;
            case ROW:
                c.drawPath(poly(-16f, -2f, 16f, -2f, 11f, 3f, -11f, 3f), p);
                c.drawCircle(0f, -13f, 2.4f, p);
                c.drawRect(-2.4f, -11f, 2.4f, -2f, p);
                p.setStrokeWidth(1.1f);
                c.drawLine(1.5f, -7f, 18f, 2f, p);
                c.drawLine(-1.5f, -7f, -18f, 2f, p);
                break;
            case FISH:
                c.drawPath(poly(-20f, -5f, 14f, -6f, 23f, -10f, 14f, 3f, -15f, 3f), p);
                c.drawRect(-9f, -14f, 2f, -5f, p);
                p.setStrokeWidth(1f);
                c.drawLine(7f, -6f, 7f, -22f, p);
                c.drawLine(7f, -22f, -13f, -7f, p);
                c.drawPath(poly(7f, -22f, 13f, -20f, 7f, -18f), p);
                break;
            case YACHT:
                c.drawPath(poly(-25f, -3f, 25f, -3f, 19f, 4f, -21f, 4f), p);
                c.drawPath(poly(-9f, -3f, -5f, -10f, 11f, -10f, 15f, -3f), p);
                c.drawRect(-2f, -14f, 8f, -10f, p);
                p.setStrokeWidth(0.9f);
                c.drawLine(4f, -14f, 4f, -26f, p);
                break;
            default:
                break;
        }
    }
}
