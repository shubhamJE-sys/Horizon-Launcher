package com.horizon.launcher;

import android.content.Context;
import android.os.Build;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;

/**
 * Watches the mobile signal level (0-4) without any sensitive permission.
 * level() is -1 when the phone does not let us read it.
 */
final class SignalWatcher {

    private final Context ctx;
    private final Runnable onChange;
    private volatile int level = -1;
    private TelephonyManager tm;
    private Object callback;
    private boolean running = false;

    SignalWatcher(Context ctx, Runnable onChange) {
        this.ctx = ctx;
        this.onChange = onChange;
    }

    int level() {
        return level;
    }

    void start() {
        if (running) return;
        try {
            tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return;
            if (Build.VERSION.SDK_INT >= 31) {
                Api31 cb = new Api31();
                tm.registerTelephonyCallback(ctx.getMainExecutor(), cb);
                callback = cb;
            } else {
                Legacy l = new Legacy();
                tm.listen(l, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
                callback = l;
            }
            running = true;
        } catch (Throwable t) {
            level = -1;
            callback = null;
        }
    }

    void stop() {
        if (!running) return;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (callback instanceof Api31) tm.unregisterTelephonyCallback((Api31) callback);
            } else if (callback instanceof Legacy) {
                tm.listen((Legacy) callback, PhoneStateListener.LISTEN_NONE);
            }
        } catch (Throwable ignored) { }
        callback = null;
        running = false;
    }

    private void set(SignalStrength s) {
        int v = -1;
        try {
            if (s != null) v = s.getLevel();
        } catch (Throwable ignored) { }
        if (v != level) {
            level = v;
            if (onChange != null) onChange.run();
        }
    }

    private final class Api31 extends TelephonyCallback implements TelephonyCallback.SignalStrengthsListener {
        @Override
        public void onSignalStrengthsChanged(SignalStrength signalStrength) {
            set(signalStrength);
        }
    }

    @SuppressWarnings("deprecation")
    private final class Legacy extends PhoneStateListener {
        @Override
        public void onSignalStrengthsChanged(SignalStrength signalStrength) {
            set(signalStrength);
        }
    }
}
