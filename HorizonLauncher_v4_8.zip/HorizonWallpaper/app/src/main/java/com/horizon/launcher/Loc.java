package com.horizon.launcher;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;

/** The place the sky is drawn for: chosen by hand from a list (default Raebareli) or taken from the phone. */
final class Loc {

    private Loc() { }

    /** {name, latitude, longitude} */
    static final Object[][] CITIES = {
            {"Raebareli", 26.23, 81.23}, {"Lucknow", 26.85, 80.95}, {"Delhi", 28.61, 77.21},
            {"Mumbai", 19.08, 72.88}, {"Kolkata", 22.57, 88.36}, {"Chennai", 13.08, 80.27},
            {"Bengaluru", 12.97, 77.59}, {"Hyderabad", 17.39, 78.49}, {"Ahmedabad", 23.02, 72.57},
            {"Pune", 18.52, 73.86}, {"Jaipur", 26.91, 75.79}, {"Patna", 25.59, 85.14},
            {"Bhopal", 23.26, 77.41}, {"Chandigarh", 30.73, 76.78}, {"Dehradun", 30.32, 78.03},
            {"Srinagar", 34.08, 74.80}, {"Leh", 34.17, 77.58}, {"Shimla", 31.10, 77.17},
            {"Guwahati", 26.14, 91.74}, {"Bhubaneswar", 20.30, 85.82}, {"Thiruvananthapuram", 8.52, 76.94},
            {"Kochi", 9.93, 76.27}, {"Panaji (Goa)", 15.50, 73.83}, {"Port Blair", 11.62, 92.73},
            {"Varanasi", 25.32, 83.01}, {"Prayagraj", 25.43, 81.85}, {"Kanpur", 26.45, 80.35},
            {"Agra", 27.18, 78.02}, {"Jodhpur", 26.24, 73.02}, {"Udaipur", 24.58, 73.68},
            {"Amritsar", 31.63, 74.87}, {"Ranchi", 23.34, 85.31}, {"Raipur", 21.25, 81.63},
            {"Nagpur", 21.15, 79.09}, {"Indore", 22.72, 75.86}, {"Coimbatore", 11.02, 76.96},
            {"Visakhapatnam", 17.69, 83.22}, {"Madurai", 9.93, 78.12}, {"Gangtok", 27.34, 88.61},
            {"Imphal", 24.82, 93.94}, {"Kathmandu", 27.72, 85.32}, {"Dhaka", 23.81, 90.41},
            {"Colombo", 6.93, 79.86}, {"Dubai", 25.20, 55.27}, {"Doha", 25.29, 51.53},
            {"Singapore", 1.35, 103.82}, {"Tokyo", 35.68, 139.69}, {"Sydney", -33.87, 151.21},
            {"London", 51.51, -0.13}, {"Paris", 48.86, 2.35}, {"Berlin", 52.52, 13.40},
            {"Moscow", 55.76, 37.62}, {"Cape Town", -33.92, 18.42}, {"New York", 40.71, -74.01},
            {"Toronto", 43.65, -79.38}, {"San Francisco", 37.77, -122.42}};

    static boolean auto(Context ctx) {
        return ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE).getBoolean("loc_auto", false);
    }

    static String name(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
        if (sp.getBoolean("loc_auto", false)) {
            String n = sp.getString("loc_auto_name", null);
            return n == null ? "PHONE LOCATION" : n;
        }
        return sp.getString("loc_name", "Raebareli");
    }

    /** {latitude, longitude} to draw the sky for. */
    static double[] get(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
        if (sp.getBoolean("loc_auto", false) && sp.contains("loc_auto_lat")) {
            return new double[]{Double.longBitsToDouble(sp.getLong("loc_auto_lat", 0L)),
                    Double.longBitsToDouble(sp.getLong("loc_auto_lon", 0L))};
        }
        String n = sp.getString("loc_name", "Raebareli");
        for (Object[] c : CITIES) {
            if (c[0].equals(n)) return new double[]{(Double) c[1], (Double) c[2]};
        }
        return new double[]{26.23, 81.23};
    }

    static void choose(Context ctx, int cityIndex) {
        ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE).edit()
                .putBoolean("loc_auto", false).putString("loc_name", (String) CITIES[cityIndex][0]).apply();
    }

    static boolean hasPermission(Context ctx) {
        return ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    static void setAuto(Context ctx, boolean on) {
        ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE).edit().putBoolean("loc_auto", on).apply();
        if (on) refreshAuto(ctx, true);
    }

    /** Takes the last place the phone knows (no new fix is requested, so it costs no battery); at most every 3 hours. */
    static void refreshAuto(Context ctx, boolean force) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
            if (!sp.getBoolean("loc_auto", false) || !hasPermission(ctx)) return;
            long now = System.currentTimeMillis();
            if (!force && now - sp.getLong("loc_auto_at", 0L) < 3L * 3600000L) return;
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best == null) return;
            String nearest = nearestName(best.getLatitude(), best.getLongitude());
            sp.edit().putLong("loc_auto_lat", Double.doubleToLongBits(best.getLatitude()))
                    .putLong("loc_auto_lon", Double.doubleToLongBits(best.getLongitude()))
                    .putString("loc_auto_name", nearest).putLong("loc_auto_at", now).apply();
        } catch (Throwable ignored) { }
    }

    private static String nearestName(double lat, double lon) {
        String best = "PHONE LOCATION";
        double bd = 1e18;
        for (Object[] c : CITIES) {
            double dl = (Double) c[1] - lat, dn = ((Double) c[2] - lon) * Math.cos(lat * Math.PI / 180.0);
            double d = dl * dl + dn * dn;
            if (d < bd) {
                bd = d;
                best = (String) c[0];
            }
        }
        return best;
    }
}
