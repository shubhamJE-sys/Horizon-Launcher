package com.horizon.launcher;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.PowerManager;
import android.os.SystemClock;
import android.widget.RemoteViews;

import java.util.Calendar;

/**
 * The eye-rest reminder: about every 20 minutes of screen-on time a notification asks you to look away.
 * Spooky mode grows from a gentle picture to a watching one to the crawling one if you keep ignoring it;
 * Gentle mode only ever shows the first; Off does nothing. No service, overlay or special access is used:
 * only one inexact alarm, the screen on/off broadcasts and normal notifications.
 */
final class EyeReminder {

    static final String MODE_SPOOKY = "SPOOKY", MODE_GENTLE = "GENTLE", MODE_OFF = "OFF";
    static final long INTERVAL_MS = 20L * 60L * 1000L;
    private static final String CHANNEL = "eye_rest";
    private static final int NOTE_ID = 4601;
    private static boolean registered = false;

    static final String[] STAGE2_LINES = {
            "Still here? I'm watching.",
            "Twenty minutes. Look away.",
            "I can see you looking at your phone.",
            "20-20-20: look 20 feet away for 20 seconds."};
    static final String STAGE1_LINE = "Look at the horizon for 20 seconds";
    static final String STAGE3_LINE = "20-20-20. Look 20 feet away. For 20 seconds. Now.";

    private EyeReminder() { }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("horizon", Context.MODE_PRIVATE);
    }

    static String mode(Context c) {
        return sp(c).getString("eye_mode", MODE_SPOOKY);
    }

    static void setMode(Context c, String m) {
        sp(c).edit().putString("eye_mode", m).putInt("eye_stage", 0).apply();
        apply(c);
    }

    /** Called once when the app process starts. */
    static void init(Context app) {
        if (!registered) {
            registered = true;
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_SCREEN_ON);
            f.addAction(Intent.ACTION_SCREEN_OFF);
            BroadcastReceiver r = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent i) {
                    if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) screenOff(ctx);
                    else screenOn(ctx);
                }
            };
            try {
                if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
                else app.registerReceiver(r, f);
            } catch (Throwable ignored) { }
        }
        makeChannel(app);
        apply(app);
    }

    private static void makeChannel(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Eye rest", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("A reminder to look away from the screen every 20 minutes");
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        } catch (Throwable ignored) { }
    }

    private static boolean interactive(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isInteractive();
    }

    /** (Re)starts or stops the timer to match the chosen mode and the screen state. */
    static void apply(Context c) {
        if (MODE_OFF.equals(mode(c))) {
            cancelAlarm(c);
            cancelNote(c);
        } else if (interactive(c)) {
            scheduleNext(c);
        }
    }

    static void screenOn(Context c) {
        if (MODE_OFF.equals(mode(c))) return;
        scheduleNext(c);
    }

    /** Locking the phone counts as a rest: the escalation starts over. */
    static void screenOff(Context c) {
        sp(c).edit().putInt("eye_stage", 0).apply();
        cancelAlarm(c);
        cancelNote(c);
    }

    /** The "I rested" button was pressed. */
    static void rested(Context c) {
        sp(c).edit().putInt("eye_stage", 0).apply();
        cancelNote(c);
        if (!MODE_OFF.equals(mode(c))) scheduleNext(c);
    }

    private static PendingIntent alarmIntent(Context c) {
        Intent i = new Intent(c, EyeAlarmReceiver.class);
        return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void scheduleNext(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + INTERVAL_MS, alarmIntent(c));
        } catch (Throwable ignored) { }
    }

    private static void cancelAlarm(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(alarmIntent(c));
        } catch (Throwable ignored) { }
    }

    private static void cancelNote(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(NOTE_ID);
        } catch (Throwable ignored) { }
    }

    private static boolean quietHours() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h >= 22 || h < 7;
    }

    /** The 20-minute alarm went off. */
    static void onAlarm(Context c) {
        String m = mode(c);
        if (MODE_OFF.equals(m)) return;
        if (!interactive(c)) {            // the screen is off: nothing to rest from, and the escalation starts over
            sp(c).edit().putInt("eye_stage", 0).apply();
            return;
        }
        if (!quietHours()) {
            int stage = MODE_GENTLE.equals(m) ? 1 : Math.max(1, Math.min(3, sp(c).getInt("eye_stage", 0) + 1));
            sp(c).edit().putInt("eye_stage", stage).apply();
            post(c, stage);
        }
        scheduleNext(c);
    }

    private static void post(Context c, int stage) {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            makeChannel(c);
            String line;
            String title;
            if (stage == 1) {
                line = STAGE1_LINE;
                title = "Eye rest";
            } else if (stage == 2) {
                line = STAGE2_LINES[Math.floorMod((int) (System.currentTimeMillis() / INTERVAL_MS), STAGE2_LINES.length)];
                title = "Still here?";
            } else {
                line = STAGE3_LINE;
                title = "Look away";
            }
            Bitmap pic = EyeArt.stagePicture(c, stage, line);
            if (pic == null) return;
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.eye_notif);
            rv.setImageViewBitmap(R.id.eye_pic, pic);
            Intent open = stage == 3 ? new Intent(c, EyeRestActivity.class) : new Intent(c, HomeActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, stage, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = new Notification.Builder(c, CHANNEL)
                    .setSmallIcon(R.drawable.ic_eye)
                    .setContentTitle(title)
                    .setContentText(line)
                    .setStyle(new Notification.DecoratedCustomViewStyle())
                    .setCustomContentView(rv)
                    .setCustomBigContentView(rv)
                    .setCustomHeadsUpContentView(rv)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_REMINDER)
                    .setOnlyAlertOnce(false);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTE_ID, b.build());
        } catch (Throwable ignored) { }
    }
}
