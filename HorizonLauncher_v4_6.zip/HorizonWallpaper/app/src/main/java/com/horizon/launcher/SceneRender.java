package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;

import java.io.InputStream;

/**
 * Draws a scene from three layers (land above the water line, clean water or ground, foreground shore).
 * Water scenes get a reflection: the land flipped at the water line, so every tree and building touches its own
 * reflection; it leans away from the sun or moon like a shadow, is longer when the body is low, and ripples slowly.
 * Dry scenes (no water) get long cast shadows on the ground instead.
 */
final class SceneRender {

    static final class Layers {
        Bitmap land, water, fg, cast;
        boolean dry;
        String id = "";
        Bitmap waterOnly() { return water; }
    }

    private static final int IMG_W = 1364, IMG_H = 944, WATER_ROW = 623;

    private SceneRender() { }

    private static Bitmap decode(Context ctx, String name) throws Exception {
        InputStream in = ctx.getAssets().open(name);
        try {
            Bitmap b = BitmapFactory.decodeStream(in);
            if (b == null) throw new Exception("bad " + name);
            return b;
        } finally {
            in.close();
        }
    }

    /** The three layers of a built-in scene, or null (content-pack scenes are single pictures and are drawn the old way). */
    static Layers load(Context ctx, String id) {
        try {
            Layers l = new Layers();
            l.id = id;
            l.land = decode(ctx, "scene_" + id + "_land.webp");
            l.water = decode(ctx, "scene_" + id + "_water.webp");
            l.fg = decode(ctx, "scene_" + id + "_fg.webp");
            l.dry = l.fg.getWidth() < 20;
            try { l.cast = decode(ctx, "scene_" + id + "_cast.webp"); } catch (Throwable ignored) { l.cast = null; }
            return l;
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * @param lean    sideways lean of the reflection per unit of depth (negative = leans left, i.e. sun on the right)
     * @param stretch how much longer than the object the reflection is (1 = same length, about 1.45 = sun on the horizon)
     * @param boat    this hour's boat, or null
     */
    static void draw(Canvas c, Layers L, Paint tinted, float l, float r, float top, float bottom,
                     float lean, float stretch, float nightK, long now, Boats.Spot boat) {
        float sy = (bottom - top) / IMG_H;
        float wy = top + WATER_ROW * sy;
        Paint bp = new Paint(tinted);
        bp.setFilterBitmap(true);

        c.drawBitmap(L.land, null, new RectF(l, top, r, wy), bp);
        c.drawBitmap(L.water, null, new RectF(l, wy, r, bottom), bp);

        if (L.dry) {
            castShadows(c, L.land, l, r, wy, bottom, lean, stretch, sy, nightK);
            return;
        }

        // reflection: the land flipped, in thin slices that are shifted sideways (lean + gentle ripple)
        int sv = c.saveLayer(l, wy, r, bottom, null);
        final int slice = 5;
        Rect src = new Rect();
        RectF dst = new RectF();
        for (int t = 0; t < WATER_ROW - 1; t += slice) {
            float d0 = t * stretch * sy;
            if (wy + d0 >= bottom) break;
            float y0 = wy + d0, y1 = wy + (t + slice) * stretch * sy;
            float wob = 0.8f * (float) Math.sin(now / 1500.0 + t * 0.05) * (0.3f + t / 330f);
            float dx = lean * d0 + wob;
            int s1 = WATER_ROW - 1 - t;
            int s0 = Math.max(0, s1 - slice);
            if (s1 <= 0) break;
            src.set(0, s0, IMG_W, s1);
            dst.set(l + dx, y0, r + dx, y1);
            c.save();
            c.scale(1f, -1f, 0f, (y0 + y1) / 2f);
            c.drawBitmap(L.land, src, dst, bp);
            c.restore();
        }
        Paint mask = new Paint();
        mask.setShader(new LinearGradient(0f, wy, 0f, bottom, 0xB8000000, 0x30000000, Shader.TileMode.CLAMP));
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawRect(l, wy, r, bottom, mask);
        c.restoreToCount(sv);

        ripples(c, l, r, wy, bottom, nightK, now);
        if (boat != null) {
            float x = l + boat.u * (r - l);
            float y = wy + boat.v * (bottom - wy);
            Boats.draw(c, tinted, boat, x, y, lean, nightK);
        }
        c.drawBitmap(L.fg, null, new RectF(l, wy, r, bottom), bp);
        if (L.cast != null) {
            // sandy scenes: palms and camels throw shadows on the sand (never into the pond, which has reflections)
            int sv2 = c.saveLayer(l, wy, r, bottom, null);
            castShadows(c, L.cast, l, r, wy, bottom, lean, stretch, sy, nightK);
            Paint keep = new Paint();
            keep.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawBitmap(L.fg, null, new RectF(l, wy, r, bottom), keep);
            c.restoreToCount(sv2);
        }
    }

    /** Where the water is: draws the shimmer only through the holes of the foreground (never over sand or shore). */
    static void clipToWater(Canvas c, Layers L, float l, float r, float top, float bottom, float lo, float hi, Runnable drawGlint) {
        float sy = (bottom - top) / IMG_H;
        float wy = top + WATER_ROW * sy;
        int sv = c.saveLayer(l, lo, r, hi, null);
        drawGlint.run();
        Paint out = new Paint();
        out.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        c.drawBitmap(L.fg, null, new RectF(l, wy, r, bottom), out);
        c.restoreToCount(sv);
    }

    /** Dry scenes: the base of everything standing on the ground throws a long, soft shadow away from the light. */
    private static void castShadows(Canvas c, Bitmap srcBmp, float l, float r, float wy, float bottom,
                                    float lean, float stretch, float sy, float nightK) {
        final int depthRows = 190;
        // shadows are longest when the sun is low and shorter towards noon; none at night
        float lowK = Math.max(0f, Math.min(1f, (stretch - 1f) / 0.45f));
        float lenK = 0.4f + 0.6f * lowK;
        float shade = 1f - nightK;
        if (shade < 0.05f) return;
        stretch = stretch * lenK;
        float reach = Math.min(bottom - wy, depthRows * stretch * sy * 1.4f);
        int sv = c.saveLayer(l, wy, r, wy + reach, null);
        Paint sp = new Paint();
        sp.setFilterBitmap(true);
        ColorMatrix cm = new ColorMatrix(new float[]{
                0.10f, 0, 0, 0, 6,
                0, 0.10f, 0, 0, 6,
                0, 0, 0.12f, 0, 10,
                0, 0, 0, 0.55f * shade, 0});
        sp.setColorFilter(new ColorMatrixColorFilter(cm));
        final int slice = 5;
        Rect src = new Rect();
        RectF dst = new RectF();
        for (int t = 0; t < depthRows; t += slice) {
            float d0 = t * stretch * sy * 1.4f;
            if (d0 >= reach) break;
            float y0 = wy + d0, y1 = wy + (t + slice) * stretch * sy * 1.4f;
            float dx = lean * 2.6f * d0;
            int s1 = WATER_ROW - 1 - t;
            int s0 = Math.max(0, s1 - slice);
            if (s1 <= 0) break;
            src.set(0, s0, IMG_W, s1);
            dst.set(l + dx, y0, r + dx, y1);
            c.save();
            c.scale(1f, -1f, 0f, (y0 + y1) / 2f);
            c.drawBitmap(srcBmp, src, dst, sp);
            c.restore();
        }
        Paint mask = new Paint();
        mask.setShader(new LinearGradient(0f, wy, 0f, wy + reach, 0xFF000000, 0x00000000, Shader.TileMode.CLAMP));
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawRect(l, wy, r, wy + reach, mask);
        c.restoreToCount(sv);
    }

    /** Faint light dashes on the water; they drift very slowly so the surface never looks frozen. */
    static void ripples(Canvas c, float l, float r, float top, float bottom, float nightK, long now) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF3EBDC);
        float k = 1f - 0.55f * nightK;
        float span = r - l;
        int rows = (int) ((bottom - top) / 3.3f);
        for (int i = 0; i < rows; i++) {
            float y = top + 1.5f + i * 3.3f + (float) Math.sin(i * 2.7) * 0.6f;
            float depth = i / (float) rows;
            for (int j = 0; j < 2; j++) {
                double h = Math.abs(Math.sin(i * 12.9898 + j * 78.233) * 43758.5453) % 1.0;
                double h2 = Math.abs(Math.sin(i * 4.1414 + j * 9.7) * 24634.6345) % 1.0;
                float len = 8f + (float) h2 * 46f;
                float x = l + (float) h * (span - len) + 3.5f * (float) Math.sin(now / 2600.0 + i * 1.7 + j);
                p.setAlpha((int) ((95 - 45 * depth) * k * (0.55f + 0.45f * (float) h2)));
                c.drawRect(x, y, x + len, y + 0.9f, p);
            }
        }
    }
}
