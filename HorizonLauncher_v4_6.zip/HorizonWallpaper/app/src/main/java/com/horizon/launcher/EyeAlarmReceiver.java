package com.horizon.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Receives the 20-minute alarm of the eye-rest reminder. */
public class EyeAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        EyeReminder.onAlarm(context.getApplicationContext());
    }
}
