package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

import java.io.InputStream;

/** Notification pictures of the eye-rest reminder: the stage picture (bubble already drawn) with the line written into it. */
final class EyeArt {

    private EyeArt() { }

    // inside of the speech bubble of each stage picture, in picture pixels (1000 x 500)
    private static final float[][] TEXT_RECT = {
            {0f, 0f, 0f, 0f},
            {662f, 34f, 970f, 126f},
            {662f, 36f, 962f, 126f},
            {545f, 92f, 925f, 232f}};

    static Bitmap decode(Context c, String name) {
        try {
            InputStream in = c.getAssets().open(name);
            try {
                return BitmapFactory.decodeStream(in);
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return null;
        }
    }

    static Bitmap stagePicture(Context c, int stage, String line) {
        Bitmap src = decode(c, "eye_" + character(c) + "_s" + stage + ".webp");
        if (src == null) return null;
        Bitmap b = src.copy(Bitmap.Config.ARGB_8888, true);
        src.recycle();
        Canvas cv = new Canvas(b);
        float[] r = TEXT_RECT[stage];
        TextPaint tp = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        try {
            tp.setTypeface(Typeface.createFromAsset(c.getAssets(), "BebasNeue.ttf"));
        } catch (Throwable ignored) { }
        tp.setColor(Color.parseColor("#1B1B1A"));
        String text = line.toUpperCase();
        float w = r[2] - r[0], h = r[3] - r[1];
        float size = 56f;
        StaticLayout lay = null;
        while (size > 18f) {
            tp.setTextSize(size);
            lay = StaticLayout.Builder.obtain(text, 0, text.length(), tp, (int) w)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 0.95f).build();
            if (lay.getHeight() <= h && lay.getLineCount() <= 3) break;
            size -= 2f;
        }
        if (lay != null) {
            cv.save();
            cv.translate(r[0], r[1] + (h - lay.getHeight()) / 2f);
            lay.draw(cv);
            cv.restore();
        }
        return b;
    }

    /** Which character's pictures are used. Only the boy's art is bundled for now. */
    static String character(Context c) {
        return "boy";
    }
}
