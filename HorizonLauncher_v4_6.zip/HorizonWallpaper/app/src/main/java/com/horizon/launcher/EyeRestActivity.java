package com.horizon.launcher;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Opens when the third (crawling) reminder is tapped. The picture crawls out of the app icon; when it has finished
 * an "I RESTED" button appears. Pressing it plays the ending: he goes to bed and sleeps, "Zzz" floats up, the screen
 * fades and closes, and the reminders start again from the gentle one. Picture frames named eye_boy_crawl1.webp...
 * and eye_boy_sleep1.webp... in the assets are played as a flip-book; without them the stage picture itself is
 * slowly zoomed instead. With animations turned off in the phone's settings only still pictures are shown.
 */
public class EyeRestActivity extends Activity {

    private SceneView view;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        view = new SceneView(this);
        setContentView(view);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (view != null) view.stop();
    }

    @Override
    public void onBackPressed() {
        // going back counts as ignoring it: the next reminder comes after 20 minutes as usual
        super.onBackPressed();
    }

    private static List<Bitmap> frames(Context c, String prefix) {
        List<Bitmap> out = new ArrayList<Bitmap>();
        for (int i = 1; i < 30; i++) {
            Bitmap bm = EyeArt.decode(c, prefix + i + ".webp");
            if (bm == null) break;
            out.add(bm);
        }
        return out;
    }

    private final class SceneView extends View {
        private final Handler h = new Handler();
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Typeface bebas;
        private final List<Bitmap> crawl, sleep;
        private final Bitmap crawlFb, tiredFb;
        private final boolean still;
        private final long t0 = SystemClock.uptimeMillis();
        private long sleepStart = -1L;
        private boolean closing = false;
        private final RectF btn = new RectF();
        private static final long CRAWL_MS = 5200L, SLEEP_MS = 5200L, FADE_MS = 1400L;

        SceneView(Context c) {
            super(c);
            Typeface tf;
            try {
                tf = Typeface.createFromAsset(c.getAssets(), "BebasNeue.ttf");
            } catch (Throwable t) {
                tf = Typeface.DEFAULT_BOLD;
            }
            bebas = tf;
            String ch = EyeArt.character(c);
            crawl = frames(c, "eye_" + ch + "_crawl");
            sleep = frames(c, "eye_" + ch + "_sleep");
            crawlFb = crawl.isEmpty() ? EyeArt.decode(c, "eye_" + ch + "_crawl_fb.webp") : null;
            tiredFb = sleep.isEmpty() ? EyeArt.decode(c, "eye_" + ch + "_tired.webp") : null;
            float scale = 1f;
            try {
                scale = Settings.Global.getFloat(c.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f);
            } catch (Throwable ignored) { }
            still = scale == 0f;
            setBackgroundColor(Color.BLACK);
            tick();
        }

        void stop() {
            h.removeCallbacksAndMessages(null);
        }

        private void tick() {
            invalidate();
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    tick();
                }
            }, 33L);
        }

        private void drawCover(Canvas c, Bitmap b, float zoom, float fx, float fy, int alpha) {
            float w = getWidth(), hgt = getHeight();
            float s = Math.max(w / b.getWidth(), hgt / b.getHeight()) * zoom;
            float dw = b.getWidth() * s, dh = b.getHeight() * s;
            // fx, fy: the point of the picture (0..1) that is kept in the middle when zoomed
            float left = w / 2f - fx * dw, top = hgt / 2f - fy * dh;
            left = Math.min(0f, Math.max(w - dw, left));
            top = Math.min(0f, Math.max(hgt - dh, top));
            p.setAlpha(alpha);
            c.drawBitmap(b, null, new RectF(left, top, left + dw, top + dh), p);
            p.setAlpha(255);
        }

        private void drawFlip(Canvas c, List<Bitmap> fr, long el, long dur) {
            int n = fr.size();
            float f = Math.min(1f, el / (float) dur) * (n - 1);
            int i = (int) f;
            float part = f - i;
            drawCover(c, fr.get(i), 1f, 0.5f, 0.5f, 255);
            if (i + 1 < n && part > 0.55f) drawCover(c, fr.get(i + 1), 1f, 0.5f, 0.5f, (int) (255 * (part - 0.55f) / 0.45f));
        }

        @Override
        protected void onDraw(Canvas c) {
            long now = SystemClock.uptimeMillis();
            long el = now - t0;
            float w = getWidth(), hgt = getHeight();
            boolean ending = sleepStart >= 0;
            if (!ending) {
                if (!crawl.isEmpty()) {
                    drawFlip(c, crawl, still ? CRAWL_MS : el, CRAWL_MS);
                } else if (crawlFb != null) {
                    float k = still ? 1f : Math.min(1f, el / (float) CRAWL_MS);
                    // from the whole picture to his angry face
                    drawCover(c, crawlFb, 1f + 0.9f * k * k, 0.37f, 0.62f, 255);
                }
                boolean done = still || el >= CRAWL_MS;
                if (done) drawButton(c, w, hgt);
            } else {
                long se = now - sleepStart;
                if (!sleep.isEmpty()) {
                    drawFlip(c, sleep, still ? SLEEP_MS : se, SLEEP_MS - 1000L);
                } else if (tiredFb != null) {
                    float k = still ? 1f : Math.min(1f, se / (float) SLEEP_MS);
                    drawCover(c, tiredFb, 1.15f, 0.5f, 0.45f, 255);
                    // the room slowly darkens as he nods off
                    p.setColor(Color.argb((int) (170 * k), 0, 0, 0));
                    c.drawRect(0f, 0f, w, hgt, p);
                }
                drawZzz(c, w, hgt, se);
                long fadeStart = SLEEP_MS - FADE_MS;
                if (se > fadeStart) {
                    float f = Math.min(1f, (se - fadeStart) / (float) FADE_MS);
                    p.setColor(Color.argb((int) (255 * f), 0, 0, 0));
                    c.drawRect(0f, 0f, w, hgt, p);
                }
                if (se >= SLEEP_MS && !closing) {
                    closing = true;
                    EyeReminder.rested(EyeRestActivity.this);
                    finish();
                }
            }
        }

        private void drawButton(Canvas c, float w, float hgt) {
            float bw = Math.min(w * 0.68f, 520f), bh = 74f * getResources().getDisplayMetrics().density / 2.6f + 20f;
            float x0 = (w - bw) / 2f, y0 = hgt * 0.84f;
            btn.set(x0, y0, x0 + bw, y0 + bh);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.parseColor("#ECE3D0"));
            c.drawRoundRect(btn, 10f, 10f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4f);
            p.setColor(Color.parseColor("#1B1B1A"));
            c.drawRoundRect(btn, 10f, 10f, p);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(bebas);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(bh * 0.55f);
            p.setLetterSpacing(0.08f);
            p.setColor(Color.parseColor("#1B1B1A"));
            c.drawText("I RESTED", btn.centerX(), btn.centerY() + bh * 0.2f, p);
            p.setLetterSpacing(0f);
            p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.DEFAULT);
        }

        /** Three "Z" letters that rise, grow and fade one after another. */
        private void drawZzz(Canvas c, float w, float hgt, long se) {
            p.setTypeface(bebas);
            p.setTextAlign(Paint.Align.CENTER);
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 3; i++) {
                float t = ((se - i * 900L) % 3600L) / 3600f;
                if (se - i * 900L < 0) continue;
                float y = hgt * 0.40f - t * hgt * 0.16f;
                float x = w * 0.50f + i * w * 0.045f + (float) Math.sin(t * 6.0) * 6f;
                float size = (hgt * 0.035f) * (1f + i * 0.45f) * (0.8f + 0.5f * t);
                p.setTextSize(size);
                p.setColor(Color.argb((int) (230 * Math.sin(Math.PI * Math.min(1f, t * 1.05f))), 236, 227, 208));
                c.drawText("Z", x, y, p);
            }
            p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.DEFAULT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_UP && sleepStart < 0
                    && (still || SystemClock.uptimeMillis() - t0 >= CRAWL_MS) && btn.contains(e.getX(), e.getY())) {
                sleepStart = SystemClock.uptimeMillis();
                return true;
            }
            return true;
        }
    }
}
