package com.horizon.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LightingColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Page 2 of the home screen: a retro room. The window shows the same sky, sun, moon, weather and scene as page 1,
 * the wall lamp burns at night, and every object opens a small shelf of apps right next to it.
 */
final class RoomView extends View {

    interface Host {
        void closeRoom();

        void openDrawer();

        void openNotifications();

        void editShelf(String key, String title);
    }

    static final class AppRef {
        String label;
        ComponentName cn;
    }

    private static final int IW = 941, IH = 1671;
    private static final float WX0 = 55f, WY0 = 287f, WW = 192f, WH = 247f;
    private static final float[][] PANES = {{55, 287, 142, 404}, {161, 287, 247, 404}, {55, 423, 142, 534}, {161, 423, 247, 534}};
    private static final float LAMP_X = 471f, LAMP_Y = 330f;
    private static final float[][] BULBS = {{386f, 267f}, {556f, 267f}};

    // key, title, then the tap area in picture pixels
    private static final String[] KEYS = {"board", "tv", "fridge", "table", "robot", "bag"};
    private static final String[] TITLES = {"NOTICE BOARD", "TV", "FRIDGE", "TABLE", "ROBOT", "BAG"};
    private static final float[][] HOTS = {
            {638, 283, 922, 573}, {80, 640, 476, 1092}, {652, 688, 926, 1282},
            {0, 1300, 504, 1546}, {538, 1150, 684, 1462}, {782, 1150, 932, 1398}};
    private static final String[][] WORDS = {
            {"keep", "notes", "note", "calendar", "docs"},
            {"youtube", "vlc", "gallery", "photos", "mx player", "prime video", "netflix", "hotstar", "jiocinema", "video"},
            {"swiggy", "zomato", "domino", "pizza hut", "blinkit", "zepto", "eatsure"},
            {"calculator", "torch", "flashlight", "files", "clock"},
            {"claude", "gemini", "chatgpt", "copilot", "perplexity", "grok"},
            {"amazon", "flipkart", "myntra", "meesho", "ajio"}};

    // times of day: hour, r, g, b
    private static final float[][] SKY_TOP = {{0, 8, 12, 38}, {5, 20, 26, 62}, {6.3f, 200, 120, 130}, {7.5f, 110, 170, 225}, {12, 78, 160, 235},
            {16, 100, 170, 228}, {18, 235, 130, 80}, {19.2f, 70, 56, 110}, {20.5f, 12, 16, 48}, {24, 8, 12, 38}};
    private static final float[][] SKY_BOT = {{0, 26, 34, 84}, {5, 80, 70, 120}, {6.3f, 255, 190, 130}, {7.5f, 205, 232, 247}, {12, 190, 226, 248},
            {16, 232, 226, 192}, {18, 255, 198, 120}, {19.2f, 196, 106, 100}, {20.5f, 30, 38, 88}, {24, 26, 34, 84}};
    private static final float[][] WASH = {{0, 74, 86, 140}, {5, 88, 94, 146}, {6.5f, 255, 214, 180}, {8, 255, 244, 230}, {12, 255, 255, 255},
            {16, 255, 246, 228}, {17.8f, 255, 196, 150}, {19, 130, 106, 142}, {20.5f, 74, 86, 140}, {24, 74, 86, 140}};

    private final PosterView src;
    private final Host host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SharedPreferences prefs;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private final int touchSlop;
    private Typeface bebas, roboto;

    private Bitmap room, spot, badgeTired, badgeAngry;
    private float scale = 1f, offX = 0f, offY = 0f;
    private int bottomInset = 0;

    private final float[][] stars = new float[46][4], clouds = new float[12][4], drops = new float[70][3];

    // sun and moon from the real sky, refreshed every half minute
    private long astroAt = 0L;
    private Astro.Arc sunArc, moonArc;

    // shelf pop-up
    private String openKey = null;
    private final RectF card = new RectF();
    private final RectF closeBtn = new RectF();
    private final List<RectF> cellRects = new ArrayList<RectF>();
    private List<AppRef> openApps = new ArrayList<AppRef>();
    private final HashMap<String, List<AppRef>> shelfCache = new HashMap<String, List<AppRef>>();
    private final HashMap<String, Bitmap> icons = new HashMap<String, Bitmap>();
    private List<AppRef> installedCache;
    private long popupAt = 0L;
    private float arrowX = 0f;
    private boolean cardBelow = true;

    // rest card
    private boolean restOpen = false;
    private final RectF restCard = new RectF();
    private final RectF restBtn = new RectF();
    private final RectF stripHit = new RectF();

    // touch
    private float downX, downY;
    private long downTime;
    private boolean longFired = false;
    private String downKey = null;
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            if (downKey == null) return;
            longFired = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            String k = downKey;
            int i = indexOf(k);
            if (host != null && i >= 0) host.editShelf(k, TITLES[i]);
        }
    };
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (isShown()) handler.postDelayed(this, 70);
        }
    };

    RoomView(Context ctx, PosterView poster, Host host) {
        super(ctx);
        this.src = poster;
        this.host = host;
        this.prefs = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
        this.dp = ctx.getResources().getDisplayMetrics().density;
        this.touchSlop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        try {
            bebas = Typeface.createFromAsset(ctx.getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(ctx.getAssets(), "Roboto-Regular.ttf");
        } catch (Throwable t) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }
        room = asset(ctx, "room.webp");
        badgeTired = asset(ctx, "badge_boy_tired.webp");
        badgeAngry = asset(ctx, "badge_boy_angry.webp");
        java.util.Random rs = new java.util.Random(7);
        for (float[] s : stars) {
            s[0] = rs.nextFloat() * WW;
            s[1] = rs.nextFloat() * WH * 0.75f;
            s[2] = 0.6f + rs.nextFloat() * 1.3f;
            s[3] = rs.nextFloat() * 6.28f;
        }
        for (float[] c : clouds) {
            c[0] = rs.nextFloat() * (WW + 160f);
            c[1] = 14f + rs.nextFloat() * WH * 0.5f;
            c[2] = 0.7f + rs.nextFloat() * 0.9f;
            c[3] = 4f + rs.nextFloat() * 8f;
        }
        for (float[] d : drops) {
            d[0] = rs.nextFloat() * WW;
            d[1] = rs.nextFloat() * WH;
            d[2] = 3f + rs.nextFloat() * 3f;
        }
    }

    private static Bitmap asset(Context ctx, String name) {
        try {
            InputStream in = ctx.getAssets().open(name);
            try {
                return BitmapFactory.decodeStream(in);
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return null;
        }
    }

    void setBottomInset(int px) {
        bottomInset = px;
        invalidate();
    }

    /** Forget which apps are on the shelves (after the user changed them, or apps were installed). */
    void reloadShelves() {
        shelfCache.clear();
        installedCache = null;
        openKey = null;
        invalidate();
    }

    void closePopups() {
        openKey = null;
        restOpen = false;
        invalidate();
    }

    boolean hasPopup() {
        return openKey != null || restOpen;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacks(ticker);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onVisibilityChanged(View changed, int visibility) {
        super.onVisibilityChanged(changed, visibility);
        handler.removeCallbacks(ticker);
        if (visibility == VISIBLE) handler.post(ticker);
        else closePopups();
    }

    // ---------- time and colour helpers ----------

    private static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }

    private static float sm(float a, float b, float v) {
        float t = clamp((v - a) / (b - a), 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private static int mixc(int a, int b, float t) {
        t = clamp(t, 0f, 1f);
        return Color.rgb(Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t),
                Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t),
                Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    private static int keyed(float[][] f, float h) {
        for (int i = 0; i < f.length - 1; i++) {
            if (h >= f[i][0] && h <= f[i + 1][0]) {
                float t = (h - f[i][0]) / Math.max(0.0001f, f[i + 1][0] - f[i][0]);
                return Color.rgb(Math.round(f[i][1] + (f[i + 1][1] - f[i][1]) * t),
                        Math.round(f[i][2] + (f[i + 1][2] - f[i][2]) * t),
                        Math.round(f[i][3] + (f[i + 1][3] - f[i][3]) * t));
            }
        }
        float[] l = f[f.length - 1];
        return Color.rgb((int) l[1], (int) l[2], (int) l[3]);
    }

    /** Today's real sunrise and sunset are stretched onto the hours the colour tables were drawn for. */
    private float effectiveHour(int nowMin, int sr, int ss) {
        if (ss <= sr + 120) {
            sr = 6 * 60;
            ss = 18 * 60 + 30;
        }
        float eh;
        if (nowMin >= sr && nowMin <= ss) {
            eh = 6.3f + (nowMin - sr) / (float) (ss - sr) * 12.2f;
        } else {
            float night = 1440f - (ss - sr);
            float since = nowMin > ss ? nowMin - ss : nowMin + 1440f - ss;
            eh = 18.5f + since / night * 11.8f;
        }
        return eh % 24f;
    }

    private static float nightK(float h) {
        return 1f - Math.max(sm(5.5f, 7.5f, h) * (1f - sm(17.5f, 19.5f, h)), 0f);
    }

    private static float lampK(float h) {
        return h >= 12f ? sm(17.3f, 19f, h) : 1f - sm(6f, 7.6f, h);
    }

    private void refreshAstro(long now) {
        if (sunArc != null && now - astroAt < 30000L) return;
        try {
            double[] ll = Loc.get(getContext());
            sunArc = Astro.arc(false, now, ll[0], ll[1]);
            moonArc = Astro.arc(true, now, ll[0], ll[1]);
            astroAt = now;
        } catch (Throwable t) {
            sunArc = null;
            moonArc = null;
        }
    }

    // ---------- drawing ----------

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        c.drawColor(0xFFF1E6CC);
        if (room == null) return;
        int availH = Math.max(1, h - bottomInset);
        scale = Math.min(w / (float) IW, availH / (float) IH);
        offX = (w - IW * scale) / 2f;
        offY = availH - IH * scale;

        // the picture is bottom-anchored: taller phones get more of the cream wall strip at the top
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(room.getPixel(8, 8));
        c.drawRect(0, 0, w, offY + 2f, p);
        p.setColor(room.getPixel(IW / 2, IH - 3));
        c.drawRect(0, availH - 1f, w, h, p);

        Calendar cal = Calendar.getInstance();
        long now = System.currentTimeMillis();
        int nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        float eh = effectiveHour(nowMin, src.sunriseMin(), src.sunsetMin());
        float k = nightK(eh);
        float lamp = lampK(eh);
        boolean ink = src.inkOnly();
        refreshAstro(now);

        c.save();
        c.translate(offX, 0f);
        c.scale(scale, scale);
        final float oy = offY / scale;       // how far the picture sits below the top of the screen, in picture pixels
        final float strip = 112f;            // height of the cream strip at the top of the picture

        if (ink) {
            ColorMatrix g = new ColorMatrix();
            g.setSaturation(0f);
            ColorMatrix hi = new ColorMatrix(new float[]{1.25f, 0, 0, 0, -28, 0, 1.25f, 0, 0, -28, 0, 0, 1.25f, 0, -28, 0, 0, 0, 1, 0});
            g.postConcat(hi);
            bmpPaint.setColorFilter(new ColorMatrixColorFilter(g));
        } else {
            bmpPaint.setColorFilter(new LightingColorFilter(keyed(WASH, eh), 0));
        }
        if (oy > 0.5f) {
            // a taller phone: the strip stays at the very top and the wall above the picture is the wallpaper mirrored upwards
            c.drawBitmap(room, new Rect(0, 0, IW, (int) strip), new RectF(0, 0, IW, strip), bmpPaint);
            float th = 112f;
            Rect tileSrc = new Rect(0, (int) strip, IW, (int) (strip + th));
            for (int i = 0; ; i++) {
                float y = oy + strip - (i + 1) * th;
                if (y + th <= strip) break;
                c.save();
                c.clipRect(0, strip, IW, oy + strip);
                if (i % 2 == 0) c.scale(1f, -1f, 0f, y + th / 2f);
                c.drawBitmap(room, tileSrc, new RectF(0, y, IW, y + th), bmpPaint);
                c.restore();
            }
        }
        c.save();
        c.translate(0f, oy);
        c.clipRect(0, oy > 0.5f ? strip : 0, IW, IH);
        c.drawBitmap(room, 0, 0, bmpPaint);
        bmpPaint.setColorFilter(null);

        if (!ink) {
            if (lamp > 0.01f) {
                ensureSpot();
                float fl = 0.92f + 0.08f * (float) (Math.sin(now / 90.0) * Math.sin(now / 233.0 + 1.3));
                if (spot != null) {
                    bmpPaint.setAlpha((int) (255 * clamp(lamp * 0.95f * fl, 0f, 1f)));
                    c.drawBitmap(spot, 0, 0, bmpPaint);
                    bmpPaint.setAlpha(255);
                }
            }
            drawWindow(c, now, eh, k);
            if (lamp > 0.01f) drawLamp(c, now, lamp);
            if (k > 0.2f) drawTvGlow(c, now, k);
        } else {
            // low battery: the window is plain ink, the lamp stays out
            drawWindowInk(c);
        }
        c.restore();
        drawStrip(c, now, k, ink);
        c.restore();

        drawPopups(c, w, availH, k);
    }

    private void ensureSpot() {
        if (spot != null || room == null) return;
        try {
            spot = Bitmap.createBitmap(IW, IH, Bitmap.Config.ARGB_8888);
            Canvas sc = new Canvas(spot);
            sc.drawBitmap(room, 0, 0, null);
            Paint pp = new Paint();
            pp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
            pp.setColor(Color.argb(52, 255, 196, 120));
            sc.drawRect(0, 0, IW, IH, pp);
            Paint pm = new Paint();
            pm.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            pm.setShader(new RadialGradient(LAMP_X, LAMP_Y + 30f, 430f,
                    new int[]{0xFF000000, 0x8C000000, 0x00000000}, new float[]{0.07f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            sc.drawRect(0, 0, IW, IH, pm);
        } catch (Throwable t) {
            spot = null;
        }
    }

    private void drawLamp(Canvas c, long now, float lamp) {
        float fl = 0.92f + 0.08f * (float) (Math.sin(now / 90.0) * Math.sin(now / 233.0 + 1.3));
        Paint g = new Paint();
        g.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
        g.setShader(new RadialGradient(LAMP_X, LAMP_Y, 360f, Color.argb((int) (255 * 0.34f * lamp * fl), 255, 176, 84),
                Color.argb(0, 255, 150, 60), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, IW, 720, g);
        for (int i = 0; i < BULBS.length; i++) {
            float f = i == 1 ? fl : 0.94f + 0.06f * (float) Math.sin(now / 140.0);
            drawFlame(c, BULBS[i][0], BULBS[i][1], lamp, f);
        }
    }

    private void drawFlame(Canvas c, float cx, float top, float lamp, float f) {
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
        g.setShader(new RadialGradient(cx, top + 30f, 90f, Color.argb((int) (255 * 0.55f * lamp * f), 255, 200, 110),
                Color.argb(0, 255, 170, 70), Shader.TileMode.CLAMP));
        c.drawRect(cx - 90f, top - 60f, cx + 90f, top + 120f, g);
        Path fp = new Path();
        fp.moveTo(cx, top);
        fp.cubicTo(cx + 4, top + 14, cx + 13, top + 28, cx + 13, top + 40);
        fp.cubicTo(cx + 13, top + 52, cx + 6, top + 58, cx, top + 58);
        fp.cubicTo(cx - 6, top + 58, cx - 13, top + 52, cx - 13, top + 40);
        fp.cubicTo(cx - 13, top + 28, cx - 4, top + 14, cx, top);
        fp.close();
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        q.setShader(new LinearGradient(0, top, 0, top + 58f, Color.argb((int) (255 * lamp), 255, 248, 214),
                Color.argb((int) (255 * lamp), 255, 184, 80), Shader.TileMode.CLAMP));
        c.drawPath(fp, q);
    }

    private void drawTvGlow(Canvas c, long now, float k) {
        c.save();
        c.clipRect(118, 866, 366, 1056);
        Paint g = new Paint();
        g.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
        float ta = 0.5f * k * (0.86f + 0.14f * (float) (Math.sin(now / 120.0) * Math.sin(now / 77.0)));
        g.setShader(new RadialGradient(242f, 960f, 160f, Color.argb((int) (255 * ta), 150, 196, 236),
                Color.argb((int) (255 * ta * 0.45f), 90, 120, 170), Shader.TileMode.CLAMP));
        c.drawRect(118, 866, 366, 1056, g);
        c.restore();
    }

    // ---------- the view outside the window ----------

    private Path panePath() {
        Path pp = new Path();
        for (float[] r : PANES) pp.addRect(r[0], r[1], r[2], r[3], Path.Direction.CW);
        return pp;
    }

    private void drawWindowInk(Canvas c) {
        c.save();
        c.clipPath(panePath());
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFEFE6D2);
        c.drawRect(WX0, WY0, WX0 + WW, WY0 + WH, p);
        p.setColor(0xFF2A2724);
        Path hill = new Path();
        hill.moveTo(WX0, WY0 + WH);
        hill.lineTo(WX0, WY0 + WH - 60);
        hill.lineTo(WX0 + 60, WY0 + WH - 96);
        hill.lineTo(WX0 + 120, WY0 + WH - 62);
        hill.lineTo(WX0 + WW, WY0 + WH - 80);
        hill.lineTo(WX0 + WW, WY0 + WH);
        hill.close();
        c.drawPath(hill, p);
        c.restore();
    }

    private String silhouetteType() {
        String id = src.sceneId();
        if ("dunes".equals(id)) return "dunes";
        if ("sea".equals(id) || "andaman".equals(id)) return "sea";
        if ("city".equals(id) || "redfort".equals(id) || "indiagate".equals(id)) return "city";
        if ("palms".equals(id)) return "palms";
        if ("peaks".equals(id) || "himalaya".equals(id) || "highway".equals(id) || "mehrangarh".equals(id)) return "peaks";
        return "lake";
    }

    private void drawWindow(Canvas c, long now, float eh, float k) {
        float cloud = src.cloudAmount();
        int rain = src.roomRain();
        boolean snow = src.roomSnow();
        float fog = src.roomFog();
        c.save();
        c.clipPath(panePath());
        int top = keyed(SKY_TOP, eh), bot = keyed(SKY_BOT, eh);
        if (cloud > 0.05f || rain > 0) {
            int grey = mixc(Color.rgb(120, 128, 140), Color.rgb(40, 44, 56), k);
            float amt = clamp(cloud * 0.55f + rain * 0.1f, 0f, 0.7f);
            top = mixc(top, grey, amt);
            bot = mixc(bot, mixc(Color.rgb(120, 128, 140), Color.rgb(50, 54, 66), k), amt);
        }
        if (fog > 0f) bot = mixc(bot, Color.rgb(200, 200, 200), 0.35f * Math.min(1f, fog * 1.4f));
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, WY0, 0, WY0 + WH, top, bot, Shader.TileMode.CLAMP));
        c.drawRect(WX0, WY0, WX0 + WW, WY0 + WH, p);
        p.setShader(null);

        float cover = rain > 0 || fog > 0.3f ? 0.1f : clamp(1f - cloud * 0.8f, 0.15f, 1f);
        if (k > 0.25f) {
            for (float[] s : stars) {
                p.setColor(Color.argb((int) (255 * clamp(k * cover * (0.55f + 0.4f * (float) Math.sin(now / 600.0 + s[3])), 0f, 1f)), 255, 255, 240));
                c.drawRect(WX0 + s[0], WY0 + s[1], WX0 + s[0] + s[2], WY0 + s[1] + s[2], p);
            }
        }
        // the real sun and moon, on arcs across the window
        if (sunArc != null && sunArc.up && rain < 2) {
            float u = sunArc.t;
            float hk = 0.55f + 0.45f * clamp((sunArc.maxAlt - 25f) / 65f, 0f, 1f);
            float sx = WX0 + u * WW, sy = WY0 + WH * 0.86f - (float) Math.sin(Math.PI * u) * WH * 0.66f * hk;
            float warm = 1f - (float) Math.sin(Math.PI * u);
            int sc = mixc(Color.rgb(255, 244, 200), Color.rgb(255, 150, 70), clamp(warm * 1.4f, 0f, 1f));
            float vis = (1f - 0.6f * cloud) * (fog > 0.3f ? 0.6f : 1f);
            p.setShader(new RadialGradient(sx, sy, 70f, Color.argb((int) (255 * 0.7f * vis), Color.red(sc), Color.green(sc), Color.blue(sc)),
                    Color.argb(0, Color.red(sc), Color.green(sc), Color.blue(sc)), Shader.TileMode.CLAMP));
            c.drawRect(sx - 70, sy - 70, sx + 70, sy + 70, p);
            p.setShader(null);
            p.setColor(Color.argb((int) (255 * clamp(vis + 0.2f, 0f, 1f)), Color.red(sc), Color.green(sc), Color.blue(sc)));
            c.drawCircle(sx, sy, 11f, p);
        }
        if (moonArc != null && moonArc.up && rain < 2 && fog < 0.5f) {
            float u = moonArc.t;
            float hk = 0.55f + 0.45f * clamp((moonArc.maxAlt - 25f) / 65f, 0f, 1f);
            float mx = WX0 + u * WW, my = WY0 + WH * 0.84f - (float) Math.sin(Math.PI * u) * WH * 0.62f * hk;
            p.setShader(new RadialGradient(mx, my, 40f, Color.argb(72, 240, 236, 210), Color.argb(0, 240, 236, 210), Shader.TileMode.CLAMP));
            c.drawRect(mx - 40, my - 40, mx + 40, my + 40, p);
            p.setShader(null);
            int day = sunArc != null && sunArc.up ? 110 : 255;
            Moon.draw(c, p, mx, my, 11f, moonArc.phase, 0xFFF4EFD8, (int) (day * (1f - 0.5f * cloud)));
            p.setAlpha(255);
        }
        // clouds
        int n = Math.min(clouds.length, 2 + Math.round(cloud * 10f) + rain);
        int cc = mixc(mixc(Color.WHITE, Color.rgb(255, 170, 120), sm(16.5f, 18.2f, eh) * (1f - sm(18.6f, 19.6f, eh))), Color.rgb(38, 46, 78), k);
        if (cloud > 0.5f || rain > 0) cc = mixc(cc, Color.rgb(120, 126, 136), 0.5f);
        p.setColor(Color.argb(217, Color.red(cc), Color.green(cc), Color.blue(cc)));
        for (int i = 0; i < n; i++) {
            float[] cl = clouds[i];
            float cx = ((cl[0] + now / 1000f * cl[3]) % (WW + 160f)) - 80f + WX0, cy = WY0 + cl[1], s = 10f * cl[2];
            c.drawCircle(cx, cy, s, p);
            c.drawCircle(cx + s * 1.1f, cy + 2, s * 0.8f, p);
            c.drawCircle(cx - s * 1.1f, cy + 3, s * 0.7f, p);
            c.drawCircle(cx + s * 0.2f, cy - s * 0.5f, s * 0.8f, p);
        }
        drawSilhouette(c, silhouetteType(), eh, k, now);
        if (rain > 0 || snow) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(snow ? 2.4f : 1.1f);
            p.setColor(snow ? Color.argb(210, 255, 255, 255) : Color.argb((int) (255 * (0.55f - 0.25f * k)), 205, 220, 240));
            int cnt = snow ? 40 : (rain == 1 ? 30 : (rain == 2 ? 50 : 70));
            Path dp = new Path();
            for (int i = 0; i < cnt && i < drops.length; i++) {
                float[] d = drops[i];
                float y = (d[1] + now / 5f * d[2] * (snow ? 0.03f : 0.1f)) % WH;
                dp.moveTo(WX0 + d[0], WY0 + y);
                dp.lineTo(WX0 + d[0] - (snow ? 0f : 2f), WY0 + y + (snow ? 1.5f : 9f));
            }
            c.drawPath(dp, p);
            p.setStyle(Paint.Style.FILL);
        }
        if (fog > 0f) {
            int fc = mixc(Color.rgb(226, 224, 214), Color.rgb(40, 46, 62), k);
            p.setColor(Color.argb((int) (255 * Math.min(0.8f, fog * 0.8f)), Color.red(fc), Color.green(fc), Color.blue(fc)));
            c.drawRect(WX0, WY0, WX0 + WW, WY0 + WH, p);
        }
        // glass shine
        p.setShader(new LinearGradient(WX0, WY0, WX0 + WW, WY0 + WH, new int[]{0x2EFFFFFF, 0x00FFFFFF, 0x0DFFFFFF},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(WX0, WY0, WX0 + WW, WY0 + WH, p);
        p.setShader(null);
        c.restore();
    }

    private void poly(Canvas c, float[][] pts, int fill) {
        Path pa = new Path();
        pa.moveTo(pts[0][0], pts[0][1]);
        for (int i = 1; i < pts.length; i++) pa.lineTo(pts[i][0], pts[i][1]);
        pa.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(fill);
        c.drawPath(pa, p);
    }

    private void palm(Canvas c, float x, float y, float h, int fill) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3f);
        p.setColor(fill);
        Path st = new Path();
        st.moveTo(x, y);
        st.quadTo(x + 6, y - h * 0.5f, x + 2, y - h);
        c.drawPath(st, p);
        p.setStyle(Paint.Style.FILL);
        float[] ds = {-1f, -0.45f, 0.45f, 1f};
        for (float d : ds) {
            Path lf = new Path();
            lf.moveTo(x + 2, y - h);
            lf.quadTo(x + 2 + d * 20, y - h - 14, x + 2 + d * 30, y - h + 8);
            lf.quadTo(x + 2 + d * 18, y - h - 4, x + 2, y - h);
            c.drawPath(lf, p);
        }
    }

    private void drawSilhouette(Canvas c, String type, float eh, float k, long now) {
        int col = mixc(Color.rgb(60, 76, 70), Color.rgb(14, 20, 34), k);
        int far = mixc(col, keyed(SKY_BOT, eh), 0.5f);
        float bot = WY0 + WH;
        p.setStyle(Paint.Style.FILL);
        if (type.equals("lake") || type.equals("peaks")) {
            boolean tall = type.equals("peaks");
            float[] xs = tall ? new float[]{20, 48, 72, 100, 130, 160, 192} : new float[]{30, 70, 120, 170, 192};
            float[] ys = tall ? new float[]{120, 60, 100, 50, 96, 66, 110} : new float[]{78, 58, 84, 66, 80};
            float[][] pk = new float[xs.length + 4][];
            pk[0] = new float[]{WX0, bot - 70};
            for (int i = 0; i < xs.length; i++) pk[i + 1] = new float[]{WX0 + xs[i], bot - ys[i]};
            pk[xs.length + 1] = new float[]{WX0 + WW, bot - 60};
            pk[xs.length + 2] = new float[]{WX0 + WW, bot};
            pk[xs.length + 3] = new float[]{WX0, bot};
            poly(c, pk, far);
            if (tall && k < 0.7f) {
                p.setColor(Color.argb((int) (255 * 0.85f * (1f - k)), 255, 255, 255));
                float[][] caps = {{48, 60}, {100, 50}, {160, 66}};
                for (float[] cp : caps) {
                    Path t = new Path();
                    t.moveTo(WX0 + cp[0], bot - cp[1]);
                    t.lineTo(WX0 + cp[0] - 9, bot - cp[1] + 16);
                    t.lineTo(WX0 + cp[0] + 9, bot - cp[1] + 16);
                    t.close();
                    c.drawPath(t, p);
                }
            }
            poly(c, new float[][]{{WX0, bot - 42}, {WX0 + 60, bot - 50}, {WX0 + 140, bot - 40}, {WX0 + WW, bot - 48}, {WX0 + WW, bot}, {WX0, bot}}, col);
            if (type.equals("lake")) {
                float wy = bot - 34;
                int g = mixc(keyed(SKY_BOT, eh), Color.rgb(40, 70, 90), 0.45f);
                p.setColor(Color.argb(242, Color.red(g), Color.green(g), Color.blue(g)));
                c.drawRect(WX0, wy, WX0 + WW, wy + 40, p);
                p.setColor(Color.argb((int) (255 * 0.12f * (1f - k)), 255, 255, 255));
                for (int j = 0; j < 4; j++) {
                    float rx = WX0 + 20 + j * 44 + (float) Math.sin(now / 700.0 + j) * 6f;
                    c.drawRect(rx, wy + 8 + j * 5, rx + 26, wy + 9.6f + j * 5, p);
                }
            }
        } else if (type.equals("dunes")) {
            Path d1 = new Path();
            d1.moveTo(WX0, bot);
            d1.lineTo(WX0, bot - 66);
            for (float x = 0; x <= WW; x += 8) d1.lineTo(WX0 + x, bot - 62 - (float) Math.sin(x / 34.0) * 14f - (float) Math.sin(x / 15.0) * 3f);
            d1.lineTo(WX0 + WW, bot);
            d1.close();
            p.setColor(mixc(Color.rgb(196, 160, 104), Color.rgb(28, 30, 52), k));
            c.drawPath(d1, p);
            Path d2 = new Path();
            d2.moveTo(WX0, bot);
            d2.lineTo(WX0, bot - 34);
            for (float x = 0; x <= WW; x += 8) d2.lineTo(WX0 + x, bot - 34 - (float) Math.sin(x / 26.0 + 2) * 10f);
            d2.lineTo(WX0 + WW, bot);
            d2.close();
            p.setColor(mixc(Color.rgb(170, 130, 82), Color.rgb(20, 22, 40), k));
            c.drawPath(d2, p);
            palm(c, WX0 + 150, bot - 40, 48, col);
            palm(c, WX0 + 170, bot - 38, 34, col);
        } else if (type.equals("sea")) {
            float hy = bot - 78;
            p.setColor(mixc(keyed(SKY_BOT, eh), Color.rgb(20, 70, 120), 0.55f + 0.2f * k));
            c.drawRect(WX0, hy, WX0 + WW, hy + 80, p);
            p.setColor(Color.argb((int) (255 * 0.2f * (1f - k)), 255, 255, 255));
            for (int j = 0; j < 7; j++) {
                float rx = WX0 + ((j * 37 + now / 40f) % WW);
                c.drawRect(rx, hy + 8 + j * 9, rx + 22, hy + 9.5f + j * 9, p);
            }
            p.setColor(mixc(far, Color.rgb(10, 20, 40), 0.2f));
            c.drawRect(WX0, hy - 1, WX0 + WW, hy + 1, p);
        } else if (type.equals("city")) {
            float[][] bs = {{6, 60}, {26, 96}, {46, 70}, {64, 120}, {86, 84}, {106, 104}, {128, 66}, {148, 110}, {170, 78}};
            for (int bi = 0; bi < bs.length; bi++) {
                float[] b = bs[bi];
                p.setColor(mixc(bi % 2 == 1 ? col : far, Color.rgb(10, 14, 28), 0.15f));
                c.drawRect(WX0 + b[0], bot - b[1], WX0 + b[0] + 18, bot, p);
                if (k > 0.35f) {
                    p.setColor(Color.argb((int) (255 * 0.85f * k), 255, 214, 120));
                    for (float wy2 = bot - b[1] + 6; wy2 < bot - 6; wy2 += 11) {
                        for (float wx = 3; wx < 16; wx += 7) {
                            if (((int) (wy2 * 7 + wx * 13 + bi * 5) % 5) < 3) c.drawRect(WX0 + b[0] + wx, wy2, WX0 + b[0] + wx + 3, wy2 + 4, p);
                        }
                    }
                }
            }
        } else {
            float hy2 = bot - 56;
            p.setColor(mixc(keyed(SKY_BOT, eh), Color.rgb(20, 80, 120), 0.5f + 0.2f * k));
            c.drawRect(WX0, hy2, WX0 + WW, hy2 + 60, p);
            poly(c, new float[][]{{WX0, bot}, {WX0, bot - 30}, {WX0 + 70, bot - 22}, {WX0 + WW, bot - 34}, {WX0 + WW, bot}},
                    mixc(Color.rgb(205, 176, 120), Color.rgb(24, 26, 44), k));
            palm(c, WX0 + 40, bot - 24, 70, col);
            palm(c, WX0 + 160, bot - 28, 58, col);
            palm(c, WX0 + 118, bot - 22, 40, col);
        }
    }

    // ---------- the cream strip at the top ----------

    private String restText(long ms) {
        long s = ms / 1000L;
        long m = Math.min(99L, s / 60L);
        if (s / 60L >= 99L) s = 59L; else s = s % 60L;
        return String.format(Locale.US, "%02d:%02d", m, s);
    }

    private void drawStrip(Canvas c, long now, float k, boolean ink) {
        long since = EyeReminder.sinceRest(getContext());
        long min = since / 60000L;
        boolean quiet = EyeReminder.quiet();
        boolean late = !quiet && min >= 20L;
        int stage = quiet ? 0 : (min >= 60L ? 3 : (min >= 40L ? 2 : 0));
        int inkC = 0xFF2A2118, red = 0xFFC8420F;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(roboto);
        p.setTextAlign(Paint.Align.LEFT);
        p.setColor(inkC);
        p.setTextSize(24f);
        p.setLetterSpacing(0.06f);
        c.drawText(quiet ? "RESTING HOURS" : "LAST REST", 26f, 36f, p);
        p.setLetterSpacing(0f);
        p.setTypeface(bebas);
        p.setTextSize(80f);
        p.setColor(late ? red : inkC);
        c.drawText(restText(since), 24f, 102f, p);
        p.setTypeface(roboto);
        p.setTextSize(24f);
        p.setColor(inkC);
        p.setLetterSpacing(0.06f);
        c.drawText("20-20-20 STREAK", 330f, 36f, p);
        p.setLetterSpacing(0f);
        int streak = EyeReminder.streak(getContext());
        p.setTypeface(bebas);
        p.setTextSize(38f);
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(streak + (streak == 1 ? " DAY" : " DAYS"), 700f, 36f, p);
        p.setTextAlign(Paint.Align.LEFT);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3f);
        for (int i = 0; i < 7; i++) {
            RectF r = new RectF(330f + i * 52f, 52f, 330f + i * 52f + 42f, 94f);
            if (i < Math.min(streak, 7)) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(red);
                c.drawRect(r, p);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setColor(inkC);
            c.drawRect(r, p);
        }
        p.setStyle(Paint.Style.FILL);
        stripHit.set(0f, 0f, 930f, 112f);

        // badge: the boy gets angrier the longer the eyes go without rest
        RectF fr = new RectF(792f, 8f, 918f, 106f);
        Bitmap bmp = stage >= 2 ? badgeAngry : badgeTired;
        if (bmp != null) {
            int sw = bmp.getWidth(), sh = bmp.getHeight();
            int cropH = (int) (sw * (fr.height() / fr.width()));
            Rect srcR = new Rect(0, Math.max(0, sh / 12), sw, Math.min(sh, Math.max(0, sh / 12) + cropH));
            if (stage == 3) {
                // peeking out of its frame, bobbing a little
                float bob = (float) Math.sin(now / 420.0) * 5f;
                float big = 1.5f;
                float bw = fr.width() * big, bh = bw * sh / sw;
                RectF d = new RectF(fr.centerX() - bw / 2f, fr.bottom - bh * 0.78f + bob, fr.centerX() + bw / 2f, fr.bottom + bh * 0.22f + bob);
                p.setColor(0xFF2A2118);
                c.drawRoundRect(fr, 16f, 16f, p);
                c.drawBitmap(bmp, null, d, bmpPaint);
            } else {
                Path clip = new Path();
                clip.addRoundRect(fr, 16f, 16f, Path.Direction.CW);
                c.save();
                c.clipPath(clip);
                c.drawBitmap(bmp, srcR, fr, bmpPaint);
                c.restore();
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(stage >= 2 ? 6f : 4f);
            p.setColor(stage >= 2 ? red : inkC);
            c.drawRoundRect(fr, 16f, 16f, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    // ---------- shelves ----------

    private int indexOf(String key) {
        for (int i = 0; i < KEYS.length; i++) if (KEYS[i].equals(key)) return i;
        return -1;
    }

    /** All launchable apps on the phone, sorted by name. */
    List<AppRef> installed() {
        if (installedCache != null) return installedCache;
        List<AppRef> out = new ArrayList<AppRef>();
        try {
            PackageManager pm = getContext().getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo r : pm.queryIntentActivities(main, 0)) {
                if (r.activityInfo == null) continue;
                if (getContext().getPackageName().equals(r.activityInfo.packageName)) continue;
                AppRef a = new AppRef();
                a.label = String.valueOf(r.loadLabel(pm));
                a.cn = new ComponentName(r.activityInfo.packageName, r.activityInfo.name);
                out.add(a);
            }
        } catch (Throwable ignored) { }
        Collections.sort(out, new Comparator<AppRef>() {
            @Override
            public int compare(AppRef x, AppRef y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });
        installedCache = out;
        return out;
    }

    /** The apps the user chose for this object, or (until they choose) the installed ones that match its theme. */
    List<AppRef> shelf(String key) {
        List<AppRef> cached = shelfCache.get(key);
        if (cached != null) return cached;
        List<AppRef> out = new ArrayList<AppRef>();
        List<AppRef> all = installed();
        String saved = prefs.getString("room_" + key, null);
        if (saved != null) {
            for (String part : saved.split("\\|")) {
                if (part.length() == 0) continue;
                ComponentName cn = ComponentName.unflattenFromString(part);
                if (cn == null) continue;
                for (AppRef a : all) {
                    if (a.cn.equals(cn)) {
                        out.add(a);
                        break;
                    }
                }
            }
        } else {
            int i = indexOf(key);
            if (i >= 0) {
                for (String w : WORDS[i]) {
                    for (AppRef a : all) {
                        String lb = a.label.toLowerCase(Locale.ROOT);
                        if (lb.contains(w) && !out.contains(a)) out.add(a);
                        if (out.size() >= 8) break;
                    }
                    if (out.size() >= 8) break;
                }
            }
        }
        shelfCache.put(key, out);
        return out;
    }

    static String savedList(List<AppRef> chosen) {
        StringBuilder sb = new StringBuilder();
        for (AppRef a : chosen) {
            if (sb.length() > 0) sb.append('|');
            sb.append(a.cn.flattenToString());
        }
        return sb.toString();
    }

    private Bitmap iconFor(AppRef a) {
        int accent = src.skyAccent();
        String ck = a.cn.flattenToString() + "#" + accent;
        Bitmap b = icons.get(ck);
        if (b != null) return b;
        try {
            Drawable d = getContext().getPackageManager().getActivityIcon(a.cn);
            b = IconStyler.tinted(d, accent, a.label, bebas);
        } catch (Throwable t) {
            b = null;
        }
        if (b == null) {
            try {
                b = IconStyler.letterTinted(a.label, accent, bebas);
            } catch (Throwable ignored) { }
        }
        if (b != null) icons.put(ck, b);
        return b;
    }

    // ---------- pop-ups (drawn on the screen, in dp) ----------

    private RectF screenRect(float[] r) {
        return new RectF(offX + r[0] * scale, offY + r[1] * scale, offX + r[2] * scale, offY + r[3] * scale);
    }

    private void layoutShelf(int w, int availH) {
        int idx = indexOf(openKey);
        if (idx < 0) return;
        RectF o = screenRect(HOTS[idx]);
        int n = Math.max(1, openApps.size());
        int cols = Math.min(4, n);
        int rows = (n + 3) / 4;
        float cell = 74f * dp, pad = 12f * dp;
        float pw = Math.max(cols * cell + pad * 2f, openApps.isEmpty() ? 220f * dp : 0f);
        pw = Math.min(pw, w - 16f * dp);
        float ph = rows * (cell + 6f * dp) + pad * 2f - 6f * dp + (openApps.isEmpty() ? 14f * dp : 0f);
        float gap = 12f * dp;
        float cx = (o.left + o.right) / 2f;
        cardBelow = o.bottom + gap + ph + 6f * dp <= availH;
        float t = cardBelow ? o.bottom + gap : Math.max(6f * dp, o.top - gap - ph);
        float l = clamp(cx - pw / 2f, 8f * dp, w - pw - 8f * dp);
        card.set(l, t, l + pw, t + ph);
        arrowX = clamp(cx, l + 26f * dp, l + pw - 26f * dp);
        closeBtn.set(card.right - 30f * dp, card.top + 2f * dp, card.right - 2f * dp, card.top + 30f * dp);
        cellRects.clear();
        float gx = card.left + (pw - cols * cell) / 2f;
        for (int i = 0; i < openApps.size(); i++) {
            int rI = i / 4, cI = i % 4;
            float x = gx + cI * cell, y = card.top + pad + rI * (cell + 6f * dp);
            cellRects.add(new RectF(x, y, x + cell, y + cell));
        }
    }

    private void drawPopups(Canvas c, int w, int availH, float k) {
        p.setShader(null);
        p.setTypeface(roboto);
        p.setLetterSpacing(0f);
        if (openKey != null) {
            layoutShelf(w, availH);
            float anim = clamp((SystemClock.uptimeMillis() - popupAt) / 160f, 0f, 1f);
            float sc = 0.86f + 0.14f * anim;
            c.save();
            c.scale(sc, sc, arrowX, cardBelow ? card.top : card.bottom);
            c.save();
            p.setAlpha((int) (255 * anim));
            int paper = k > 0.5f ? 0xFFE9DDC2 : 0xFFF5EBD3, inkC = 0xFF2A2118;
            // soft shadow
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb((int) (70 * anim), 0, 0, 0));
            c.drawRoundRect(new RectF(card.left + 3f * dp, card.top + 4f * dp, card.right + 3f * dp, card.bottom + 4f * dp), 18f * dp, 18f * dp, p);
            p.setColor(paper);
            p.setAlpha((int) (255 * anim));
            c.drawRoundRect(card, 18f * dp, 18f * dp, p);
            Path ar = new Path();
            float ah = 11f * dp, aw = 12f * dp;
            if (cardBelow) {
                ar.moveTo(arrowX - aw, card.top + 1f);
                ar.lineTo(arrowX, card.top - ah);
                ar.lineTo(arrowX + aw, card.top + 1f);
            } else {
                ar.moveTo(arrowX - aw, card.bottom - 1f);
                ar.lineTo(arrowX, card.bottom + ah);
                ar.lineTo(arrowX + aw, card.bottom - 1f);
            }
            ar.close();
            c.drawPath(ar, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.4f * dp);
            p.setColor(inkC);
            p.setAlpha((int) (255 * anim));
            c.drawRoundRect(card, 18f * dp, 18f * dp, p);
            // the arrow's outline continues the card's, without a line across its base
            Path ao = new Path();
            if (cardBelow) {
                ao.moveTo(arrowX - aw, card.top);
                ao.lineTo(arrowX, card.top - ah);
                ao.lineTo(arrowX + aw, card.top);
            } else {
                ao.moveTo(arrowX - aw, card.bottom);
                ao.lineTo(arrowX, card.bottom + ah);
                ao.lineTo(arrowX + aw, card.bottom);
            }
            c.drawPath(ao, p);
            p.setStyle(Paint.Style.FILL);
            p.setAlpha(255);
            // close button
            p.setColor(inkC);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.4f * dp);
            float cx = closeBtn.centerX(), cy = closeBtn.centerY(), r = 5.5f * dp;
            c.drawLine(cx - r, cy - r, cx + r, cy + r, p);
            c.drawLine(cx - r, cy + r, cx + r, cy - r, p);
            p.setStyle(Paint.Style.FILL);
            if (openApps.isEmpty()) {
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(12f * dp);
                p.setColor(inkC);
                c.drawText("NO APPS HERE YET", card.centerX(), card.centerY() - 2f * dp, p);
                p.setTextSize(10.5f * dp);
                p.setColor(0xFF6B5A44);
                c.drawText("HOLD THE OBJECT TO ADD SOME", card.centerX(), card.centerY() + 14f * dp, p);
            }
            for (int i = 0; i < openApps.size() && i < cellRects.size(); i++) {
                RectF cr = cellRects.get(i);
                Bitmap ic = iconFor(openApps.get(i));
                float is = 50f * dp;
                if (ic != null) {
                    RectF d = new RectF(cr.centerX() - is / 2f, cr.top + 2f * dp, cr.centerX() + is / 2f, cr.top + 2f * dp + is);
                    c.drawBitmap(ic, null, d, bmpPaint);
                }
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(10f * dp);
                p.setColor(inkC);
                String lb = openApps.get(i).label;
                while (lb.length() > 3 && p.measureText(lb) > cr.width() - 4f * dp) lb = lb.substring(0, lb.length() - 1);
                if (lb.length() < openApps.get(i).label.length()) lb = lb.trim() + "…";
                c.drawText(lb, cr.centerX(), cr.bottom - 3f * dp, p);
            }
            c.restore();
            c.restore();
        }
        if (restOpen) {
            float cw = Math.min(w - 32f * dp, 300f * dp), chh = 128f * dp;
            float l = (w - cw) / 2f, t = 120f * scale + 6f * dp;
            restCard.set(l, t, l + cw, t + chh);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(70, 0, 0, 0));
            c.drawRoundRect(new RectF(l + 3f * dp, t + 4f * dp, l + cw + 3f * dp, t + chh + 4f * dp), 18f * dp, 18f * dp, p);
            p.setColor(0xFFF5EBD3);
            c.drawRoundRect(restCard, 18f * dp, 18f * dp, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.4f * dp);
            p.setColor(0xFF2A2118);
            c.drawRoundRect(restCard, 18f * dp, 18f * dp, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(bebas);
            p.setTextSize(26f * dp);
            c.drawText("LOOK 20 FEET AWAY", restCard.centerX(), restCard.top + 36f * dp, p);
            p.setTypeface(roboto);
            p.setTextSize(11.5f * dp);
            p.setColor(0xFF6B5A44);
            c.drawText("FOR 20 SECONDS, THEN TAP BELOW", restCard.centerX(), restCard.top + 56f * dp, p);
            restBtn.set(restCard.centerX() - 80f * dp, restCard.bottom - 50f * dp, restCard.centerX() + 80f * dp, restCard.bottom - 14f * dp);
            p.setColor(0xFFC8420F);
            c.drawRoundRect(restBtn, 10f * dp, 10f * dp, p);
            p.setColor(0xFFFFF4E0);
            p.setTypeface(bebas);
            p.setTextSize(22f * dp);
            c.drawText("I RESTED", restBtn.centerX(), restBtn.centerY() + 7f * dp, p);
        }
    }

    // ---------- touch ----------

    private String hotAt(float x, float y) {
        for (int i = 0; i < KEYS.length; i++) {
            if (screenRect(HOTS[i]).contains(x, y)) return KEYS[i];
        }
        return null;
    }

    private void openShelf(String key) {
        restOpen = false;
        openKey = key;
        openApps = shelf(key);
        popupAt = SystemClock.uptimeMillis();
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                downTime = SystemClock.uptimeMillis();
                longFired = false;
                downKey = hotAt(downX, downY);
                if (openKey != null && card.contains(downX, downY)) downKey = null;
                handler.removeCallbacks(longPress);
                if (downKey != null && !restOpen) handler.postDelayed(longPress, 600);
                return true;
            case MotionEvent.ACTION_MOVE: {
                float mx = e.getX() - downX, my = e.getY() - downY;
                if (mx * mx + my * my > (float) touchSlop * touchSlop * 2.5f) handler.removeCallbacks(longPress);
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                return true;
            case MotionEvent.ACTION_UP: {
                handler.removeCallbacks(longPress);
                if (longFired) return true;
                float dx = e.getX() - downX, dy = e.getY() - downY;
                if (dx > touchSlop * 5f && Math.abs(dx) > Math.abs(dy) * 1.4f) {
                    closePopups();
                    if (host != null) host.closeRoom();
                } else if (dy < -touchSlop * 4f && Math.abs(dy) > Math.abs(dx)) {
                    closePopups();
                    if (host != null) host.openDrawer();
                } else if (dy > touchSlop * 4f && Math.abs(dy) > Math.abs(dx) * 1.2f) {
                    closePopups();
                    if (host != null) host.openNotifications();
                } else if (dx * dx + dy * dy <= (float) touchSlop * touchSlop && SystemClock.uptimeMillis() - downTime < 600) {
                    tap(e.getX(), e.getY());
                }
                return true;
            }
            default:
                return true;
        }
    }

    private void tap(float x, float y) {
        if (restOpen) {
            if (restBtn.contains(x, y)) {
                EyeReminder.rested(getContext());
                restOpen = false;
            } else if (!restCard.contains(x, y)) {
                restOpen = false;
            }
            invalidate();
            return;
        }
        if (openKey != null) {
            if (closeBtn.contains(x, y)) {
                openKey = null;
            } else if (card.contains(x, y)) {
                for (int i = 0; i < cellRects.size() && i < openApps.size(); i++) {
                    if (cellRects.get(i).contains(x, y)) {
                        launch(openApps.get(i).cn);
                        openKey = null;
                        break;
                    }
                }
            } else {
                String k = hotAt(x, y);
                if (k != null && !k.equals(openKey)) {
                    openShelf(k);
                    return;
                }
                openKey = null;
            }
            invalidate();
            return;
        }
        // the cream strip: time since the last rest, with a button to say you rested
        RectF strip = new RectF(offX, 0f, offX + IW * scale, 112f * scale);
        if (strip.contains(x, y)) {
            restOpen = true;
            invalidate();
            return;
        }
        String k = hotAt(x, y);
        if (k != null) openShelf(k);
    }

    private void launch(ComponentName cn) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(cn);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }
}
