package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * The engraved string lights for page 1 (assets p1_h0..9 off / on, bulb positions in p1_pts.txt):
 * 0 filament bulbs, 1 and 2 stars, 3 hearts, 4 moons, 5 lanterns, 6 flowers, 7 jars, 8 globe bulbs, 9 teardrop bulbs.
 */
final class StringLights {
    static final int FILAMENT = 0, STAR_A = 1, STAR_B = 2, HEART = 3, MOON = 4, LANTERN = 5, FLOWER = 6, JAR = 7, GLOBE = 8, DROP = 9;
    private static final Bitmap[][] B = new Bitmap[10][2];
    private static float[][][] pts;
    private static final Paint BP = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private static final Paint GP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final RectF R = new RectF();
    private static final int[] TRI = {0xFFFF9933, 0xFFFFFFFF, 0xFF3CDC5A};

    private StringLights() { }

    private static Bitmap bmp(Context ctx, int k, int on) {
        if (B[k][on] == null) {
            try (InputStream in = ctx.getAssets().open("p1_h" + k + (on == 1 ? "_on" : "_off") + ".webp")) {
                B[k][on] = BitmapFactory.decodeStream(in);
            } catch (Throwable ignored) { }
        }
        return B[k][on];
    }

    private static void loadPts(Context ctx) {
        if (pts != null) return;
        float[][][] p = new float[10][][];
        try (BufferedReader br = new BufferedReader(new InputStreamReader(ctx.getAssets().open("p1_pts.txt")))) {
            String ln;
            while ((ln = br.readLine()) != null) {
                String[] t = ln.trim().split(" ");
                if (t.length < 3) continue;
                int k = t[0].charAt(1) - '0';
                float[][] q = new float[t.length - 3][2];
                for (int i = 3; i < t.length; i++) {
                    String[] xy = t[i].split(",");
                    q[i - 3][0] = Float.parseFloat(xy[0]);
                    q[i - 3][1] = Float.parseFloat(xy[1]);
                }
                p[k] = q;
            }
        } catch (Throwable ignored) { }
        pts = p;
    }

    private static void glow(Canvas c, float x, float y, float r, int rgb, float a) {
        int col = Color.argb((int) (255 * Math.max(0f, Math.min(1f, a))), Color.red(rgb), Color.green(rgb), Color.blue(rgb));
        GP.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
        GP.setShader(new RadialGradient(x, y, r, new int[]{col, Color.argb((int) (Color.alpha(col) * 0.35f), Color.red(rgb), Color.green(rgb), Color.blue(rgb)), 0},
                new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, GP);
        GP.setShader(null);
        GP.setXfermode(null);
    }

    /**
     * Hangs string k between (ax,ay) and (bx,by). lit 0..1 fades the lit picture and the glows in; tri = 1 gives
     * saffron / white / green lights; dim 0..1 darkens the unlit picture (the scene is darker at night).
     */
    static void draw(Canvas c, Context ctx, int k, float ax, float ay, float bx, float by, float lit, int tri, float dim, long now) {
        Bitmap off = bmp(ctx, k, 0);
        loadPts(ctx);
        if (off == null || pts[k] == null) return;
        float len = (float) Math.hypot(bx - ax, by - ay);
        float ang = (float) Math.toDegrees(Math.atan2(by - ay, bx - ax));
        float h = len * off.getHeight() / off.getWidth();
        c.save();
        c.translate(ax, ay);
        c.rotate(ang);
        R.set(0f, 0f, len, h);
        BP.setAlpha(255);
        BP.setColorFilter(dim > 0.01f ? new android.graphics.LightingColorFilter(
                Color.rgb((int) (255 - 110 * dim), (int) (255 - 110 * dim), (int) (255 - 80 * dim)), 0) : null);
        c.drawBitmap(off, null, R, BP);
        BP.setColorFilter(null);
        if (lit > 0.01f) {
            Bitmap on = bmp(ctx, k, 1);
            if (on != null) {
                BP.setAlpha((int) (255 * Math.min(1f, lit * (tri == 1 ? 0.5f : 1f))));
                c.drawBitmap(on, null, R, BP);
                BP.setAlpha(255);
            }
            float[][] q = pts[k];
            float gr = Math.max(5f, h * 0.55f);
            for (int i = 0; i < q.length; i++) {
                float x = q[i][0] * len, y = q[i][1] * h;
                float tw = 0.72f + 0.28f * (float) Math.sin(now / 330.0 + i * 1.9);
                if (tri == 1) {
                    glow(c, x, y, gr, TRI[(i + (int) (now / 900L)) % 3], 0.85f * lit * tw);
                } else {
                    glow(c, x, y, gr, 0xFFFFD890, 0.5f * lit * tw);
                }
                glow(c, x, y, gr * 0.3f, 0xFFFFFFFF, 0.5f * lit * tw);
            }
        }
        c.restore();
    }
}
