package com.horizon.launcher;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

/**
 * The colour of the whole screen at one moment. Four colours (top, mid, horizon, deep) are mixed from
 * the palette's day, twilight and night sets according to the time against sunrise and sunset and the cloud cover.
 * It also decides whether text at a given height should be dark or light so it always reads.
 */
final class Sky {

    static final int INK = Color.parseColor("#1B1B1A");
    static final int LIGHT = Color.parseColor("#F4F1EA");
    static final int CREAM = Color.parseColor("#ECE3D0");

    /** Heights (design units) of the four colour stops when the sky fills the whole screen. */
    static final float[] YS_FULL = {0f, 230f, 397f, 804f};
    /** Heights of the stops when the sky only fills the scene box (classic look). */
    static final float[] YS_BOX = {241f, 300f, 397f, 478f};

    final Palette pal;
    final int[] cols = new int[4];
    final float[] ys;
    float nightK = 0f;   // 0 = day, 1 = deep night
    float twiW = 0f;     // 1 = right at sunrise / sunset
    boolean day = true;
    final int[] palCols = new int[4];   // the day's own palette colours, before the sky pictures
    float[] art;   // weights of the painted sky layers (bleeding palettes only)

    private Sky(Palette pal) {
        this.pal = pal;
        this.ys = pal.bleed ? YS_FULL : YS_BOX;
    }

    static int blend(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    static float lum(int c) {
        return (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f;
    }

    static Sky compute(Palette pal, int nowMin, int sr, int ss, float cloud) {
        Sky s = new Sky(pal);
        s.day = nowMin >= sr && nowMin <= ss;
        float d = nowMin - sr, e = ss - nowMin;
        float tw;
        if (s.day) {
            float w = Math.min(d, e);
            tw = Math.max(0f, Math.min(1f, 1f - w / 60f));
            s.nightK = 0f;
            for (int i = 0; i < 4; i++) s.cols[i] = blend(pal.day[i], pal.twi[i], tw);
            s.twiW = tw;
        } else {
            float m = d < 0 ? -d : -e;
            s.nightK = Math.max(0f, Math.min(1f, m / 45f));
            for (int i = 0; i < 4; i++) s.cols[i] = blend(pal.twi[i], pal.night[i], s.nightK);
            s.twiW = 1f - s.nightK;
        }
        // Make the sky at the top and the water at the bottom clearly visible by day: the two ends
        // lean toward the palette's deeper twilight colours while the middle stays light.
        if (pal.bleed) {
            float k = 0.62f * (1f - s.nightK);
            s.cols[0] = blend(s.cols[0], pal.twi[0], k);
            s.cols[3] = blend(s.cols[3], pal.twi[3], k * 0.78f);
            s.cols[1] = blend(s.cols[1], pal.twi[0], k * 0.18f);
        }
        if (pal.bleed && SkyArt.enabled) {
            System.arraycopy(s.cols, 0, s.palCols, 0, 4);
            s.art = SkyArt.weights(s.nightK, s.twiW, nowMin, cloud);
            int[] m = SkyArt.mix(s.art);
            for (int i = 0; i < 3; i++) s.cols[i] = m[i];
            return s;
        }
        if (cloud > 0f) {
            int dim = blend(Color.parseColor("#BBB5A8"), Color.parseColor("#14171F"), s.nightK);
            for (int i = 0; i < 4; i++) s.cols[i] = blend(s.cols[i], dim, cloud * 0.35f);
        }
        return s;
    }

    /** Sky colour at a height in design units. */
    int colorAt(float y) {
        if (y <= ys[0]) return cols[0];
        for (int i = 1; i < 4; i++) {
            if (y <= ys[i]) {
                float t = (y - ys[i - 1]) / (ys[i] - ys[i - 1]);
                return blend(cols[i - 1], cols[i], t);
            }
        }
        return cols[3];
    }

    /** Text / line colour that reads on whatever is behind it at this height. */
    int fgAt(float y) {
        if (!pal.bleed && (y < YS_BOX[0] - 2f || y > YS_BOX[3] + 2f)) return INK;
        // Always one of the two real text colours, never a grey in between: whichever reads better on the sky here.
        int bg = colorAt(y);
        float lb = relLum(bg);
        float cInk = (lb + 0.05f) / (relLum(INK) + 0.05f);
        float cLight = (relLum(LIGHT) + 0.05f) / (lb + 0.05f);
        return cInk >= cLight * 0.92f ? INK : LIGHT;
    }

    /** WCAG relative luminance, 0 (black) to 1 (white). */
    static float relLum(int c) {
        float r = lin(Color.red(c) / 255f), g = lin(Color.green(c) / 255f), b = lin(Color.blue(c) / 255f);
        return 0.2126f * r + 0.7152f * g + 0.0722f * b;
    }

    private static float lin(float v) {
        return v <= 0.03928f ? v / 12.92f : (float) Math.pow((v + 0.055f) / 1.055f, 2.4f);
    }

    /** True when text at this height is drawn light. */
    boolean darkAt(float y) {
        return lum(fgAt(y)) > 0.5f;
    }

    /** The red accent, lifted a little at night so it still glows. */
    int accent() {
        return blend(pal.accent, Color.WHITE, 0.2f * nightK);
    }

    /** The mid colour, used for window background while the app starts. */
    int mid() {
        return cols[1];
    }

    /**
     * Paints the sky behind everything. With a bleeding palette it fills the whole visible area; with the classic
     * look it paints a cream page and a sky only inside the scene box. A soft glow sits under the sun or moon.
     */
    void drawBackdrop(Canvas c, Paint p, float vx0, float vy0, float vx1, float vy1,
                      float boxL, float boxT, float boxR, float boxB, float bodyX, float horizonY) {
        p.setStyle(Paint.Style.FILL);
        p.setAlpha(255);
        if (pal.bleed) {
            float[] pos = {ys[0] / 804f, ys[1] / 804f, ys[2] / 804f, ys[3] / 804f};
            p.setShader(new LinearGradient(0f, 0f, 0f, 804f, cols, pos, Shader.TileMode.CLAMP));
            c.drawRect(vx0, vy0, vx1, vy1, p);
            p.setShader(null);
            if (art != null) {
                SkyArt.draw(c, p, art, vx0, vy0, vx1, horizonY + 6f);
            }
            int base = blend(Color.parseColor("#FFF1D0"), Color.parseColor("#5B6B96"), nightK);
            int a = (int) (26 + 70 * twiW + 34 * nightK);
            int inner = Color.argb(Math.min(110, a), Color.red(base), Color.green(base), Color.blue(base));
            int outer = Color.argb(0, Color.red(base), Color.green(base), Color.blue(base));
            p.setShader(new RadialGradient(bodyX, horizonY, 300f, inner, outer, Shader.TileMode.CLAMP));
            c.drawRect(vx0, vy0, vx1, vy1, p);
            p.setShader(null);
        } else {
            p.setColor(CREAM);
            c.drawRect(vx0, vy0, vx1, vy1, p);
            float h = boxB - boxT;
            float[] pos = {(ys[0] - YS_BOX[0]) / (YS_BOX[3] - YS_BOX[0]), (ys[1] - YS_BOX[0]) / (YS_BOX[3] - YS_BOX[0]),
                    (ys[2] - YS_BOX[0]) / (YS_BOX[3] - YS_BOX[0]), 1f};
            // by day the sky box melts into the cream page: no visible rectangle (it darkens only towards night)
            float melt = 0.9f * (1f - nightK);
            int[] bc = new int[4];
            for (int i = 0; i < 4; i++) bc[i] = blend(cols[i], CREAM, melt);
            p.setShader(new LinearGradient(0f, boxT, 0f, boxB, bc, pos, Shader.TileMode.CLAMP));
            c.drawRect(boxL, boxT, boxR, boxB, p);
            p.setShader(null);
        }
    }
}
