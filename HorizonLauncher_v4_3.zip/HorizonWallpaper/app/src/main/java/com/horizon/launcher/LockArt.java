package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.io.File;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

/**
 * Draws the lock screen picture and the plain home wallpaper in the same colours as the home screen.
 * The top-left is left empty on purpose: that is where the phone puts its own clock.
 */
final class LockArt {

    private LockArt() { }

    /** How much the phone enlarges the lock-screen wallpaper (measured from a screenshot: about 1.10). */
    static final float LOCK_ZOOM = 1.10f;

    private static final float SCENE_T = 300f;
    private static final float SCENE_H = 236f;
    private static final float LAKE = SCENE_T + SCENE_H * 0.66f;

    /** 0 = day, 1 = twilight, 2 = night: the lock picture is refreshed when this changes. */
    static int bucket(int nowMin, int sr, int ss) {
        if (nowMin < sr - 30 || nowMin > ss + 60) return 2;
        if ((nowMin >= sr - 30 && nowMin <= sr + 45) || (nowMin >= ss - 45 && nowMin <= ss + 60)) return 1;
        return 0;
    }

    static String key(Look look, int bucket) {
        return look.key + "|b" + bucket + "|z" + LOCK_ZOOM;
    }

    private static Bitmap scene(Context ctx, Look look) {
        Bitmap b = null;
        try {
            File f = look.pack.sceneFile(look.sceneId);
            if (f != null && f.isFile()) b = BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Throwable ignored) { }
        if (b == null) {
            try {
                InputStream in = ctx.getAssets().open("scene_" + look.sceneId + ".webp");
                b = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Throwable ignored) { }
        }
        if (b == null) {
            try {
                InputStream in = ctx.getAssets().open("scene_lake.webp");
                b = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Throwable ignored) { }
        }
        return b;
    }

    /** A plain gradient in the current sky colours, used behind the launcher. */
    static Bitmap plain(Sky sky, int w, int h) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float[] pos = {0f, 0.286f, 0.494f, 1f};
        p.setShader(new LinearGradient(0f, 0f, 0f, h, sky.cols, pos, Shader.TileMode.CLAMP));
        c.drawRect(0f, 0f, w, h, p);
        return bmp;
    }

    static Bitmap lock(Context ctx, Look look, Sky sky, int nowMin, int sr, int ss, float cloud, int w, int h) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Typeface bebas, roboto;
        try {
            bebas = Typeface.createFromAsset(ctx.getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(ctx.getAssets(), "Roboto-Regular.ttf");
        } catch (Exception e) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }
        Palette pal = look.pal;
        float scale = w / 360f;
        float offY = (h - 804f * scale) / 2f;
        c.save();
        c.translate(0f, offY);
        c.scale(scale, scale);
        float vy0 = -offY / scale, vy1 = (h - offY) / scale;
        // The phone enlarges the lock-screen wallpaper by about 10%, which pushed the frame and texts off the
        // edges. Draw the layout slightly smaller so that it lands exactly on the screen after that zoom.
        final float z = 1f / LOCK_ZOOM;
        c.translate(180f, 402f);
        c.scale(z, z);
        c.translate(-180f, -402f);
        float vx0 = 180f - 180f / z, vx1 = 180f + 180f / z;
        vy0 = 402f + (vy0 - 402f) / z;
        vy1 = 402f + (vy1 - 402f) / z;

        // sun or moon position on the same arc as the home screen
        boolean day = nowMin >= sr && nowMin <= ss;
        float bx, by, br;
        if (day) {
            float t = (nowMin - sr) / (float) Math.max(1, ss - sr);
            bx = 40f + t * 270f;
            by = (LAKE + 24f) - (float) Math.sin(Math.PI * t) * ((LAKE + 24f) - (SCENE_T + 51f));
            br = 33f;
        } else {
            int len = 1440 - (ss - sr);
            int m2 = nowMin >= ss ? nowMin - ss : nowMin + 1440 - ss;
            float t = m2 / (float) Math.max(1, len);
            bx = 40f + t * 270f;
            by = (LAKE + 22f) - (float) Math.sin(Math.PI * t) * ((LAKE + 22f) - (SCENE_T + 47f));
            br = 24f;
        }

        sky.drawBackdrop(c, p, vx0, vy0, vx1, vy1, 9.5f, SCENE_T, 350.5f, SCENE_T + SCENE_H, bx, LAKE);

        // stars
        if (sky.nightK > 0.15f) {
            Random r = new Random(11);
            p.setColor(Color.parseColor("#EDE6D3"));
            p.setAlpha((int) (255 * sky.nightK * (1f - cloud * 0.8f)));
            for (int i = 0; i < 70; i++) {
                float x = 4f + r.nextFloat() * 352f, y = 8f + r.nextFloat() * 370f, rad = 0.5f + r.nextFloat() * 0.9f;
                if (y < LAKE - 14f && y > 250f) c.drawCircle(x, y, rad, p);
            }
            p.setAlpha(255);
        }
        // sun / moon
        if (day) {
            p.setColor(sky.accent());
            p.setAlpha((int) (255 * (1f - 0.55f * cloud)));
            c.drawCircle(bx, by, br, p);
            p.setAlpha(255);
        } else {
            double phase = Texts.moonPhase(System.currentTimeMillis());
            float f = (float) ((1.0 - Math.cos(2.0 * Math.PI * phase)) / 2.0);
            float dd = 2f * br * f;
            p.setColor(Color.parseColor("#EDE6D3"));
            c.drawCircle(bx, by, br, p);
            p.setColor(sky.colorAt(by));
            c.drawCircle(phase < 0.5 ? bx - dd : bx + dd, by, br + 0.5f, p);
        }
        try {
            Decor.sky(c, p, sky, look.fest == null ? null : look.fest.decor, SCENE_T, LAKE, System.currentTimeMillis());
        } catch (Exception ignored) { }

        // scene
        Bitmap sb = scene(ctx, look);
        RectF dst = new RectF(9.5f, SCENE_T, 350.5f, SCENE_T + SCENE_H);
        if (sb != null) {
            float a = 1f - 0.55f * sky.nightK - 0.2f * cloud;
            float[] tint = pal.tint;
            ColorMatrix cm = new ColorMatrix(new float[]{
                    a * tint[0], 0, 0, 0, 0,
                    0, a * tint[1], 0, 0, 0,
                    0, 0, a * tint[2], 0, 16f * sky.nightK,
                    0, 0, 0, 1, 0});
            Paint lp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
            lp.setColorFilter(new ColorMatrixColorFilter(cm));
            int save = c.saveLayer(dst, null);
            c.drawBitmap(sb, null, dst, lp);
            c.restoreToCount(save);
            if (pal.bleed) WaterExt.draw(c, sb, lp, dst.left, dst.right, dst.bottom, 56f, sky.nightK, 0xFFF1E9D8);
        }
        try {
            Decor.front(c, p, sky, look.fest == null ? null : look.fest.decor, LAKE, System.currentTimeMillis());
        } catch (Exception ignored) { }

        // frame lines
        float L = 8f, R = 352f;
        line(c, p, sky, L, R, 28f, true, 1.5f);
        line(c, p, sky, L, R, 790f, true, 1.5f);
        line(c, p, sky, L, R, 248f, true, 1.5f);
        vline(c, p, sky, L, 28f, 790f, 1.5f);
        vline(c, p, sky, R, 28f, 790f, 1.5f);
        vline(c, p, sky, 240f, 28f, 248f, 1.5f);

        // HORIZON (vertical) and slogans: the clock area on the left stays empty
        String word = "HORIZON";
        float size = 74f;
        p.setTypeface(bebas);
        p.setLetterSpacing(0.02f);
        p.setTextSize(size);
        float wd = p.measureText(word);
        if (wd > 188f) size = size * 188f / wd;   // keeps the top clear of the phone's status icons
        float cap = size * 0.70f;
        c.save();
        c.translate(270f + cap / 2f, 240f);
        c.rotate(-90f);
        txt(c, p, word, 0f, 0f, size, sky.fgAt(130f), bebas, Paint.Align.LEFT, 0.02f);
        c.restore();
        blockUp(c, p, sky, look.slogan1, 304f, 79f, 7.4f, 5.6f, roboto, 42f);
        p.setColor(sky.accent());
        p.setStyle(Paint.Style.FILL);
        c.drawRect(304f, 86f, 324f, 88f, p);
        blockUp(c, p, sky, look.slogan2, 304f, 189f, 8f, 5.6f, roboto, 42f);
        p.setColor(sky.accent());
        c.drawRect(304f, 196f, 324f, 198f, p);

        // scene corner messages
        block(c, p, sky, look.cornerL, 18f, 266f, 9f, 6.2f, roboto, 100f);
        blockRight(c, p, sky, look.cornerR, 344f, 266f, 9f, 6.2f, roboto, 120f);

        // message at the bottom, kept clear of the torch and camera buttons
        String[] two = splitTwo(look.tagline);
        float ts = 24f;
        p.setTypeface(bebas);
        p.setLetterSpacing(0.03f);
        for (String ln : two) {
            p.setTextSize(ts);
            float lw = p.measureText(ln);
            if (lw > 176f) ts = Math.max(12f, ts * 176f / lw);
        }
        for (int i = 0; i < two.length; i++) {
            txt(c, p, two[i], 180f, 742f + i * (ts + 3f), ts, sky.fgAt(750f), bebas, Paint.Align.CENTER, 0.03f);
        }
        c.restore();
        return bmp;
    }

    private static String[] splitTwo(String s) {
        String[] words = s.trim().split("\\s+");
        if (words.length < 3) return new String[]{s};
        int total = s.length(), run = 0, cut = words.length / 2;
        for (int i = 0; i < words.length; i++) {
            run += words[i].length() + 1;
            if (run >= total / 2) {
                cut = i + 1;
                break;
            }
        }
        if (cut >= words.length) cut = words.length - 1;
        StringBuilder a = new StringBuilder(), b = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            StringBuilder t = i < cut ? a : b;
            if (t.length() > 0) t.append(' ');
            t.append(words[i]);
        }
        return new String[]{a.toString(), b.toString()};
    }

    private static void txt(Canvas c, Paint p, String t, float x, float y, float size, int color,
                            Typeface tf, Paint.Align al, float sp) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(tf);
        p.setTextSize(size);
        p.setColor(color);
        p.setTextAlign(al);
        p.setLetterSpacing(sp);
        c.drawText(t, x, y, p);
    }

    private static void block(Canvas c, Paint p, Sky sky, String pooled, float x, float y, float gap, float size,
                              Typeface tf, float maxW) {
        String[] lines = pooled.split("\\|");
        p.setTypeface(tf);
        p.setLetterSpacing(0.3f);
        float s = size;
        for (String ln : lines) {
            p.setTextSize(size);
            float w = p.measureText(ln);
            if (w > maxW) s = Math.min(s, Math.max(4f, size * maxW / w));
        }
        for (int i = 0; i < lines.length; i++) {
            txt(c, p, lines[i].trim(), x, y + i * gap, s, sky.fgAt(y + i * gap), tf, Paint.Align.LEFT, 0.3f);
        }
    }

    /** Like block(), but the LAST line sits on lastBase, so the text hugs the red rule below it. */
    private static void blockUp(Canvas c, Paint p, Sky sky, String pooled, float x, float lastBase, float gap,
                                float size, Typeface tf, float maxW) {
        int n = pooled.split("\\|").length;
        block(c, p, sky, pooled, x, lastBase - (n - 1) * gap, gap, size, tf, maxW);
    }

    private static void blockRight(Canvas c, Paint p, Sky sky, String pooled, float x, float y, float gap, float size,
                                   Typeface tf, float maxW) {
        String[] lines = pooled.split("\\|");
        p.setTypeface(tf);
        p.setLetterSpacing(0.4f);
        float s = size;
        for (String ln : lines) {
            p.setTextSize(size);
            float w = p.measureText(ln);
            if (w > maxW) s = Math.min(s, Math.max(4f, size * maxW / w));
        }
        for (int i = 0; i < lines.length; i++) {
            txt(c, p, lines[i].trim(), x, y + i * gap, s, sky.fgAt(y + i * gap), tf, Paint.Align.RIGHT, 0.4f);
        }
    }

    private static void line(Canvas c, Paint p, Sky sky, float x0, float x1, float y, boolean horizontal, float w) {
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
        p.setColor(sky.fgAt(y));
        c.drawLine(x0, y, x1, y, p);
    }

    private static void vline(Canvas c, Paint p, Sky sky, float x, float y0, float y1, float w) {
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
        p.setColor(sky.fgAt((y0 + y1) / 2f));
        c.drawLine(x, y0, x, y1, p);
    }

    /** Small convenience for the caller: the calendar minute of the day. */
    static int minuteOfDay() {
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
    }

    static String upper(String s) {
        return s.toUpperCase(Locale.ENGLISH);
    }
}
