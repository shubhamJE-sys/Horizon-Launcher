package com.horizon.launcher;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * The poster home screen. The whole screen is one sky that follows the time and weather; the frame lines,
 * clock, messages, battery, signal meter, music deck and text buttons are all drawn here.
 */
public class PosterView extends View {

    public interface Host {
        void openDrawer();

        /** Swipe down on the wallpaper: pull the notification shade. */
        void openNotifications();
        void openQuickSettings();

        void pickApp(int target);

        void openStyleMenu();

        /** Swipe left on the wallpaper: slide over to page 2, the room. */
        void showRoom();
    }

    private static final float DW = 360f, DH = 804f;
    private static final int RED_DEFAULT = Color.parseColor("#C8382C");
    private static final int MOON = Color.parseColor("#EDE6D3");

    /** City scene: the picture ends in a pavement edge (row 881 of 944); no water effects below it. */
    private static final float CITY_EDGE = 881f / 944f;
    /** Layered scenes (city, highway) are solid down to the imaginary line (the top of the greeting row, 30 units below SC_B)
     *  and fade out below it, behind the greeting row. */
    private static final float STACK_LINE = 477f + 47f, STACK_FADE = 23f;
    /** How far the lock screen's scene box (top 300) lies below the home screen's (top 241): the lock screen moves the sun and moon anchors up by this much for the layered scenes, so they stand where they do on the home screen. */
    static final float STACK_SUN_DROP = 59f;
    private static final float SC_L = 9.5f, SC_T = 241f, SC_R = 350.5f, SC_B = 477f;
    private static final float LAKE_Y = 241f + 236f * 0.66f;

    // music deck
    private static final float DECK_L = 12f, DECK_T = 399f, DECK_R = 348f, DECK_B = 549f;
    private static final float KEY_T = 507f, KEY_B = 533f;
    private static final float[] KEY_L = {116f, 149f, 183f, 216f};
    private static final float[] KEY_WS = {29f, 30f, 29f, 30f};

    private static String weatherUrl(double lat, double lon) {
        return "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                + "&current=temperature_2m,weather_code,cloud_cover,visibility"
                + "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
                + "&timezone=auto&forecast_days=5";
    }

    private static final String[] BUTTON_WORDS = {
            "PHONE", "MESSAGES", "BROWSER", "GALLERY", "CAMERA", "PLAY STORE"};
    private static final String[] DEFAULT_CAPS = {
            "MAKE THE CALL", "SEND A MESSAGE", "BROWSE THE WEB",
            "SHARE YOUR MOMENTS", "CAPTURE THE MOMENT", "DISCOVER NEW APPS"};
    private static final String[] NEWS_PACKAGES = {
            "com.google.android.apps.magazines", "com.eterno", "com.nis.app",
            "com.microsoft.amp.apps.bingnews", "flipboard.app", "com.toi.reader.activities"};

    /** Cloud shapes as groups of ovals: {dx, dy, rx, ry}, all relative to the cloud centre. */
    private static final float[][][] CLOUD_SHAPES = {
            {{0, 0, 26, 8}, {-14, -5, 15, 8}, {9, -9, 17, 10}},                       // classic three-puff
            {{0, 0, 24, 8}, {-12, -7, 12, 9}, {2, -12, 13, 11}, {14, -6, 11, 8}},     // tall and puffy
            {{0, 0, 36, 6}, {-12, -4, 16, 5}, {15, -3, 14, 5}},                       // long and flat
            {{0, 0, 17, 7}, {-5, -6, 10, 8}, {6, -5, 9, 7}},                          // small round
            {{0, 0, 28, 8}, {-14, -8, 12, 10}, {12, -10, 14, 11}, {0, -5, 10, 6}},    // two humps
            {{0, 0, 32, 4}, {-9, -3, 17, 3}}};                                        // thin wisp

    /** Clouds drift over the whole sky, above and inside the scene: {x, y, size, shape, strength}. */
    private static final float[][] CLOUDS = {
            {.18f, 150f, 1.0f, 0, .55f}, {.50f, 300f, 1.3f, 4, 1f}, {.86f, 205f, 0.9f, 3, .5f},
            {.36f, 290f, 1.1f, 1, 1f}, {.72f, 118f, 1.2f, 2, .45f}, {.08f, 330f, 0.9f, 5, 1f},
            {.93f, 306f, 0.8f, 3, 1f}, {.45f, 88f, 1.0f, 5, .4f}, {.28f, 232f, 1.2f, 2, .6f},
            {.80f, 350f, 1.0f, 0, 1f}};

    private static final String[] TOWER = {
            "....#....",
            ".#..#..#.",
            "#.#.#.#.#",
            "#.#.#.#.#",
            "...###...",
            "...#.#...",
            "..#...#.."};

    private final Host host;
    private Bitmap sceneBmp;
    private SceneRender.Layers sceneLayers;   // stock scenes are drawn from layers so the reflection can lean
    private float viewX0 = 0f, viewX1 = 360f;  // the real left / right screen edges in design units
    private String sceneBmpId = "";
    private Typeface bebas, roboto;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint layerPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audio;
    private SignalWatcher signal;
    private ConnectivityManager.NetworkCallback netCallback;

    private float scale = 1f, offX = 0f, offY = 0f;
    private int bottomInset = 0;
    private boolean receiving = false;
    private boolean started = false;
    private long lastTap = 0;
    private long sceneTapAt = 0L;

    private float downX, downY;
    private long downTime;
    private int touchSlop = 24;

    private int batteryPct = 100;
    private int pluggedType = 0;
    private float tempC = -1f;

    private boolean weatherOk = false;
    private String weatherLoc = "";
    private String sunKey = "";
    private volatile boolean fetching = false;
    private long lastFetch = 0;
    private int wCode = 0, wCloud = 0;
    private float wVisM = -1f;                     // real visibility in metres (-1 = unknown)
    private int fcDays = 0;
    private final String[] fcName = new String[5];
    private final int[] fcCode = new int[5], fcRain = new int[5];
    private final float[] fcMax = new float[5], fcMin = new float[5];
    private int infoMode = InfoCards.NONE;
    private float wTemp = 0f;
    private int sunriseMin = 360, sunsetMin = 1080;

    private final float[] rainX = new float[120];
    private final float[] rainY = new float[120];
    private final float[] starX = new float[70];
    private final float[] starY = new float[70];
    private final float[] starR = new float[70];

    private boolean panelOpen = false;

    // user-chosen apps: 0-5 buttons, 6 music, 7 clock, 8 calendar, 9 greeting (news)
    private final ComponentName[] custom = new ComponentName[10];
    private final String[] customLabel = new String[10];
    private SharedPreferences prefs;
    private boolean longFired = false;
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            onLongPress();
        }
    };
    private final Runnable wallHold = new Runnable() {
        @Override
        public void run() {
            onWallHold();
        }
    };

    // look of the day
    private ContentPack pack;
    private Look look;
    private int lookDay = Integer.MIN_VALUE;
    private boolean lookDirty = true;
    private Sky sky;
    private Palette pal = Palette.HORIZON;

    // sun / moon of this frame
    private float bodyX, bodyY, bodyR;
    private boolean bodyUp, isDay;
    private Body body = new Body();
    private float sunBright = 0.5f;

    // network readout
    private float wifiFrac = 0f, mobFrac = 0f;
    private String wifiLabel = "WI-FI • OFF", mobLabel = "MOBILE • --";
    private boolean noNet = false;

    // battery message cache
    private String batText = "";
    private String batKey = "";

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                readBattery(intent);
            }
            fetchWeather();
            invalidate();
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (started && panelOpen) {
                boolean busy = musicActive() || SystemClock.uptimeMillis() < volUntil;
                handler.postDelayed(this, busy ? 55 : 1000);
            }
        }
    };

    public PosterView(Context ctx, Host host) {
        super(ctx);
        this.host = host;
        setBackgroundColor(Sky.CREAM);
        try {
            touchSlop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        } catch (Exception ignored) { }
        try {
            bebas = Typeface.createFromAsset(ctx.getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(ctx.getAssets(), "Roboto-Regular.ttf");
        } catch (Exception e) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }
        audio = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        prefs = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
        for (int i = 0; i < custom.length; i++) {
            String f = prefs.getString("app_" + i, null);
            if (f != null) {
                custom[i] = ComponentName.unflattenFromString(f);
                customLabel[i] = prefs.getString("label_" + i, "");
            }
        }
        sunriseMin = prefs.getInt("sr", 360);
        sunsetMin = prefs.getInt("ss", 1080);
        pack = ContentPack.load(ctx);

        signal = new SignalWatcher(ctx, new Runnable() {
            @Override
            public void run() {
                postInvalidate();
            }
        });

        Random r = new Random(11);
        for (int i = 0; i < rainX.length; i++) {
            rainX[i] = r.nextFloat() * 341f;
            rainY[i] = r.nextFloat() * 236f;
        }
        for (int i = 0; i < starX.length; i++) {
            starX[i] = 4f + r.nextFloat() * 352f;
            starY[i] = 8f + r.nextFloat() * 370f;
            starR[i] = 0.5f + r.nextFloat() * 0.9f;
        }
        Intent sticky = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (sticky != null) readBattery(sticky);
    }

    // ---------- public API for the activity ----------

    public void setBottomInset(int px) {
        bottomInset = Math.max(0, px);
        invalidate();
    }

    /** The app the user picked for a tap area, or "" when it still uses the default. */
    public String customLabelOf(int target) {
        if (target < 0 || target >= custom.length || custom[target] == null) return "";
        return customLabel[target] == null ? "" : customLabel[target];
    }

    public void setCustom(int target, ComponentName cn, String label) {
        if (target < 0 || target >= custom.length) return;
        SharedPreferences.Editor ed = prefs.edit();
        if (cn == null) {
            custom[target] = null;
            customLabel[target] = null;
            ed.remove("app_" + target).remove("label_" + target);
        } else {
            custom[target] = cn;
            customLabel[target] = label;
            ed.putString("app_" + target, cn.flattenToString()).putString("label_" + target, label);
        }
        ed.apply();
        invalidate();
    }

    public void closePanel() {
        panelOpen = false;
        handler.removeCallbacks(ticker);
        invalidate();
    }

    /** Called after the style menu changed a setting or a pack was imported. */
    public void refreshLook() {
        lookDirty = true;
        invalidate();
    }

    public void reloadPack() {
        pack = ContentPack.load(getContext());
        lookDirty = true;
        invalidate();
    }

    public ContentPack pack() {
        return pack;
    }

    public Look look() {
        ensureLook(Calendar.getInstance());
        return look;
    }

    public int skyMid() {
        return sky != null ? sky.mid() : Sky.CREAM;
    }

    public int skyInk() {
        return sky != null ? sky.fgAt(400f) : Sky.INK;
    }

    public int skyAccent() {
        return sky != null ? sky.accent() : RED_DEFAULT;
    }

    public int sunriseMin() {
        return sunriseMin;
    }

    public int sunsetMin() {
        return sunsetMin;
    }

    public float cloudAmount() {
        return cloudFrac();
    }

    // what the room's window needs to show the same weather and scene as page 1
    SceneRender.Layers sceneLayers() {
        return sceneLayers;
    }

    public int roomRain() {
        return rainLevel();
    }

    public boolean roomSnow() {
        return snowing();
    }

    public float roomFog() {
        return fogStrength();
    }

    public String sceneId() {
        return look != null ? look.sceneId : "lake";
    }

    public boolean inkOnly() {
        return prefs != null && prefs.getBoolean("ink", false);
    }

    public boolean hasWeather() {
        return weatherOk;
    }

    // ---------- lifecycle (called by the activity) ----------

    public void start() {
        started = true;
        if (!receiving) {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_TIME_TICK);
            f.addAction(Intent.ACTION_TIME_CHANGED);
            f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            f.addAction(Intent.ACTION_BATTERY_CHANGED);
            f.addAction(Intent.ACTION_POWER_CONNECTED);
            f.addAction(Intent.ACTION_POWER_DISCONNECTED);
            f.addAction("android.net.conn.CONNECTIVITY_CHANGE");
            f.addAction("android.net.wifi.RSSI_CHANGED");
            f.addAction("android.net.wifi.WIFI_STATE_CHANGED");
            if (Build.VERSION.SDK_INT >= 33) {
                getContext().registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                getContext().registerReceiver(receiver, f);
            }
            receiving = true;
        }
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && netCallback == null) {
                netCallback = new ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(Network network) {
                        postInvalidate();
                    }

                    @Override
                    public void onLost(Network network) {
                        postInvalidate();
                    }

                    @Override
                    public void onCapabilitiesChanged(Network network, NetworkCapabilities nc) {
                        postInvalidate();
                    }
                };
                NetworkRequest req = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
                cm.registerNetworkCallback(req, netCallback);
            }
        } catch (Throwable t) {
            netCallback = null;
        }
        if (signal != null) signal.start();
        Intent sticky = getContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (sticky != null) readBattery(sticky);
        fetchWeather();
        invalidate();
        handler.removeCallbacks(ticker);
        if (panelOpen) handler.postDelayed(ticker, 500);
    }

    public void stop() {
        started = false;
        handler.removeCallbacks(ticker);
        handler.removeCallbacks(longPress);
        handler.removeCallbacks(wallHold);
        if (receiving) {
            try { getContext().unregisterReceiver(receiver); } catch (Exception ignored) { }
            receiving = false;
        }
        if (netCallback != null) {
            try {
                ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                if (cm != null) cm.unregisterNetworkCallback(netCallback);
            } catch (Throwable ignored) { }
            netCallback = null;
        }
        if (signal != null) signal.stop();
    }

    // ---------- battery ----------

    private void readBattery(Intent i) {
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scaleVal = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (level >= 0 && scaleVal > 0) batteryPct = Math.round(level * 100f / scaleVal);
        pluggedType = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        tempC = t >= 0 ? t / 10f : -1f;
        // below 15% the whole poster turns to plain ink and paper; it comes back above 20%
        if (batteryPct >= 0 && prefs != null) {
            boolean on = prefs.getBoolean("ink", false);
            boolean want = on;
            if (batteryPct < 15) want = true;
            else if (batteryPct >= 20) want = false;
            if (want != on) {
                prefs.edit().putBoolean("ink", want).apply();
                lookDirty = true;
                invalidate();
            }
        }
    }

    // ---------- weather ----------

    private void fetchWeather() {
        long now = SystemClock.elapsedRealtime();
        if (fetching) return;
        if (weatherOk && now - lastFetch < 30L * 60L * 1000L) return;
        if (!weatherOk && lastFetch != 0 && now - lastFetch < 2L * 60L * 1000L) return;
        fetching = true;
        lastFetch = now;
        Loc.refreshAuto(getContext(), false);
        final double[] ll = Loc.get(getContext());
        final String locKey = Math.round(ll[0] * 10) + "," + Math.round(ll[1] * 10);
        if (!locKey.equals(weatherLoc)) {
            weatherLoc = locKey;
            weatherOk = false;   // another place: the old readings do not apply
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection con = (HttpURLConnection) new URL(weatherUrl(ll[0], ll[1])).openConnection();
                    con.setConnectTimeout(8000);
                    con.setReadTimeout(8000);
                    InputStream in = con.getInputStream();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    con.disconnect();
                    JSONObject j = new JSONObject(bo.toString("UTF-8"));
                    JSONObject cur = j.getJSONObject("current");
                    final float temp = (float) cur.getDouble("temperature_2m");
                    final int code = cur.getInt("weather_code");
                    final int cloud = cur.getInt("cloud_cover");
                    final float vis = (float) cur.optDouble("visibility", -1.0);
                    final int nd;
                    final String[] dn = new String[5];
                    final int[] dc = new int[5], dr = new int[5];
                    final float[] dmax = new float[5], dmin = new float[5];
                    int ndTmp = 0;
                    try {
                        JSONObject dl = j.getJSONObject("daily");
                        org.json.JSONArray tm = dl.getJSONArray("time"), wc = dl.getJSONArray("weather_code"),
                                mx = dl.getJSONArray("temperature_2m_max"), mn = dl.getJSONArray("temperature_2m_min");
                        org.json.JSONArray pr = dl.optJSONArray("precipitation_probability_max");
                        ndTmp = Math.min(5, tm.length());
                        for (int k = 0; k < ndTmp; k++) {
                            String ds = tm.getString(k);
                            Calendar dcal = Calendar.getInstance();
                            dcal.set(Integer.parseInt(ds.substring(0, 4)), Integer.parseInt(ds.substring(5, 7)) - 1,
                                    Integer.parseInt(ds.substring(8, 10)));
                            dn[k] = k == 0 ? "TODAY" : dcal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
                            dc[k] = wc.optInt(k, 0);
                            dmax[k] = (float) mx.optDouble(k, 0);
                            dmin[k] = (float) mn.optDouble(k, 0);
                            dr[k] = pr == null || pr.isNull(k) ? -1 : pr.optInt(k, -1);
                        }
                    } catch (Exception ignored) { ndTmp = 0; }
                    nd = ndTmp;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            wVisM = vis;
                            fcDays = nd;
                            for (int k = 0; k < nd; k++) {
                                fcName[k] = dn[k];
                                fcCode[k] = dc[k];
                                fcMax[k] = dmax[k];
                                fcMin[k] = dmin[k];
                                fcRain[k] = dr[k];
                            }
                            wTemp = temp;
                            wCode = code;
                            wCloud = cloud;
                            prefs.edit().putInt("wcloud", cloud).putInt("wcode", code).apply();
                            weatherOk = true;
                            invalidate();
                        }
                    });
                } catch (Exception ignored) {
                } finally {
                    fetching = false;
                }
            }
        }).start();
    }

    private int toMinutes(String iso) {
        int h = Integer.parseInt(iso.substring(11, 13));
        int m = Integer.parseInt(iso.substring(14, 16));
        return h * 60 + m;
    }

    private float cloudFrac() {
        if (!weatherOk) return 0f;
        float c = wCloud / 100f;
        if (wCode >= 51) c = Math.max(c, 0.8f);
        else if (wCode == 45 || wCode == 48) c = Math.max(c, 0.6f);
        return Math.max(0f, Math.min(1f, c));
    }

    private int rainLevel() {
        if (!weatherOk) return 0;
        switch (wCode) {
            case 51: case 53: case 55: case 56: case 57:
                return 1;
            case 61: case 63: case 66: case 80: case 81:
                return 2;
            case 65: case 67: case 82: case 95: case 96: case 99:
                return 3;
            default:
                return 0;
        }
    }

    private boolean snowing() {
        return weatherOk && ((wCode >= 71 && wCode <= 77) || wCode == 85 || wCode == 86);
    }

    /** Effective visibility in metres for the fog look: the real reading, or a guess when the code says fog. */
    private float fogVisibility() {
        if (!weatherOk) return 10000f;
        boolean fogCode = wCode == 45 || wCode == 48;
        float v = wVisM >= 0f ? wVisM : (fogCode ? 700f : 10000f);
        if (fogCode && v > 1000f) v = 900f;   // the report says fog, so show at least thin fog
        return v;
    }

    /** 0 = clear; mist 1-2 km is faint, fog 0.5-1 km, thick 200-500 m, dense 100-200 m nearly hides the scene; never fully blank. */
    private float fogStrength() {
        float v = fogVisibility();
        if (v >= 2000f) return 0f;
        float s;
        if (v >= 1000f) s = 0.16f + 0.14f * (2000f - v) / 1000f;
        else if (v >= 500f) s = 0.30f + 0.20f * (1000f - v) / 500f;
        else if (v >= 200f) s = 0.50f + 0.25f * (500f - v) / 300f;
        else if (v >= 100f) s = 0.75f + 0.13f * (200f - v) / 100f;
        else s = 0.88f;
        return Math.min(0.88f, s);
    }

    private String fogLabel() {
        float v = fogVisibility();
        String name = v >= 1000f ? "MIST" : (v >= 500f ? "FOG" : (v >= 200f ? "THICK FOG" : "DENSE FOG"));
        String dist = v >= 1000f ? String.format(Locale.US, "%.1f KM", v / 1000f)
                : (Math.round(v / 50f) * 50) + " M";
        return name + " • " + dist;
    }

    private String weatherLabel(boolean night) {
        if (fogStrength() > 0f) return fogLabel();
        switch (wCode) {
            case 0: return night ? "CLEAR NIGHT" : "CLEAR SKY";
            case 1: return "MOSTLY CLEAR";
            case 2: return "PARTLY CLOUDY";
            case 3: return "OVERCAST";
            case 45: case 48: return "FOG";
            case 51: case 53: case 55: case 56: case 57: return "DRIZZLE";
            case 61: case 63: case 65: case 66: case 67: return "RAIN";
            case 80: case 81: case 82: return "SHOWERS";
            case 71: case 73: case 75: case 77: case 85: case 86: return "SNOW";
            case 95: case 96: case 99: return "THUNDERSTORM";
            default: return "WEATHER";
        }
    }

    // ---------- network readout (Wi-Fi row and mobile row) ----------

    private static String strength(float frac) {
        if (frac >= 0.75f) return "STRONG";
        if (frac >= 0.5f) return "GOOD";
        if (frac >= 0.28f) return "FAIR";
        return "WEAK";
    }

    private void readNetwork() {
        boolean wifiConn = false, cellData = false;
        int rssi = Integer.MIN_VALUE;
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                    if (nc == null || !nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue;
                    if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        wifiConn = true;
                        if (Build.VERSION.SDK_INT >= 29) {
                            int ss = nc.getSignalStrength();
                            if (ss != NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED) rssi = ss;
                        }
                    } else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        cellData = true;
                    }
                }
            }
        } catch (Throwable ignored) { }

        boolean wifiOn = false;
        try {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                wifiOn = wm.isWifiEnabled();
                if (wifiConn && rssi == Integer.MIN_VALUE) {
                    WifiInfo wi = wm.getConnectionInfo();
                    if (wi != null && wi.getRssi() > -127) rssi = wi.getRssi();
                }
            }
        } catch (Throwable ignored) { }

        if (wifiConn) {
            if (rssi != Integer.MIN_VALUE) {
                wifiFrac = Math.max(0.08f, Math.min(1f, (rssi + 100f) / 50f));
                wifiLabel = "WI-FI • " + strength(wifiFrac);
            } else {
                wifiFrac = 1f;
                wifiLabel = "WI-FI • CONNECTED";
            }
        } else {
            wifiFrac = 0f;
            wifiLabel = wifiOn ? "WI-FI • NOT JOINED" : "WI-FI • OFF";
        }

        // the phone's own "mobile data" switch (readable without any permission)
        boolean dataOff = false;
        try {
            android.content.ContentResolver cr = getContext().getContentResolver();
            dataOff = android.provider.Settings.Global.getInt(cr, "mobile_data", 1) == 0;
        } catch (Throwable ignored) { }

        int lvl = signal != null ? signal.level() : -1;
        if (dataOff && !cellData) {
            mobFrac = 0f;
            mobLabel = "MOBILE • DATA OFF";
        } else if (lvl >= 0) {
            mobFrac = lvl / 4f;
            mobLabel = lvl == 0 ? "MOBILE • NO SIGNAL" : "MOBILE • " + strength(Math.max(0.28f, mobFrac));
            if (lvl == 4) mobLabel = "MOBILE • STRONG";
        } else {
            mobFrac = cellData ? 1f : 0f;
            mobLabel = cellData ? "MOBILE • DATA ON" : "MOBILE • DATA OFF";
        }
        noNet = !wifiConn && !cellData;
    }

    // ---------- music remote ----------

    private boolean musicActive() {
        try {
            return audio != null && audio.isMusicActive();
        } catch (Exception e) {
            return false;
        }
    }

    private void sendKey(int code) {
        try {
            long t = SystemClock.uptimeMillis();
            audio.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0));
            audio.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0));
        } catch (Exception ignored) { }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        }, 500);
    }

    private void transport(int which) {
        int key = which == 0 ? KeyEvent.KEYCODE_MEDIA_PREVIOUS
                : (which == 1 ? KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE : KeyEvent.KEYCODE_MEDIA_NEXT);
        sendKey(key);
    }

    private void launchComponent(ComponentName cn) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(cn);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }

    private void openMusicApp() {
        if (custom[6] != null) {
            launchComponent(custom[6]);
            return;
        }
        if (host != null) host.pickApp(6);
    }

    private void openNews() {
        if (custom[9] != null) {
            launchComponent(custom[9]);
            return;
        }
        PackageManager pm = getContext().getPackageManager();
        for (String pkg : NEWS_PACKAGES) {
            try {
                Intent li = pm.getLaunchIntentForPackage(pkg);
                if (li != null) {
                    li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(li);
                    return;
                }
            } catch (Exception ignored) { }
        }
        if (host != null) host.pickApp(9);
    }

    private void openClock() {
        if (custom[7] != null) {
            launchComponent(custom[7]);
            return;
        }
        try {
            Intent i = new Intent(AlarmClock.ACTION_SHOW_ALARMS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            return;
        } catch (Exception ignored) { }
        try {
            PackageManager pm = getContext().getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo r : pm.queryIntentActivities(main, 0)) {
                String lbl = String.valueOf(r.loadLabel(pm)).toLowerCase(Locale.ROOT);
                String pkg = r.activityInfo.packageName.toLowerCase(Locale.ROOT);
                if (lbl.contains("clock") || pkg.contains("deskclock") || pkg.contains("alarmclock")) {
                    launchComponent(new ComponentName(r.activityInfo.packageName, r.activityInfo.name));
                    return;
                }
            }
        } catch (Exception ignored) { }
    }

    private void openCalendar() {
        if (custom[8] != null) {
            launchComponent(custom[8]);
            return;
        }
        startIntent(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR));
    }

    private void startIntent(Intent i) {
        if (i == null) return;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }


    // ---------- hold menu (browser / messages) ----------

    private static final class MenuItem {
        String label;
        String pkg;       // launch by package, or null for "choose app"
        Bitmap icon;
        int pickTarget = -1;
    }

    private final Paint menuIconPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private boolean menuOpen = false;
    private int menuSel = -1;
    private int menuTarget = 0;
    private final java.util.ArrayList<MenuItem> menuItems = new java.util.ArrayList<>();
    private float menuL, menuT, menuW = 168f, menuRow = 30f;

    private Intent launchFirst(String... pkgs) {
        PackageManager pm = getContext().getPackageManager();
        for (String p : pkgs) {
            try {
                Intent li = pm.getLaunchIntentForPackage(p);
                if (li != null) return li;
            } catch (Throwable ignored) { }
        }
        return null;
    }

    private void addMenuPkg(java.util.HashSet<String> seen, String pkg) {
        if (pkg == null || pkg.equals(getContext().getPackageName()) || !seen.add(pkg)) return;
        PackageManager pm = getContext().getPackageManager();
        try {
            if (pm.getLaunchIntentForPackage(pkg) == null) return;
            MenuItem mi = new MenuItem();
            mi.pkg = pkg;
            mi.label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
            android.graphics.drawable.Drawable d = pm.getApplicationIcon(pkg);
            Bitmap b = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888);
            Canvas cc = new Canvas(b);
            d.setBounds(0, 0, 72, 72);
            d.draw(cc);
            mi.icon = b;
            menuItems.add(mi);
        } catch (Throwable ignored) { }
    }

    /** Every installed app that could sit in the hold list of Messages (1) or Browser (2): {package, label}. */
    java.util.List<String[]> altCandidates(int target) {
        java.util.List<String[]> out = new java.util.ArrayList<>();
        java.util.LinkedHashSet<String> pk = new java.util.LinkedHashSet<>();
        PackageManager pm = getContext().getPackageManager();
        try {
            if (target == 2) {
                pk.add("com.android.chrome");
                for (ResolveInfo r : pm.queryIntentActivities(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://example.com")), PackageManager.MATCH_ALL))
                    pk.add(r.activityInfo.packageName);
            } else {
                for (String k : new String[]{"com.whatsapp", "com.google.android.apps.messaging", "com.oneplus.mms", "com.android.mms",
                        "org.telegram.messenger", "org.thoughtcrime.securesms", "com.facebook.orca", "com.whatsapp.w4b"}) pk.add(k);
                for (ResolveInfo r : pm.queryIntentActivities(new Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:")), PackageManager.MATCH_ALL))
                    pk.add(r.activityInfo.packageName);
            }
        } catch (Throwable ignored) { }
        for (String k : pk) {
            try {
                if (pm.getLaunchIntentForPackage(k) == null) continue;
                out.add(new String[]{k, String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(k, 0)))});
            } catch (Throwable ignored) { }
        }
        return out;
    }

    private boolean openAppMenu(int target, float x, float y) {
        menuItems.clear();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        PackageManager pm = getContext().getPackageManager();
        // the app the button itself opens is never one of its "alternatives"
        String mainPkg = (custom[target] != null) ? custom[target].getPackageName() : (target == 2 ? "com.android.chrome" : "com.whatsapp");
        seen.add(mainPkg);
        String saved = getContext().getSharedPreferences("horizon", 0).getString("alts_" + target, null);
        if (saved != null) {   // the list chosen in APP SETUP
            for (String k : saved.split(",")) if (k.length() > 0) addMenuPkg(seen, k);
        } else if (target == 2) {
            try {
                Intent v = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://example.com"));
                for (ResolveInfo r : pm.queryIntentActivities(v, PackageManager.MATCH_ALL)) {
                    addMenuPkg(seen, r.activityInfo.packageName);
                }
            } catch (Throwable ignored) { }
        } else {
            String[] known = {"com.google.android.apps.messaging", "com.oneplus.mms", "com.android.mms",
                    "org.telegram.messenger", "org.thoughtcrime.securesms", "com.facebook.orca", "com.whatsapp.w4b"};
            for (String k : known) addMenuPkg(seen, k);
            // the automatic list is only real messaging apps: the known ones and the phone's default SMS app
            // (any other app that merely answers "smsto:", such as some operator apps, can be added by hand in APP SETUP)
            try {
                String def = android.provider.Telephony.Sms.getDefaultSmsPackage(getContext());
                if (def != null) addMenuPkg(seen, def);
            } catch (Throwable ignored) { }
        }
        while (menuItems.size() > 6) menuItems.remove(menuItems.size() - 1);
        // the list is only for opening apps; choosing which apps live here is done in Horizon APP SETUP
        if (menuItems.isEmpty()) return false;
        if (menuItems.size() == 1) {   // one app only: open it straight away
            startIntent(launchFirst(menuItems.get(0).pkg));
            return true;
        }
        menuTarget = target;
        float h = menuItems.size() * menuRow;
        menuL = Math.max(viewX0 + 8f, Math.min(viewX1 - 8f - menuW, x - menuW / 2f));
        menuT = Math.max(46f, y - 34f - h);
        menuSel = -1;
        menuOpen = true;
        invalidate();
        return true;
    }

    private int menuRowAt(float x, float y) {
        if (x < menuL - 6f || x > menuL + menuW + 6f) return -1;
        int r = (int) Math.floor((y - menuT) / menuRow);
        return (r >= 0 && r < menuItems.size()) ? r : -1;
    }

    private void runMenuItem(MenuItem mi) {
        if (mi.pickTarget >= 0) {
            if (host != null) host.pickApp(mi.pickTarget);
            return;
        }
        startIntent(launchFirst(mi.pkg));
    }

    private void drawAppMenu(Canvas c) {
        if (!menuOpen || menuItems.isEmpty()) return;
        float h = menuItems.size() * menuRow;
        int accent = sky.accent();
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x66000000);
        c.drawRoundRect(new RectF(menuL + 2f, menuT + 3f, menuL + menuW + 2f, menuT + h + 3f), 8f, 8f, paint);
        paint.setColor(0xFFF3EBDA);
        c.drawRoundRect(new RectF(menuL, menuT, menuL + menuW, menuT + h), 8f, 8f, paint);
        for (int i = 0; i < menuItems.size(); i++) {
            float y = menuT + i * menuRow;
            if (i == menuSel) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(accent);
                c.drawRoundRect(new RectF(menuL + 3f, y + 2f, menuL + menuW - 3f, y + menuRow - 2f), 6f, 6f, paint);
            }
            MenuItem mi = menuItems.get(i);
            if (mi.icon != null) {
                c.drawBitmap(mi.icon, null, new RectF(menuL + 8f, y + 4f, menuL + 30f, y + 26f), menuIconPaint);
            }
            text(c, mi.label.toUpperCase(Locale.US), menuL + (mi.icon != null ? 38f : 12f), y + 19f, 9.5f,
                    i == menuSel ? 0xFFF3EBDA : 0xFF1B1B1A, roboto, Paint.Align.LEFT, 0.1f);
            if (i < menuItems.size() - 1) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(0x33000000);
                c.drawRect(menuL + 8f, y + menuRow - 0.5f, menuL + menuW - 8f, y + menuRow + 0.5f, paint);
            }
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.5f);
        paint.setColor(0xFF1B1B1A);
        c.drawRoundRect(new RectF(menuL, menuT, menuL + menuW, menuT + h), 8f, 8f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    // ---------- touch ----------

    /** Which tappable area a point (design units) is in: 0-5 buttons, 6 music, 7 clock, 8 calendar, 9 greeting, 10 drawer strip, -1 none. */
    private int hotspot(float x, float y) {
        // every zone is one cell of the printed grid: the lines are at y 582, 640, 670, 728, 786 (four rows of 58 units) and x 136 / 122.7 / 237.3
        if (inRect(x, y, 240f, 524f, 350f, 582f)) return 6;
        if (inRect(x, y, viewX0, 524f, 238f, 582f)) return 9;
        if (inRect(x, y, viewX0, 670f, viewX1, 786f)) {
            int col = x < 8f + 344f / 3f ? 0 : (x < 8f + 688f / 3f ? 1 : 2);
            return (y < 728f ? 0 : 3) + col;
        }
        if (inRect(x, y, 8f, 34f, 108f, 196f)) return 7;
        if (inRect(x, y, 108f, 34f, 228f, 150f) || inRect(x, y, 228f, 34f, 352f, 240f)) return 8;
        if (inRect(x, y, 90f, 786f, 270f, 804f)) return 10;
        if (inRect(x, y, 108f, 152f, 228f, 212f)) return 13;   // sunrise and sunset times: opens sun and moon info
        if (weatherOk && inRect(x, y, 298f, 246f, 352f, 282f)) return 11;   // just the weather text
        if (inRect(x, y, viewX0, 582f, 136f, 640f)) return 12;   // the day-of-the-year cell
        return -1;
    }


    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (menuOpen) {
            int act = e.getActionMasked();
            float mxd = (e.getX() - offX) / scale, myd = (e.getY() - offY) / scale;
            if (act == MotionEvent.ACTION_MOVE) {
                int sel = menuRowAt(mxd, myd);
                if (sel != menuSel) {
                    menuSel = sel;
                    if (sel >= 0) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                    invalidate();
                }
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                int sel = act == MotionEvent.ACTION_UP ? menuRowAt(mxd, myd) : -1;
                menuOpen = false;
                if (sel >= 0) runMenuItem(menuItems.get(sel));
                invalidate();
            }
            return true;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = e.getX();
                downY = e.getY();
                downTime = SystemClock.uptimeMillis();
                longFired = false;
                handler.removeCallbacks(longPress);
                handler.removeCallbacks(wallHold);
                float x = (downX - offX) / scale, y = (downY - offY) / scale;
                volDrag = false;
                if (panelOpen && inVolumeStrip(x, y)) {
                    volDrag = true;
                    volumeFromX(x);
                    return true;
                }
                if (!panelOpen) {
                    if (hotspot(x, y) >= 0 && hotspot(x, y) != 10) {
                        int hh = hotspot(x, y);
                        handler.postDelayed(longPress, (hh == 1 || hh == 2) ? 1250 : 450);
                    }
                    else if (hotspot(x, y) < 0) handler.postDelayed(wallHold, 1500);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (volDrag) {
                    volumeFromX((e.getX() - offX) / scale);
                    return true;
                }
                float mx = e.getX() - downX, my = e.getY() - downY;
                if (mx * mx + my * my > (float) touchSlop * touchSlop * 2.5f) {
                    handler.removeCallbacks(longPress);
                    handler.removeCallbacks(wallHold);
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                volDrag = false;
                handler.removeCallbacks(longPress);
                handler.removeCallbacks(wallHold);
                return true;
            case MotionEvent.ACTION_UP: {
                handler.removeCallbacks(longPress);
                handler.removeCallbacks(wallHold);
                if (volDrag) {
                    volDrag = false;
                    return true;
                }
                if (longFired) return true;
                float dx = e.getX() - downX, dy = e.getY() - downY;
                if (dx < -touchSlop * 5f && Math.abs(dx) > Math.abs(dy) * 1.4f) {
                    closePanel();
                    if (host != null) host.showRoom();
                } else if (dy < -touchSlop * 4f && Math.abs(dy) > Math.abs(dx)) {
                    closePanel();
                    if (host != null) host.openDrawer();
                } else if (dy > touchSlop * 4f && Math.abs(dy) > Math.abs(dx) * 1.2f) {
                    closePanel();
                    if (host != null) {
                        // left half: notifications, right half: quick settings
                        if (downX < getWidth() / 2f) host.openNotifications(); else host.openQuickSettings();
                    }
                } else if (dx * dx + dy * dy <= (float) touchSlop * touchSlop
                        && SystemClock.uptimeMillis() - downTime < 500) {
                    handleTap(e.getX(), e.getY());
                }
                return true;
            }
            default:
                return true;
        }
    }

    private void onLongPress() {
        float x = (downX - offX) / scale;
        float y = (downY - offY) / scale;
        int target = hotspot(x, y);
        if (target == 0) {
            longFired = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            Intent ci = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS);
            startIntent(ci);
            return;
        }
        if ((target == 1 || target == 2) && openAppMenu(target, x, y)) {
            longFired = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            return;
        }
        if (target == 1 || target == 2) {   // no other apps to list: just open the main app
            longFired = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            lastTap = 0;
            handleTap(downX, downY);
            return;
        }
        if (target >= 0 && target <= 9 && host != null) {
            longFired = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            host.pickApp(target);
        }
    }

    private void onWallHold() {
        if (host == null || panelOpen) return;
        longFired = true;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        host.openStyleMenu();
    }

    private boolean inRect(float x, float y, float l, float t, float r, float b) {
        return x >= l && x <= r && y >= t && y <= b;
    }

    private void handleTap(float px, float py) {
        long now = SystemClock.uptimeMillis();
        if (now - lastTap < 300) return;
        float x = (px - offX) / scale;
        float y = (py - offY) / scale;

        if (infoMode != InfoCards.NONE) {
            lastTap = now;
            infoMode = InfoCards.NONE;
            invalidate();
            return;
        }
        if (panelOpen) {
            lastTap = now;
            if (inRect(x, y, DECK_L, DECK_T, DECK_R, DECK_B)) {
                deckTap(x, y);
            } else {
                closePanel(); // touching outside closes the player
            }
            return;
        }
        int h = hotspot(x, y);
        if (h < 0) {
            // the sun or the moon in the sky opens its details
            boolean hit = false;
            if (body.sunUp && inRect(x, y, body.sx - body.sr - 12f, body.sy - body.sr - 12f, body.sx + body.sr + 12f, body.sy + body.sr + 12f)) hit = true;
            if (body.moonUp && inRect(x, y, body.mx - body.mr - 12f, body.my - body.mr - 12f, body.mx + body.mr + 12f, body.my + body.mr + 12f)) hit = true;
            if (hit && y < LAKE_Y) {
                lastTap = now;
                infoMode = InfoCards.SUNMOON;
                invalidate();
            } else if (!hit && sceneLayers != null && sceneLayers.stack != null
                    && inRect(x, y, SC_L, SC_T, SC_R, SC_B)) {
                // double tap on the scene: the Meteor rides past
                if (now - sceneTapAt < 550L) {
                    sceneTapAt = 0L;
                    if (StackScene.trigger(System.currentTimeMillis())) {
                        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                        invalidate();
                    }
                } else {
                    sceneTapAt = now;
                }
            }
            return;
        }
        lastTap = now;
        switch (h) {
            case 13:
                infoMode = InfoCards.SUNMOON;
                invalidate();
                break;
            case 11:
                infoMode = InfoCards.FORECAST;
                invalidate();
                break;
            case 12:
                infoMode = InfoCards.HOLIDAYS;
                invalidate();
                break;
            case 6:
                panelOpen = true;
                handler.removeCallbacks(ticker);
                handler.postDelayed(ticker, 300);
                invalidate();
                break;
            case 7:
                openClock();
                break;
            case 8:
                openCalendar();
                break;
            case 9:
                openNews();
                break;
            case 10:
                if (host != null) host.openDrawer();
                break;
            default:
                launchButton(h);
                break;
        }
    }

    private void deckTap(float x, float y) {
        // a tap on either speaker opens the volume control for a few seconds
        float[][] spk = {{DECK_L + 54f, DECK_T + 92f}, {DECK_L + 282f, DECK_T + 92f}};
        for (float[] sp : spk) {
            float dx = x - sp[0], dy = y - sp[1];
            if (dx * dx + dy * dy <= 44f * 44f) {
                volUntil = SystemClock.uptimeMillis() + 5000L;
                invalidate();
                return;
            }
        }
        if (y < KEY_T - 4f || y > KEY_B + 8f) return;
        for (int i = 0; i < 4; i++) {
            if (x >= KEY_L[i] - 1.5f && x <= KEY_L[i] + KEY_WS[i] + 1.5f) {
                if (i == 3) openMusicApp();
                else transport(i);
                return;
            }
        }
    }

    /** The phone app's own home (recents, favourites, contacts), not the bare keypad; the keypad is the fallback. */
    private Intent dialerHome() {
        try {
            android.telecom.TelecomManager tm =
                    (android.telecom.TelecomManager) getContext().getSystemService(Context.TELECOM_SERVICE);
            String pkg = tm == null ? null : tm.getDefaultDialerPackage();
            if (pkg != null) {
                Intent li = getContext().getPackageManager().getLaunchIntentForPackage(pkg);
                if (li != null) return li;
            }
        } catch (Throwable ignored) { }
        return new Intent(Intent.ACTION_DIAL);
    }

    private void launchButton(int idx) {
        if (idx >= 0 && idx < 6 && custom[idx] != null) {
            launchComponent(custom[idx]);
            return;
        }
        Intent i = null;
        switch (idx) {
            case 0:
                i = dialerHome();
                if (i != null) i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                break;
            case 1:
                i = launchFirst("com.whatsapp", "com.whatsapp.w4b");
                if (i == null) i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING);
                break;
            case 2:
                i = launchFirst("com.android.chrome");
                if (i == null) i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
                break;
            case 3:
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY);
                break;
            case 4:
                i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                break;
            case 5:
                i = getContext().getPackageManager().getLaunchIntentForPackage("com.android.vending");
                break;
            default:
                break;
        }
        startIntent(i);
    }

    // ---------- look of the day ----------

    private void ensureLook(Calendar cal) {
        int dn = Texts.dayNumber(cal);
        if (look == null || lookDirty || dn != lookDay
                || (look.previewUntil > 0 && System.currentTimeMillis() > look.previewUntil)) {
            look = Look.compute(getContext(), pack, cal);
            lookDay = dn;
            lookDirty = false;
            pal = look.pal;
        }
        if (!look.sceneId.equals(sceneBmpId)) {
            sceneBmp = loadScene(look.sceneId);
            sceneLayers = null;
            try {
                java.io.File pf = pack.sceneFile(look.sceneId);
                if (pf == null || !pf.isFile()) sceneLayers = SceneRender.load(getContext(), look.sceneId);
            } catch (Throwable ignored) { }
            sceneBmpId = look.sceneId;
        }
    }

    private Bitmap loadScene(String id) {
        Bitmap b = null;
        try {
            File f = pack.sceneFile(id);
            if (f != null && f.isFile()) {
                b = BitmapFactory.decodeFile(f.getAbsolutePath());
            }
        } catch (Throwable ignored) { }
        if (b == null) {
            try {
                InputStream in = getContext().getAssets().open("scene_" + id + ".webp");
                b = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Throwable ignored) { }
        }
        if (b == null && !"lake".equals(id)) {
            try {
                InputStream in = getContext().getAssets().open("scene_lake.webp");
                b = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Throwable ignored) { }
        }
        return b;
    }

    // ---------- drawing helpers ----------

    private void text(Canvas c, String t, float x, float y, float size, int color,
                      Typeface tf, Paint.Align align, float spacingEm) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(tf);
        paint.setTextSize(size);
        paint.setColor(color);
        paint.setTextAlign(align);
        paint.setLetterSpacing(spacingEm);
        if (bdBmp != null && !sampling && !plain && (color == Sky.INK || color == Sky.LIGHT) && t.length() > 0) {
            drawContrast(c, t, x, y);
            return;
        }
        c.drawText(t, x, y, paint);
    }

    // ---------- contrast rule: every letter is white on a dark surrounding and black on a light one ----------
    private Bitmap bdBmp;
    private Canvas bdCv;
    private long bdAt;
    private boolean sampling;
    private boolean plain;   // true while a pop-up with its own background is drawn: its text keeps its own colours (no white/black rule)
    private float bdX0, bdY0;
    private static final float BDQ = 0.3f;   // backdrop picture: 0.3 pixel per design unit
    private final Matrix bdM = new Matrix();
    private final float[] bdP = new float[8];

    /** A small picture of what is behind the text (sky, sun, moon, scene), redrawn every few seconds. */
    private int bdMin = -1;
    private String bdKey = "";

    private void refreshBackdrop(Calendar cal, int w, int h, int nowMin) {
        long t = SystemClock.uptimeMillis();
        float vx0 = -offX / scale, vy0 = -offY / scale, vx1 = (w - offX) / scale, vy1 = (h - offY) / scale;
        int bw = Math.max(8, (int) ((vx1 - vx0) * BDQ)), bh = Math.max(8, (int) ((vy1 - vy0) * BDQ));
        String key = look.sceneId + "|" + bw + "x" + bh;
        boolean full = bdBmp == null || bdBmp.getWidth() != bw || bdBmp.getHeight() != bh || nowMin != bdMin || !key.equals(bdKey);
        // the sky only changes with the minute; only the band with the moving scene is redrawn every 4 seconds
        if (!full && t - bdAt < 4000L) return;
        bdAt = t;
        bdMin = nowMin;
        bdKey = key;
        if (bdBmp == null || bdBmp.getWidth() != bw || bdBmp.getHeight() != bh) {
            bdBmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            bdCv = new Canvas(bdBmp);
        }
        bdX0 = vx0;
        bdY0 = vy0;
        bdCv.save();
        if (!full) {
            bdCv.clipRect(0f, (SC_T - 40f - vy0) * BDQ, bw, (STACK_LINE + STACK_FADE + 8f - vy0) * BDQ);
        }
        bdCv.drawColor(sky.cols[3]);
        bdCv.scale(BDQ, BDQ);
        bdCv.translate(-vx0, -vy0);
        float oldX0 = viewX0, oldX1 = viewX1;
        viewX0 = vx0;
        viewX1 = vx1;
        sampling = true;
        try {
            sky.drawBackdrop(bdCv, paint, vx0, vy0, vx1, vy1, SC_L, SC_T, SC_R, SC_B, bodyX, LAKE_Y);
            drawSkyObjects(bdCv, cal);
            drawSceneLayer(bdCv);
        } catch (Throwable ignored) {
        } finally {
            sampling = false;
            viewX0 = oldX0;
            viewX1 = oldX1;
            bdCv.restore();
        }
        updateAmbient();
    }

    /** White for a dark surrounding, black for a light one, from the backdrop picture under this box (local canvas units). */
    private static final float LUM_CUT = 0.18f;      // above = light surrounding (black ink), below = dark (white ink)
    private static final float LUM_BAND = 0.10f;     // a surrounding this close to the cut is "unsure": it takes the screen-wide choice below
    private final float[] bdS = new float[25];
    private boolean ambBlack = true;                 // the one colour all unsure letters take (the sky's overall brightness decides, with a dead band so it never flickers)

    /** The sky's overall brightness (median of a grid over the sky above the scene) picks the colour for every unsure letter,
     *  so a mid-blue sky gives ONE colour to all its letters instead of a different one per line or per letter. */
    private void updateAmbient() {
        if (bdBmp == null) return;
        int w = bdBmp.getWidth(), h = bdBmp.getHeight();
        int yEnd = Math.max(4, Math.min(h - 1, (int) ((SC_T - bdY0) * BDQ)));
        float[] s = new float[16 * 10];
        int n = 0;
        for (int iy = 0; iy < 10; iy++) {
            for (int ix = 0; ix < 16; ix++) {
                int px = Math.min(w - 1, (int) (w * (ix + 0.5f) / 16f));
                int py = Math.min(yEnd, (int) (yEnd * (iy + 0.5f) / 10f));
                s[n++] = Sky.relLum(bdBmp.getPixel(px, py));
            }
        }
        java.util.Arrays.sort(s, 0, n);
        float m = s[n / 2];
        if (m > LUM_CUT + 0.02f) ambBlack = true;
        else if (m < LUM_CUT - 0.02f) ambBlack = false;
    }

    /** Brightness of the surrounding of a box. The MEDIAN of a 5x5 spread of samples, so a single star, sparkle or
     *  stripe of the sky texture can never tip one letter to the other colour. */
    private float lumAt(Matrix m, float x0, float y0, float x1, float y1) {
        bdP[0] = x0; bdP[1] = y0; bdP[2] = x1; bdP[3] = y0; bdP[4] = x0; bdP[5] = y1; bdP[6] = x1; bdP[7] = y1;
        m.mapPoints(bdP);
        float minX = Math.min(Math.min(bdP[0], bdP[2]), Math.min(bdP[4], bdP[6]));
        float maxX = Math.max(Math.max(bdP[0], bdP[2]), Math.max(bdP[4], bdP[6]));
        float minY = Math.min(Math.min(bdP[1], bdP[3]), Math.min(bdP[5], bdP[7]));
        float maxY = Math.max(Math.max(bdP[1], bdP[3]), Math.max(bdP[5], bdP[7]));
        int n = 0;
        for (int iy = 0; iy < 5; iy++) {
            for (int ix = 0; ix < 5; ix++) {
                float sx = minX + (maxX - minX) * (ix + 0.5f) / 5f;
                float sy = minY + (maxY - minY) * (iy + 0.5f) / 5f;
                int px = (int) (((sx - offX) / scale - bdX0) * BDQ);
                int py = (int) (((sy - offY) / scale - bdY0) * BDQ);
                px = Math.max(0, Math.min(bdBmp.getWidth() - 1, px));
                py = Math.max(0, Math.min(bdBmp.getHeight() - 1, py));
                float v = Sky.relLum(bdBmp.getPixel(px, py));
                int k = n++;
                while (k > 0 && bdS[k - 1] > v) { bdS[k] = bdS[k - 1]; k--; }   // insertion sort
                bdS[k] = v;
            }
        }
        return bdS[n / 2];
    }

    private int contrastAt(Matrix m, float x0, float y0, float x1, float y1) {
        return lumAt(m, x0, y0, x1, y1) > LUM_CUT ? Color.BLACK : Color.WHITE;
    }

    /** Same white / black rule for lines, icons and outlines: the colour for a box of the current canvas. */
    private int inkBox(Canvas c, int old, float x0, float y0, float x1, float y1) {
        if (bdBmp == null || sampling || (old != Sky.INK && old != Sky.LIGHT) || plain) return old;
        c.getMatrix(bdM);
        return contrastAt(bdM, x0, y0, x1, y1);
    }

    private void drawContrast(Canvas c, String t, float x, float y) {
        float total = paint.measureText(t);
        Paint.Align al = paint.getTextAlign();
        float start = al == Paint.Align.CENTER ? x - total / 2f : al == Paint.Align.RIGHT ? x - total : x;
        float cap = paint.getTextSize() * 0.72f;
        paint.setTextAlign(Paint.Align.LEFT);
        c.getMatrix(bdM);
        int len = t.length();
        float[] gxs = new float[len], advs = new float[len], lum = new float[len];
        for (int i = 0; i < len; i++) {
            if (t.charAt(i) == ' ') { lum[i] = Float.NaN; continue; }
            // the letter's place = the width of everything up to and including it, minus its own advance: this keeps the kerning
            // between it and the previous letter (measuring only the text before it lost pairs like T-A and W-I, leaving odd gaps)
            advs[i] = paint.measureText(t, i, i + 1);
            gxs[i] = start + paint.measureText(t, 0, i + 1) - advs[i];
            // the surrounding is read over a box about 4 letters wide and 2 letter-heights tall (not just the letter's own cell),
            // so the stripes of the sky texture average out and neighbouring letters get the same reading
            lum[i] = lumAt(bdM, gxs[i] - advs[i] * 1.5f, y - cap * 1.6f, gxs[i] + advs[i] * 2.5f, y + cap * 0.4f);
        }
        // ONE colour for the whole text (every word and letter of it): decided from the middle (median) of what is behind its
        // letters, never letter by letter, so a word can no longer be half white and half black. A surrounding right at the
        // white/black cut takes the screen-wide colour chosen from the sky's overall brightness.
        int n = 0;
        float[] sorted = new float[len];
        for (int i = 0; i < len; i++) if (!Float.isNaN(lum[i])) sorted[n++] = lum[i];
        if (n == 0) { paint.setTextAlign(al); return; }
        java.util.Arrays.sort(sorted, 0, n);
        float mid = (n % 2 == 1) ? sorted[n / 2] : 0.5f * (sorted[n / 2 - 1] + sorted[n / 2]);
        boolean black = Math.abs(mid - LUM_CUT) < LUM_BAND ? ambBlack : mid > LUM_CUT;
        int fill = black ? Color.BLACK : Color.WHITE;
        // letters that sit on a part of the picture where this colour reads poorly (WCAG ratio under 3:1) get a thin soft outline in the
        // opposite colour, so they stay readable without changing colour
        boolean[] weak = new boolean[len];
        boolean anyWeak = false;
        for (int i = 0; i < len; i++) {
            if (Float.isNaN(lum[i])) continue;
            float ratio = black ? (lum[i] + 0.05f) / 0.05f : 1.05f / (lum[i] + 0.05f);
            if (ratio < 3f) { weak[i] = true; anyWeak = true; }
        }
        if (anyWeak) {
            float top = y - paint.getTextSize() * 1.3f, bot = y + paint.getTextSize() * 0.5f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeWidth(Math.max(0.5f, paint.getTextSize() * 0.045f));
            paint.setColor(black ? 0x99FFFFFF : 0x99000000);
            int i = 0;
            while (i < len) {
                if (Float.isNaN(lum[i]) || !weak[i]) { i++; continue; }
                int j = i;
                while (j + 1 < len && (Float.isNaN(lum[j + 1]) || weak[j + 1])) j++;
                while (j > i && Float.isNaN(lum[j])) j--;
                int p0 = prevInk(lum, i);
                int nx = j + 1;
                while (nx < len && Float.isNaN(lum[nx])) nx++;
                float l = i == 0 ? start - paint.getTextSize() * 2f : (gxs[p0] + advs[p0] + gxs[i]) / 2f;
                float r = nx >= len ? start + total + paint.getTextSize() * 2f : (gxs[j] + advs[j] + gxs[nx]) / 2f;
                c.save();
                c.clipRect(l, top, r, bot);
                c.drawText(t, start, y, paint);
                c.restore();
                i = nx;
            }
            paint.setStyle(Paint.Style.FILL);
        }
        paint.setColor(fill);
        c.drawText(t, start, y, paint);
        paint.setTextAlign(al);
    }

    /** Index of the nearest letter (not a space) before i. */
    private static int prevInk(float[] lum, int i) {
        int p = i - 1;
        while (p > 0 && Float.isNaN(lum[p])) p--;
        return Math.max(p, 0);
    }

    /** Draws text and shrinks it if it would be wider than maxW. Returns the size used. */
    private float fitText(Canvas c, String t, float x, float y, float size, float minSize, int color,
                          Typeface tf, Paint.Align align, float spacingEm, float maxW) {
        paint.setTypeface(tf);
        paint.setLetterSpacing(spacingEm);
        paint.setTextSize(size);
        float w = paint.measureText(t);
        if (w > maxW) size = Math.max(minSize, size * maxW / w);
        text(c, t, x, y, size, color, tf, align, spacingEm);
        return size;
    }

    private float blockSize(String[] lines, float size, float minSize, float spacingEm, Typeface tf, float maxW) {
        paint.setTypeface(tf);
        paint.setLetterSpacing(spacingEm);
        float s = size;
        for (String ln : lines) {
            paint.setTextSize(size);
            float w = paint.measureText(ln);
            if (w > maxW) s = Math.min(s, Math.max(minSize, size * maxW / w));
        }
        return s;
    }

    private void textBlock(Canvas c, String pooled, float x, float firstY, float lineGap, float size, float minSize,
                           float spacingEm, Typeface tf, Paint.Align align, float maxW) {
        String[] lines = pooled.split("\\|");
        float s = blockSize(lines, size, minSize, spacingEm, tf, maxW);
        for (int i = 0; i < lines.length; i++) {
            text(c, lines[i].trim(), x, firstY + i * lineGap, s, sky.fgAt(firstY + i * lineGap), tf, align, spacingEm);
        }
    }

    /** Same as textBlock but the LAST line sits on lastY, so the block hugs whatever is below it. */
    private void textBlockUp(Canvas c, String pooled, float x, float lastY, float lineGap, float size, float minSize,
                             float spacingEm, Typeface tf, Paint.Align align, float maxW) {
        String[] lines = pooled.split("\\|");
        float s = blockSize(lines, size, minSize, spacingEm, tf, maxW);
        for (int i = 0; i < lines.length; i++) {
            float y = lastY - (lines.length - 1 - i) * lineGap;
            text(c, lines[i].trim(), x, y, s, sky.fgAt(y), tf, align, spacingEm);
        }
    }

    private static String clockText(int min, boolean h24) {
        int h = Math.floorMod(min / 60, 24), m = Math.floorMod(min, 60);
        if (h24) return String.format(Locale.US, "%02d:%02d", h, m);
        int h12 = (h % 12 == 0) ? 12 : h % 12;
        return String.format(Locale.US, "%d:%02d %s", h12, m, h < 12 ? "AM" : "PM");
    }

    private void hline(Canvas c, float x0, float x1, float y, float w) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(w);
        int base = sky.fgAt(y);
        if (bdBmp == null || sampling || (base != Sky.INK && base != Sky.LIGHT) || plain) {
            paint.setColor(base);
            c.drawLine(x0, y, x1, y, paint);
            return;
        }
        // drawn in short pieces, each white or black for what is behind it
        c.getMatrix(bdM);
        Matrix m = new Matrix(bdM);
        for (float a = x0; a < x1; a += 24f) {
            float b = Math.min(x1, a + 24f);
            float lv = lumAt(m, a - 12f, y - 6f, b + 12f, y + 6f);
            boolean blk = Math.abs(lv - LUM_CUT) < LUM_BAND ? ambBlack : lv > LUM_CUT;   // unsure stretches follow the sky's overall colour, so a line never splits
            paint.setColor(blk ? Color.BLACK : Color.WHITE);
            c.drawLine(a, y, b, y, paint);
        }
    }

    private void vline(Canvas c, float x, float y0, float y1, float w) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(w);
        paint.setColor(inkBox(c, sky.fgAt((y0 + y1) / 2f), x - 2f, y0, x + 2f, y1));
        c.drawLine(x, y0, x, y1, paint);
    }

    // ---------- main draw ----------

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        Calendar cal = Calendar.getInstance();
        ensureLook(cal);
        int availH = Math.max(1, h - bottomInset);
        scale = Math.min(w / DW, availH / DH);
        offX = (w - DW * scale) / 2f;
        offY = (availH - DH * scale) / 2f;

        int nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        updateSunTimes(cal);
        SkyArt.init(getContext());
        SkyArt.set(weatherOk ? wTemp : Float.NaN, rainLevel());
        sky = Sky.compute(pal, nowMin, sunriseMin, sunsetMin, cloudFrac());
        computeBody(nowMin);
        readNetwork();
        try { refreshBackdrop(cal, w, h, nowMin); } catch (Throwable ignored) { }

        c.drawColor(sky.cols[3]);
        c.save();
        c.translate(offX, offY);
        c.scale(scale, scale);
        float vx0 = -offX / scale, vy0 = -offY / scale;
        float vx1 = (w - offX) / scale, vy1 = (h - offY) / scale;
        viewX0 = vx0;
        viewX1 = vx1;
        try {
            sky.drawBackdrop(c, paint, vx0, vy0, vx1, vy1, SC_L, SC_T, SC_R, SC_B, bodyX, LAKE_Y);
            drawSkyObjects(c, cal);
            drawSceneLayer(c);
            drawWeatherFx(c);
            drawFrames(c);
        } catch (Exception ignored) { }
        try { drawLive(c, cal); } catch (Exception ignored) { }
        c.restore();
    }

    /** Sunrise and sunset for the chosen place, worked out on the phone (once a day and whenever the place changes). */
    private void updateSunTimes(Calendar cal) {
        double[] ll = Loc.get(getContext());
        String k = Texts.dayNumber(cal) + "|" + Math.round(ll[0] * 10) + "," + Math.round(ll[1] * 10);
        if (k.equals(sunKey)) return;
        sunKey = k;
        try {
            int[] st = Astro.sunTimes(cal, ll[0], ll[1]);
            if (st != null && st[1] > st[0]) {
                sunriseMin = st[0];
                sunsetMin = st[1];
                prefs.edit().putInt("sr", st[0]).putInt("ss", st[1]).apply();
            }
        } catch (Throwable ignored) { }
    }

    /** Float temperature for other drawing code (lock screen); NaN when the weather is not known yet. */
    public float temperatureOrNaN() {
        return weatherOk ? wTemp : Float.NaN;
    }

    private void computeBody(int nowMin) {
        body = Body.compute(getContext(), System.currentTimeMillis(), LAKE_Y, SC_T);
        isDay = body.sunUp;
        if (body.sunUp) {
            bodyX = body.sx;
            bodyY = body.sy;
            bodyR = body.sr;
        } else if (body.moonUp) {
            bodyX = body.mx;
            bodyY = body.my;
            bodyR = body.mr;
        } else {
            bodyX = 180f;
            bodyY = LAKE_Y + 60f;
            bodyR = 24f;
        }
        bodyUp = body.anyUp() && bodyY < LAKE_Y - 6f;
        sunBright = Body.brightness(weatherOk ? wTemp : Float.NaN);
    }

    private static boolean inTextZone(float x, float y) {
        return (x > 10f && x < 114f && y > 34f && y < 200f)      // clock digits
                || (x > 110f && x < 220f && y > 40f && y < 215f)  // date and sunrise / sunset
                || (x > 258f && x < 352f && y > 34f && y < 232f); // day name and slogans
    }

    // ---- a constellation drawn on the sky by a faint line that runs along its figure and then fades away ----
    private void drawConstellationTrace(Canvas c, float nightK, float cc) {
        if (nightK < 0.6f || cc > 0.55f || rainLevel() > 0) return;
        double[] ll = Loc.get(getContext());
        Constellations.Plan pl = Constellations.plan(System.currentTimeMillis(), ll[0], ll[1]);
        if (pl == null) return;
        float skyTop = SC_T + 20f, skyBot = Math.min(SC_T + 120f, LAKE_Y - 24f);
        float cy = skyBot - Math.max(0f, Math.min(1f, pl.meanAlt / 80f)) * (skyBot - skyTop);
        float half = 46f;
        cy = Math.max(skyTop + half * 0.6f, Math.min(skyBot - half * 0.4f, cy));
        float cx = SC_L + 60f + pl.fx * (SC_R - SC_L - 120f);
        if (bodyUp) {   // never on top of the moon or the sun: try other places along the sky
            for (int tries = 0; tries < 4; tries++) {
                boolean clash = Math.abs(cx - bodyX) < half + bodyR + 14f && Math.abs(cy - bodyY) < half + bodyR + 14f;
                if (!clash) break;
                float f2 = (pl.fx + 0.27f * (tries + 1)) % 1f;
                cx = SC_L + 60f + f2 * (SC_R - SC_L - 120f);
            }
            if (Math.abs(cx - bodyX) < half + bodyR + 14f && Math.abs(cy - bodyY) < half + bodyR + 14f) return;   // nowhere free: rest this turn
        }
        Constellations.drawTrace(c, paint, pl, cx, cy, 1f, 0.8f, 1.5f, MOON, 0.42f * nightK * (1f - cc));
    }

    private void drawSkyObjects(Canvas c, Calendar cal) {
        float cc = cloudFrac();
        float nightK = sky.nightK;
        int accent = sky.accent();
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);

        if (nightK > 0.15f) {
            int a = (int) (255 * nightK * (1f - cc * 0.8f));
            paint.setColor(MOON);
            paint.setAlpha(Math.max(0, Math.min(255, a)));
            for (int i = 0; i < starX.length; i++) {
                if (!pal.bleed && (starX[i] < SC_L || starX[i] > SC_R || starY[i] < SC_T + 6f || starY[i] > SC_T + 126f)) continue;
                if (starY[i] > LAKE_Y - 14f) continue;
                if (inTextZone(starX[i], starY[i])) continue;   // no star dots crossing the clock, date and slogans
                if (SkyArt.enabled && sky.art != null) {
                    // new sky: soft dots, with a slow twinkling four-point sparkle on every seventh star
                    if (i % 7 == 0) {
                        float tw = 0.65f + 0.35f * (float) Math.sin(System.currentTimeMillis() / 900.0 + i * 1.7);
                        paint.setAlpha(Math.max(0, Math.min(255, (int) (a * tw))));
                        SkyArt.sparkle(c, paint, starX[i], starY[i], 3.4f + starR[i] * 1.6f);
                        paint.setAlpha(Math.max(0, Math.min(255, a)));
                    } else {
                        c.drawCircle(starX[i], starY[i], starR[i], paint);
                    }
                } else {
                    c.drawCircle(starX[i], starY[i], starR[i], paint);
                }
            }
            paint.setAlpha(255);
            drawConstellationTrace(c, nightK, cc);
            if (SkyArt.engine && !sampling && nightK > 0.6f && cc < 0.4f) {
                // the sky engine's rare shooting star (clear nights only)
                SkyEngine.shootingStar(c, paint, System.currentTimeMillis(), SC_L + 20f, SC_R - 20f, SC_T + 10f, LAKE_Y - 70f,
                        (int) (255 * nightK * (1f - cc * 1.5f)));
                paint.setShader(null);
                paint.setStyle(Paint.Style.FILL);
            }
        }

        c.save();
        if (!pal.bleed) c.clipRect(SC_L, SC_T, SC_R, SC_B);

        if (body.moonUp) {
            // by day the moon is only a pale shape; at night it is clear. Nothing is drawn while it is below the horizon.
            int ma = body.sunUp ? (int) (110 * (1f - cc)) : (int) (255 * (1f - 0.5f * cc));
            if (ma > 8) Moon.draw(c, paint, body.mx, body.my, body.mr, body.phase, MOON, ma);
            paint.setAlpha(255);
        }
        if (body.sunUp) {
            float b = sunBright;
            // hot days: whiter disc and a wide glow; cold days: a paler, calmer sun
            int disc = accent;
            float white = Math.max(0f, b - 0.5f) * 1.2f;
            if (white > 0f) disc = Sky.blend(accent, 0xFFFFFFF2, Math.min(0.6f, white));
            float glow = Math.max(0f, b - 0.45f) * 1.8f;
            if (glow > 0f) {
                float rad = body.sr * (1.5f + 2.6f * b);
                int a0 = (int) (Math.min(1f, glow) * 140f * (1f - 0.8f * cc));
                paint.setShader(new RadialGradient(body.sx, body.sy, rad,
                        Color.argb(a0, Color.red(disc), Color.green(disc), Color.blue(disc)),
                        Color.argb(0, Color.red(disc), Color.green(disc), Color.blue(disc)), Shader.TileMode.CLAMP));
                c.drawCircle(body.sx, body.sy, rad, paint);
                paint.setShader(null);
            }
            float soft = b < 0.3f ? 0.72f + 0.28f * (b / 0.3f) : 1f;
            if (SkyArt.enabled && sky.art != null) {
                SkyArt.drawSun(c, paint, body.sx, body.sy, body.sr, (int) (255 * soft * (1f - 0.55f * cc)), Math.min(1f, sky.twiW * 1.2f), cc, weatherOk ? wTemp : Float.NaN);
            } else {
                paint.setColor(disc);
                paint.setAlpha((int) (255 * soft * (1f - 0.55f * cc)));
                c.drawCircle(body.sx, body.sy, body.sr, paint);
            }
            paint.setAlpha(255);
        }

        try {
            Decor.sky(c, paint, sky, look.fest == null ? null : look.fest.decor, SC_T, LAKE_Y, System.currentTimeMillis());
        } catch (Exception ignored) { }
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);

        int nCl = Math.round(cc * CLOUDS.length);
        int cloudCol = nightK > 0.5f ? Color.parseColor("#3A4150")
                : (cc > 0.6f ? Color.parseColor("#B3AD9F") : Color.parseColor("#F6F0E3"));
        for (int i = 0; i < nCl && i < CLOUDS.length; i++) {
            float cx = CLOUDS[i][0] * 360f;
            float cy = CLOUDS[i][1];
            float s = CLOUDS[i][2];
            float[][] shape = CLOUD_SHAPES[(int) CLOUDS[i][3]];
            if (SkyArt.enabled) {
                int kind = (SkyArt.rain > 0 || cc > 0.85f) ? SkyArt.CL_STORM : (cc > 0.55f ? SkyArt.CL_OVER : SkyArt.CL_FAIR);
                float w = 125f * s * (kind == SkyArt.CL_FAIR ? 1f : 1.25f);
                if (SkyArt.drawCloud(c, paint, kind, i * 3 + i / 2, cx, cy, w, (int) (240 * CLOUDS[i][4]), nightK)) continue;
            }
            paint.setColor(cloudCol);
            // clouds above the scene box are lighter so the clock and messages stay easy to read
            paint.setAlpha((int) (235 * CLOUDS[i][4]));
            for (float[] o : shape) {
                c.drawOval(new RectF(cx + (o[0] - o[2]) * s, cy + (o[1] - o[3]) * s,
                        cx + (o[0] + o[2]) * s, cy + (o[1] + o[3]) * s), paint);
            }
            paint.setAlpha(255);
        }
        c.restore();
    }

    /** City (layered): strings of festival lights hung from lamp post to lamp post along the street. */
    private void stackFestivalLights(Canvas c, float sl, float sr, float nightK) {
        String pl = look.fest.palette, dc = look.fest.decor;
        int a, b, tri = 0;
        if ("TRICOLOUR".equals(dc) || "TRICOLOUR".equals(pl)) { a = StringLights.GLOBE; b = StringLights.FILAMENT; tri = 1; }
        else if ("DIWALI".equals(pl)) { a = StringLights.LANTERN; b = StringLights.DROP; }
        else if ("CHRISTMAS".equals(pl)) { a = StringLights.STAR_B; b = StringLights.DROP; }
        else if ("EID".equals(pl)) { a = StringLights.MOON; b = StringLights.STAR_A; }
        else return;
        float lit = Math.max(Math.min(1f, Math.max(0f, (nightK - 0.1f) / 0.5f)), 0.35f);
        float[] g = SceneRender.geo(sl, sr, SC_T, SC_B);
        float[][] seg = {{118f, 265f}, {265f, 565f}, {565f, 930f}};
        long now = System.currentTimeMillis();
        for (int j = 0; j < seg.length; j++) {
            float xa = g[0] + seg[j][0] * g[3], xb = g[0] + seg[j][1] * g[3];
            float y = g[2] + 624f * g[3];
            StringLights.draw(c, getContext(), (j % 2 == 0) ? a : b, xa, y, xb, y, lit, tri, 0.5f * nightK, now);
        }
    }

    /**
     * Highway: the tea stall gets a string of lights under its roof on every festival; the shrine gets lights on three sides
     * (along the top and down both sides, like the notice board) on Diwali only.
     */
    private void highwayFestivalLights(Canvas c, float sl, float sr, float nightK) {
        String pl = look.fest.palette == null ? "" : look.fest.palette, dc = look.fest.decor == null ? "" : look.fest.decor;
        int a, b, tri = 0;
        if ("TRICOLOUR".equals(dc) || "TRICOLOUR".equals(pl)) { a = StringLights.GLOBE; b = StringLights.FILAMENT; tri = 1; }
        else if ("DIWALI".equals(pl)) { a = StringLights.LANTERN; b = StringLights.DROP; }
        else if ("CHRISTMAS".equals(pl)) { a = StringLights.STAR_B; b = StringLights.DROP; }
        else if ("EID".equals(pl)) { a = StringLights.MOON; b = StringLights.STAR_A; }
        else { a = StringLights.FILAMENT; b = StringLights.STAR_A; }
        float lit = Math.max(Math.min(1f, Math.max(0f, (nightK - 0.1f) / 0.5f)), 0.35f);
        float s = (sr - sl) / StackScene.W;
        float baseY = STACK_LINE - StackScene.H * s;     // design y of the scene picture's top
        long now = System.currentTimeMillis();
        float[] st = sceneLayers.stack.propBox(3);
        if (st != null) {
            float k = s;   // sprite px are scene px
            float x0 = sl + (st[0] + 6f) * s, x1 = sl + (st[0] + st[2] - 8f) * s, y = baseY + (st[1] + 15f) * s;
            StringLights.draw(c, getContext(), a, x0, y, x1, y, lit, tri, 0.5f * nightK, now);
        }
        float[] sh = sceneLayers.stack.propBox(4);
        if (sh != null && "DIWALI".equals(pl)) {
            float xl = sl + (sh[0] + 13f) * s, xr = sl + (sh[0] + 55f) * s;
            float yt = baseY + (sh[1] + 36f) * s, yb = baseY + (sh[1] + 66f) * s;
            StringLights.draw(c, getContext(), a, xl, yt, xr, yt, lit, 0, 0.5f * nightK, now);      // top
            StringLights.draw(c, getContext(), b, xl, yt, xl, yb, lit, 0, 0.5f * nightK, now);      // left side, hangs outward
            StringLights.draw(c, getContext(), b, xr, yb, xr, yt, lit, 0, 0.5f * nightK, now);      // right side
        }
    }

    /** Festivals: string lights hung roofline to roofline on the buildings of the scene. */
    private void drawFestivalLights(Canvas c, float sl, float sr, float nightK) {
        try {
            if (look.fest == null || sceneLayers == null) return;
            String sid = look.sceneId == null ? "" : look.sceneId;
            if (sceneLayers.stack != null) {
                if ("highway".equals(sid)) { highwayFestivalLights(c, sl, sr, nightK); return; }
                if (!"city".equals(sid)) return;
                stackFestivalLights(c, sl, sr, nightK);
                return;
            }
            boolean buildings = "city".equals(sid) || "taj".equals(sid) || "jalmahal".equals(sid)
                    || "mehrangarh".equals(sid) || "redfort".equals(sid) || "indiagate".equals(sid);
            if (!buildings) return;
            String pl = look.fest.palette, dc = look.fest.decor;
            int a, b, tri = 0;
            if ("TRICOLOUR".equals(dc) || "TRICOLOUR".equals(pl)) { a = StringLights.GLOBE; b = StringLights.FILAMENT; tri = 1; }
            else if ("DIWALI".equals(pl)) { a = StringLights.LANTERN; b = StringLights.DROP; }
            else if ("CHRISTMAS".equals(pl)) { a = StringLights.STAR_B; b = StringLights.DROP; }
            else if ("EID".equals(pl)) { a = StringLights.MOON; b = StringLights.STAR_A; }
            else return;
            float lit = Math.max(Math.min(1f, Math.max(0f, (nightK - 0.1f) / 0.5f)), 0.35f);
            float w = sr - sl;
            float wl = sceneLayers.art ? SceneRender.artGeo(sceneLayers, sl, sr, SC_T, SC_B)[4] : SceneRender.geo(sl, sr, SC_T, SC_B)[4];
            long now = System.currentTimeMillis();
            for (int j = 0; j < 2; j++) {
                float xa = sl + (0.08f + 0.46f * j) * w, xb = xa + 0.38f * w;
                float ya = SceneRender.skyline(sceneLayers, sl, sr, SC_T, SC_B, xa);
                float yb = SceneRender.skyline(sceneLayers, sl, sr, SC_T, SC_B, xb);
                if (Float.isNaN(ya) || Float.isNaN(yb) || ya > wl - 24f || yb > wl - 24f) continue;
                StringLights.draw(c, getContext(), j == 0 ? a : b, xa, ya + 10f, xb, yb + 10f, lit, tri, 0.5f * nightK, now);
            }
        } catch (Throwable ignored) { }
    }

    private void drawSceneLayer(Canvas c) {
        float cc = cloudFrac();
        float nightK = sky.nightK;
        c.save();
        // with the bleeding looks the scene runs to the real screen edges and its water carries on below the box
        final float sl = pal.bleed ? viewX0 - 1f : SC_L, sr = pal.bleed ? viewX1 + 1f : SC_R;
        final boolean art = sceneLayers != null && sceneLayers.art;
        final boolean city = "city".equals(look.sceneId);
        final boolean stackS = sceneLayers != null && sceneLayers.stack != null;
        final float stackScale = (sr - sl) / StackScene.W;
        final float sb = stackS ? STACK_LINE : SC_B;
        final float floorY = stackS ? STACK_LINE - (1f - CITY_EDGE) * StackScene.H * stackScale : SC_T + CITY_EDGE * (SC_B - SC_T);
        // the picture may reach above the box (layered scenes are scaled to fit the width): never cut its top
        final float picTop = stackS ? Math.min(SC_T, STACK_LINE - StackScene.H * stackScale) - 2f : SC_T;
        c.clipRect(sl, picTop, sr, stackS ? STACK_LINE + STACK_FADE : ((pal.bleed || art) ? SC_B + 76f : SC_B));
        if (sceneBmp != null) {
            float a = 1f - 0.55f * nightK - 0.2f * cc;
            float bl = 16f * nightK;
            float[] tint = pal.tint;
            ColorMatrix cm = new ColorMatrix(new float[]{
                    a * tint[0], 0, 0, 0, 0,
                    0, a * tint[1], 0, 0, 0,
                    0, 0, a * tint[2], 0, bl,
                    0, 0, 0, 1, 0});
            if ("INK".equals(pal.id)) {
                ColorMatrix grey = new ColorMatrix();
                grey.setSaturation(0f);
                grey.postConcat(cm);
                cm = grey;
            }
            layerPaint.setColorFilter(new ColorMatrixColorFilter(cm));
            Bitmap waterForExt = sceneBmp;
            if (sceneLayers != null) {
                // the reflection leans away from the sun or moon, and is longest when the body is low
                float lean = body.anyUp() ? -(bodyX - 180f) / 180f * 0.24f : 0f;
                float low = body.anyUp() ? Math.max(0f, Math.min(1f, (bodyY - 292f) / (LAKE_Y + 24f - 292f))) : 0f;
                float stretch = 1f + 0.45f * low;
                long nowMs = System.currentTimeMillis();
                Boats.Spot boat = null;
                if (!sceneLayers.dry && !art) {
                    float glintU = bodyUp ? (bodyX - sl) / (sr - sl) : -1f;
                    boat = Boats.pick(look.sceneId, hourKey(nowMs), glintU, sceneLayers.fg);
                }
                int save = c.saveLayer(sl, Math.min(SC_T - 30f, picTop), sr, stackS ? STACK_LINE + STACK_FADE : (art ? SC_B + 76f : SC_B), null);
                SceneRender.draw(c, sceneLayers, layerPaint, sl, sr, SC_T, sb, lean, stretch, nightK, nowMs, boat, city ? 0f : 46f);
                c.restoreToCount(save);
                waterForExt = sceneLayers.water;
                drawFestivalLights(c, sl, sr, nightK);
                if (sceneLayers.stack != null && started && !sampling) {
                    // traffic and people move: redraw just the scene 24 times a second while it is on screen
                    postInvalidateDelayed(1000 / 24, (int) (offX + sl * scale), (int) (offY + SC_T * scale),
                            (int) (offX + sr * scale) + 1, (int) (offY + (STACK_LINE + STACK_FADE + 4f) * scale) + 1);
                }
            } else {
                int save = c.saveLayer(sl, SC_T, sr, SC_B, null);
                c.drawBitmap(sceneBmp, null, new RectF(sl, SC_T, sr, SC_B), layerPaint);
                c.restoreToCount(save);
            }
            if (pal.bleed && !art && !city && sceneLayers.stack == null) {
                // the water carries on below the box (not a flipped copy: the picture's bottom is already a reflection)
                WaterExt.draw(c, waterForExt, layerPaint, sl, sr, SC_B, 76f, nightK, 0xFFF1E9D8,
                        sceneLayers != null && sceneLayers.dry);
            }
        }

        if (bodyUp && !(sceneLayers != null && sceneLayers.dry)) {
            final Runnable glintJob = new Runnable() { public void run() {
            // a broken, uneven, slowly shimmering glint on the water (never a tidy stack of stripes)
            int col = isDay ? sky.accent() : MOON;
            long step = System.currentTimeMillis() / 1500L;
            float gk = isDay ? 0.55f + 0.9f * sunBright : 1f;
            if (art) {
                // the sun or moon behind the mountains throws no glint on the lake
                float cover = SceneRender.landCover(sceneLayers, sl, sr, SC_T, SC_B, bodyX, bodyY, 7f);
                gk *= 1f - Math.min(1f, cover * 1.25f);
            }
            if (gk < 0.02f) return;
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(col);
            for (int i = 0; i < 16; i++) {
                float reach = 1f - i / 19f;
                float yy = LAKE_Y + 4f + i * 4.7f + hash(i, 0, step) * 1.4f;
                int n = 1 + (int) (hash(i, 1, 0) * 3f);
                float wander = (float) Math.sin(i * 0.9 + step * 0.35) * 5f * (0.4f + i / 16f);
                for (int j = 0; j < n; j++) {
                    float h = hash(i, 2 + j, step);
                    float w = (3f + hash(i, 6 + j, 0) * 24f) * (1f - 0.3f * cc) * reach * (art ? 0.62f : 1f) + 1.5f;
                    float x = bodyX + wander + (hash(i, 9 + j, step) - 0.5f) * 26f * (0.5f + i / 16f);
                    paint.setAlpha(Math.min(255, (int) (210 * gk * reach * (0.45f + 0.55f * h) * (1f - 0.5f * cc))));
                    float th = art ? 0.55f + h * 0.55f : 1.2f + h * 1.2f;
                    c.drawRect(x - w / 2f, yy, x + w / 2f, yy + th, paint);
                }
            }
            paint.setAlpha(255);
            } };
            final Runnable glintClipped = new Runnable() { public void run() {
                if (city) {
                    c.save();
                    c.clipRect(sl, SC_T, sr, floorY);
                    glintJob.run();
                    c.restore();
                } else {
                    glintJob.run();
                }
            } };
            if (sceneLayers != null) {
                SceneRender.clipToWater(c, sceneLayers, sl, sr, SC_T, SC_B, LAKE_Y - 2f, LAKE_Y + 100f, glintClipped);
            } else {
                glintClipped.run();
            }
        }
        if (art && sceneLayers != null && sceneBmp != null) {
            // the boat sits on top of the glint, behind nothing but the water
            long nowB = System.currentTimeMillis();
            float glintU = bodyUp ? (bodyX - sl) / (sr - sl) : -1f;
            float[] bs = SceneRender.boatSpot(hourKey(nowB), glintU);
            SceneRender.drawBoat(c, sceneLayers, layerPaint, sl, sr, SC_T, SC_B, bs[0], bs[1], nowB, nightK);
        }
        try {
            Decor.front(getContext(), c, paint, sky, look.fest == null ? null : look.fest.decor, LAKE_Y, System.currentTimeMillis(), look.sceneId, sceneLayers != null && sceneLayers.dry,
                    "city".equals(look.sceneId) ? floorY : 0f);
        } catch (Exception ignored) { }
        c.restore();
    }

    /** Changes once an hour: the boat takes a new place then. */
    private long hourKey(long ms) {
        Calendar cc = Calendar.getInstance();
        cc.setTimeInMillis(ms);
        return (long) Texts.dayNumber(cc) * 24L + cc.get(Calendar.YEAR) * 9000L + cc.get(Calendar.HOUR_OF_DAY);
    }

    private static float hash(int i, int j, long k) {
        double v = Math.sin(i * 12.9898 + j * 78.233 + k * 37.719) * 43758.5453;
        return (float) Math.abs(v - Math.floor(v));
    }

    private void drawWeatherFx(Canvas c) {
        float nightK = sky.nightK;
        c.save();
        c.clipRect(SC_L, SC_T, SC_R, SC_B);
        paint.setShader(null);
        float fs = fogStrength();
        if (fs > 0f) {
            int fog = nightK > 0.5f ? Color.parseColor("#2A2F3B") : Color.parseColor("#E4DCC8");
            int fr = Color.red(fog), fgc = Color.green(fog), fb = Color.blue(fog);
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new LinearGradient(0, SC_T, 0, SC_B,
                    Color.argb((int) (255 * fs * 0.72f), fr, fgc, fb),
                    Color.argb((int) (255 * fs), fr, fgc, fb), Shader.TileMode.CLAMP));
            c.drawRect(SC_L, SC_T, SC_R, SC_B, paint);
            paint.setShader(null);
            // drifting banks of haze, slow enough to be calm
            long tm = System.currentTimeMillis();
            for (int k = 0; k < 6; k++) {
                float ph = ((tm / (90000f + k * 13000f)) + k * 0.37f) % 1f;
                float cx = SC_L - 80f + ph * (SC_R - SC_L + 160f);
                float cy = SC_T + (k + 0.6f) / 6.4f * (SC_B - SC_T) + (float) Math.sin(tm / 5200.0 + k) * 5f;
                paint.setColor(Color.argb((int) (255 * Math.min(0.5f, fs * 0.55f)), fr, fgc, fb));
                c.drawOval(new RectF(cx - 130f, cy - 13f, cx + 130f, cy + 13f), paint);
            }
        }
        int rl = rainLevel();
        if (rl > 0) {
            int n = rl == 1 ? 40 : (rl == 2 ? 75 : 115);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(0.9f);
            paint.setColor(nightK > 0.5f ? MOON : Sky.INK);
            paint.setAlpha(120);
            for (int i = 0; i < n; i++) {
                float x0 = SC_L + rainX[i];
                float y0 = SC_T + rainY[i];
                c.drawLine(x0, y0, x0 - 2.5f, y0 + 9f, paint);
            }
            paint.setAlpha(255);
            paint.setStyle(Paint.Style.FILL);
        }
        if (snowing()) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(nightK > 0.5f ? MOON : Color.WHITE);
            for (int i = 0; i < 80; i++) {
                c.drawCircle(SC_L + rainX[i], SC_T + rainY[i], 1.5f, paint);
            }
        }
        c.restore();
    }

    private void drawFrames(Canvas c) {
        // no outer left / right lines; the horizontal lines run to the real screen edges; all lines 1.5 thick
        float L = viewX0, R = viewX1;
        float fl = 8f;   // the inner dividers keep their place
        hline(c, L, R, 582f, 1.5f);
        vline(c, 136f, 582f, 640f, 1.5f);
        hline(c, L, R, 640f, 1.5f);
        hline(c, L, R, 670f, 1.5f);
        hline(c, L, R, 728f, 1.5f);
        hline(c, L, R, 786f, 1.5f);
        vline(c, fl + 344f / 3f, 670f, 786f, 1.5f);
        vline(c, fl + 688f / 3f, 670f, 786f, 1.5f);
    }

    // ---------- the live content ----------

    private void drawLive(Canvas c, Calendar cal) {
        boolean h24 = DateFormat.is24HourFormat(getContext());
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int hh = h24 ? hour : ((hour % 12 == 0) ? 12 : hour % 12);
        int mm = cal.get(Calendar.MINUTE);
        int accent = sky.accent();

        text(c, String.format(Locale.US, "%02d", hh), 14, 108, 96, sky.fgAt(70f), bebas, Paint.Align.LEFT, 0f);
        text(c, String.format(Locale.US, "%02d", mm), 14, 182, 96, accent, bebas, Paint.Align.LEFT, 0f);

        int dateInk = sky.fgAt(88f);
        String mon = cal.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
        text(c, mon, 112, 68, 34, dateInk, bebas, Paint.Align.LEFT, 0.04f);
        text(c, String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), 112, 102, 34, dateInk, bebas, Paint.Align.LEFT, 0.04f);
        text(c, String.valueOf(cal.get(Calendar.YEAR)), 112, 136, 34, dateInk, bebas, Paint.Align.LEFT, 0.04f);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(dateInk);
        paint.setStrokeWidth(1.5f);
        c.drawLine(112, 148, 214, 148, paint);
        if (!h24) {
            text(c, hour < 12 ? "AM" : "PM", 112, 163, 10, accent, roboto, Paint.Align.LEFT, 0.25f);
        }
        // sunrise and sunset fill the lower part of the date column
        int sunInk = sky.fgAt(190f);
        text(c, "SUNRISE", 112, 184, 5.2f, sunInk, roboto, Paint.Align.LEFT, 0.25f);
        text(c, clockText(sunriseMin, h24), 112, 202, 17, sunInk, bebas, Paint.Align.LEFT, 0.04f);
        text(c, "SUNSET", 168, 184, 5.2f, sunInk, roboto, Paint.Align.LEFT, 0.25f);
        text(c, clockText(sunsetMin, h24), 168, 202, 17, sunInk, bebas, Paint.Align.LEFT, 0.04f);

        String day = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
        float size = 62f;
        paint.setTypeface(bebas);
        paint.setTextSize(size);
        paint.setLetterSpacing(0.02f);
        float wdt = paint.measureText(day);
        if (wdt > 182f) size = size * 182f / wdt;
        float cap = size * 0.70f;
        c.save();
        c.translate(266f + cap / 2f, 228f);
        c.rotate(-90f);
        text(c, day, 0, 0, size, sky.fgAt(130f), bebas, Paint.Align.LEFT, 0.02f);
        c.restore();

        // slogans beside the day name
        // each slogan sits right on top of its red rule, whatever the number of lines
        textBlockUp(c, look.slogan1, 344f, 93f, 8.6f, 6f, 4.2f, 0.23f, roboto, Paint.Align.RIGHT, 50f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accent);
        c.drawRect(322f, 100f, 344f, 102f, paint);
        textBlockUp(c, look.slogan2, 344f, 193f, 8.6f, 6f, 4.2f, 0.23f, roboto, Paint.Align.RIGHT, 50f);
        paint.setColor(accent);
        c.drawRect(322f, 200f, 344f, 202f, paint);

        fitText(c, look.tagline, 18f, 222f, 6.5f, 4.5f, sky.fgAt(222f), roboto, Paint.Align.LEFT, 0.4f, 205f);

        // scene corner messages and weather
        textBlock(c, look.cornerL, 18f, 257f, 9.4f, 6.5f, 4.5f, 0.46f, roboto, Paint.Align.LEFT, 100f);
        // the right corner now carries the weather, written exactly like the quotes
        String rightCorner = look.cornerR;
        if (weatherOk) rightCorner = (weatherLabel(!isDay).replace(' ', '|') + "|" + Math.round(wTemp) + "°C").toUpperCase(Locale.US);
        textBlock(c, rightCorner, 344f, 257f, 9.4f, 6.5f, 4.5f, 0.46f, roboto, Paint.Align.RIGHT, 120f);

        // greeting (a festival replaces it)
        String greet;
        if (look.fest != null && look.fest.greet.length() > 0) greet = look.fest.greet;
        else greet = hour < 12 ? "GOOD MORNING" : (hour < 17 ? "GOOD AFTERNOON" : (hour < 21 ? "GOOD EVENING" : "GOOD NIGHT"));
        // the four panel rows are all 58 units tall: the greeting row sits between the imaginary line (509) and 567
        c.save();
        c.translate(0f, 37f);
        fitText(c, greet, 18, 524, 40f, 18f, sky.fgAt(515f), bebas, Paint.Align.LEFT, 0.03f, 215f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accent);
        c.drawRect(18, 534, 54, 536.5f, paint);

        try { drawMusicButton(c); } catch (Exception ignored) { }
        c.restore();
        c.save();
        c.translate(0f, 29f);

        int docInk = sky.fgAt(580f);
        text(c, String.valueOf(cal.get(Calendar.DAY_OF_YEAR)), 16, 590, 42, docInk, bebas, Paint.Align.LEFT, 0f);
        text(c, "DAY OF THE YEAR", 16, 603, 5.6f, docInk, roboto, Paint.Align.LEFT, 0.25f);

        // note about this day, next to the day number
        String[] noteLines = look.dayNote.split("\\|");
        float ns = blockSize(noteLines, 6f, 4.2f, 0.27f, roboto, 34f);
        // the block sits right above the red rule, whatever the number of lines
        int nl = Math.min(4, noteLines.length);
        float lastBase = 588f;
        for (int i = 0; i < nl; i++) {
            text(c, noteLines[i].trim(), 96f, lastBase - (nl - 1 - i) * 8.2f, ns, docInk, roboto, Paint.Align.LEFT, 0.27f);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accent);
        c.drawRect(98f, 593f, 118f, 595f, paint);

        try { drawBattery(c, cal); } catch (Exception ignored) { }
        try { drawSignal(c); } catch (Exception ignored) { }
        c.restore();
        try { drawButtons(c); } catch (Exception ignored) { }
        plain = true;
        try { if (panelOpen) drawDeck(c); } catch (Exception ignored) { }
        plain = false;

        // the footer row is gone; only the version stays, below the grid on the right
        int foot = sky.fgAt(796f);
        text(c, "V6.8", 346f, 796f, 5.5f, foot, roboto, Paint.Align.RIGHT, 0.2f);
        try { drawInfo(c, cal); } catch (Exception ignored) { }
        plain = true;
        try { drawAppMenu(c); } catch (Exception ignored) { }
        plain = false;
    }

    /** The forecast, sun-and-moon or holiday card, drawn over the poster until it is tapped away. */
    private void drawInfo(Canvas c, Calendar cal) {
        if (infoMode == InfoCards.NONE) return;
        InfoCards.Data d = new InfoCards.Data();
        d.place = Loc.name(getContext());
        d.days = fcDays;
        for (int i = 0; i < fcDays; i++) {
            d.dayName[i] = fcName[i];
            d.code[i] = fcCode[i];
            d.max[i] = fcMax[i];
            d.min[i] = fcMin[i];
            d.rain[i] = fcRain[i];
        }
        d.sunrise = sunriseMin;
        d.sunset = sunsetMin;
        d.h24 = android.text.format.DateFormat.is24HourFormat(getContext());
        long nowMs = System.currentTimeMillis();
        double[] ll = Loc.get(getContext());
        try {
            int[] mt = Astro.moonTimes(cal, ll[0], ll[1]);
            d.moonrise = mt[0];
            d.moonset = mt[1];
            d.phase = Astro.moonPhase(nowMs);
            d.distKm = Astro.moonDistanceKm(nowMs);
            String[] mv = Astro.moonView(nowMs, ll[0], ll[1], cloudFrac(), d.h24);
            d.moonSee1 = mv[0];
            d.moonSee2 = mv[1];
        } catch (Throwable ignored) { }
        d.moonUp = body.moonUp;
        try {   // constellations: the ones up now if it is dark, otherwise the ones up at 9 pm tonight
            long when = nowMs;
            boolean darkNow = Astro.sunAlt(nowMs, ll[0], ll[1]) < -6.0;
            if (!darkNow) {
                Calendar t9 = (Calendar) cal.clone();
                t9.set(Calendar.HOUR_OF_DAY, 21);
                t9.set(Calendar.MINUTE, 0);
                t9.set(Calendar.SECOND, 0);
                when = t9.getTimeInMillis();
                if (when < nowMs) when = nowMs;
            }
            java.util.List<Constellations.C> vis = Constellations.visible(when, ll[0], ll[1], 14.0);
            final long wh = when;
            final double la = ll[0], lo = ll[1];
            java.util.Collections.sort(vis, new java.util.Comparator<Constellations.C>() {
                public int compare(Constellations.C x, Constellations.C y) {
                    return Double.compare(Constellations.meanAlt(y, wh, la, lo, 14.0), Constellations.meanAlt(x, wh, la, lo, 14.0));
                }
            });
            d.constDark = darkNow;
            d.consts = vis.toArray(new Constellations.C[0]);
            d.constWhen = when;
            d.lat = ll[0];
            d.lon = ll[1];
        } catch (Throwable ignored) { }
        if (infoMode == InfoCards.HOLIDAYS) d.holidays = Festivals.upcoming(cal, pack.festivals(), 6);
        InfoCards.draw(c, paint, infoMode, bebas, roboto, sky, viewX0, viewX1, d);
    }

    /** A clear-shell cassette in line art (label on top, tape window, bottom trapezoid), after a real tape. */
    private void drawCassette(Canvas c, float cx, float cy, float s, boolean spin, int ink, int accent) {
        float lw = 1.5f * Math.max(0.8f, s);
        paint.setShader(null);
        // clear plastic shell: a faint tint of the ink colour
        paint.setStyle(Paint.Style.FILL);
        paint.setColor((ink & 0x00FFFFFF) | 0x26000000);
        RectF shell = new RectF(cx - 30f * s, cy - 20f * s, cx + 30f * s, cy + 20f * s);
        c.drawRoundRect(shell, 3.5f * s, 3.5f * s, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(ink);
        paint.setStrokeWidth(lw * 1.15f);
        c.drawRoundRect(shell, 3.5f * s, 3.5f * s, paint);
        // paper label across the top
        RectF lab = new RectF(cx - 26f * s, cy - 17f * s, cx + 26f * s, cy - 8.5f * s);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFFEFE3C6);
        c.drawRect(lab, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(ink);
        paint.setStrokeWidth(lw * 0.8f);
        c.drawRect(lab, paint);
        paint.setStrokeWidth(lw * 0.55f);
        c.drawLine(cx - 22f * s, cy - 12.6f * s, cx + 14f * s, cy - 12.6f * s, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accent);
        c.drawRect(cx + 17f * s, cy - 15.6f * s, cx + 24f * s, cy - 10f * s, paint);
        // tape window with the two dark tape packs
        float ry = cy + 0.2f * s;
        float[] rx = {cx - 12.5f * s, cx + 12.5f * s};
        float[] pack = {8.4f * s, 6.6f * s};
        if (spin) {
            float ph = (float) ((System.currentTimeMillis() % 40000L) / 40000.0);
            pack[0] = (8.6f - 2.2f * ph) * s;
            pack[1] = (6.4f + 2.2f * ph) * s;
        }
        paint.setColor(0xFF3A2B24);
        for (int i = 0; i < 2; i++) c.drawCircle(rx[i], ry, pack[i], paint);
        paint.setColor(0xFF3A2B24);
        c.drawRect(cx - 12.5f * s, ry + 5.2f * s, cx + 12.5f * s, ry + 6.8f * s, paint);
        double base = spin ? ((System.currentTimeMillis() / 100L) % 60L) * 6.0 : 0.0;
        for (int i = 0; i < 2; i++) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFFE8DDBF);
            c.drawCircle(rx[i], ry, 4.7f * s, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(lw * 0.7f);
            paint.setColor(0xFF3A2B24);
            c.drawCircle(rx[i], ry, 4.7f * s, paint);
            paint.setStrokeWidth(lw * 0.9f);
            for (int k = 0; k < 6; k++) {
                double a = Math.toRadians(base + k * 60.0);
                c.drawLine(rx[i] + (float) Math.cos(a) * 2.1f * s, ry + (float) Math.sin(a) * 2.1f * s,
                        rx[i] + (float) Math.cos(a) * 3.0f * s, ry + (float) Math.sin(a) * 3.0f * s, paint);
            }
            paint.setStrokeWidth(lw * 0.7f);
            paint.setColor(ink);
            c.drawCircle(rx[i], ry, 2.1f * s, paint);
        }
        // bottom trapezoid with its holes
        Path tz = new Path();
        tz.moveTo(cx - 20f * s, cy + 19f * s);
        tz.lineTo(cx - 15f * s, cy + 9.5f * s);
        tz.lineTo(cx + 15f * s, cy + 9.5f * s);
        tz.lineTo(cx + 20f * s, cy + 19f * s);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(ink);
        paint.setStrokeWidth(lw * 0.8f);
        c.drawPath(tz, paint);
        paint.setStyle(Paint.Style.FILL);
        c.drawCircle(cx - 8f * s, cy + 14.5f * s, 1.5f * s, paint);
        c.drawCircle(cx + 8f * s, cy + 14.5f * s, 1.5f * s, paint);
        c.drawRect(cx - 3.2f * s, cy + 13f * s, cx - 1.2f * s, cy + 16f * s, paint);
        c.drawRect(cx + 1.2f * s, cy + 13f * s, cx + 3.2f * s, cy + 16f * s, paint);
        // corner screws
        float[][] sc = {{-26.5f, -17f}, {26.5f, -17f}, {-26.5f, 17f}, {26.5f, 17f}};
        for (float[] q : sc) c.drawCircle(cx + q[0] * s, cy + q[1] * s, 1.1f * s, paint);
    }

    private void drawMusicButton(Canvas c) {
        if (panelOpen) return;
        boolean playing = musicActive();
        int ink = inkBox(c, sky.fgAt(510f), 240f, 487f, 350f, 545f);
        drawCassette(c, 294f, 514f, 0.95f, playing, ink, sky.accent());
        if (playing) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(sky.accent());
            c.drawCircle(326f, 489f, 3f, paint);
        }
    }

    private void drawButtons(Canvas c) {
        float cw = 344f / 3f;
        float maxW = cw - 12f;
        int accent = sky.accent();
        for (int row = 0; row < 2; row++) {
            int ink = sky.fgAt(row == 0 ? 713f : 765f);
            for (int col = 0; col < 3; col++) {
                int idx = row * 3 + col;
                float cx = 8f + cw * (col + 0.5f);
                float baseline = row == 0 ? 701f : 759f;
                String word;
                String cap;
                if (custom[idx] != null && customLabel[idx] != null && customLabel[idx].length() > 0) {
                    word = customLabel[idx].toUpperCase(Locale.getDefault());
                    cap = "YOUR CHOICE";
                } else {
                    word = BUTTON_WORDS[idx];
                    cap = DEFAULT_CAPS[idx];
                }
                float size = 22f;
                paint.setTypeface(bebas);
                paint.setLetterSpacing(0.06f);
                paint.setTextSize(size);
                float w = paint.measureText(word);
                if (w > maxW) size = Math.max(11f, size * maxW / w);
                paint.setTextSize(size);
                CharSequence shown = word;
                if (paint.measureText(word) > maxW) {
                    TextPaint tp = new TextPaint(paint);
                    shown = TextUtils.ellipsize(word, tp, maxW, TextUtils.TruncateAt.END);
                }
                text(c, shown.toString(), cx, baseline, size, ink, bebas, Paint.Align.CENTER, 0.06f);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(accent);
                c.drawRect(cx - 9, baseline + 6, cx + 9, baseline + 8, paint);
                text(c, cap, cx, row == 0 ? 723f : 781f, 6.5f, ink, roboto, Paint.Align.CENTER, 0.31f);
            }
        }
    }

    private void drawSignal(Canvas c) {
        int ink = inkBox(c, sky.fgAt(626f), 8f, 612f, 262f, 636f);
        int accent = sky.accent();
        int skip = noNet ? 9 : 0;
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        for (int row = 0; row < 2; row++) {
            float frac = noNet ? 0f : (row == 0 ? wifiFrac : mobFrac);
            int filled = Math.round(frac * 40f);
            for (int i = skip; i < 40; i++) {
                paint.setColor(ink);
                paint.setAlpha(i < filled ? 255 : 38);
                float x = 16f + i * 6.2f;
                float y = 618f + row * 8f;
                c.drawRect(x, y, x + 5f, y + 6f, paint);
            }
        }
        paint.setAlpha(255);
        if (noNet) {
            // a tower made of little squares, crossed out
            float cell = 3f, pitch = 3.6f, x0 = 16f, y0 = 614f;
            paint.setColor(ink);
            for (int r = 0; r < TOWER.length; r++) {
                for (int k = 0; k < TOWER[r].length(); k++) {
                    if (TOWER[r].charAt(k) == '#') {
                        c.drawRect(x0 + k * pitch, y0 + r * pitch, x0 + k * pitch + cell, y0 + r * pitch + cell, paint);
                    }
                }
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.9f);
            paint.setColor(accent);
            c.drawLine(x0 - 2f, y0 - 1f, x0 + 9 * pitch + 1f, y0 + 7 * pitch + 1f, paint);
            paint.setStyle(Paint.Style.FILL);
            text(c, "NO TOWER", 278f, 624f, 5.8f, ink, roboto, Paint.Align.LEFT, 0.16f);
            text(c, "NO CONNECTION", 278f, 632f, 5.8f, ink, roboto, Paint.Align.LEFT, 0.16f);
        } else {
            text(c, wifiLabel, 278f, 624f, 5.8f, ink, roboto, Paint.Align.LEFT, 0.16f);
            text(c, mobLabel, 278f, 632f, 5.8f, ink, roboto, Paint.Align.LEFT, 0.16f);
        }
    }

    private String batteryMessage(Calendar cal, boolean charging) {
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        String key = Texts.dayNumber(cal) + "|" + (batteryPct / 5) + "|" + charging + "|" + (hour / 4) + "|" + look.key;
        if (!key.equals(batKey)) {
            batKey = key;
            batText = Texts.battery(batteryPct, charging, pack.quotes("batCharging"), pack.quotes("batFull"),
                    pack.quotes("batHigh"), pack.quotes("batMid"), pack.quotes("batLow"), pack.quotes("batCrit"),
                    Texts.dayNumber(cal), hour);
        }
        return batText;
    }

    private void drawBattery(Canvas c, Calendar cal) {
        float x = 146, y = 562, w = 52, h = 22;
        boolean charging = pluggedType != 0;
        int ink = inkBox(c, sky.fgAt(575f), 146f, 562f, 198f, 584f);
        int accent = sky.accent();

        paint.setShader(null);
        paint.setColor(ink);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.8f);
        c.drawRoundRect(x, y, x + w, y + h, 3, 3, paint);
        paint.setStyle(Paint.Style.FILL);
        c.drawRect(x + w, y + 6, x + w + 4, y + h - 6, paint);

        int segs = Math.max(batteryPct > 0 ? 1 : 0, Math.round(batteryPct / 20f));
        paint.setColor(accent);
        float sw = (w - 8) / 5f;
        for (int i = 0; i < segs && i < 5; i++) {
            float sx = x + 3 + i * sw;
            c.drawRect(sx, y + 3, sx + sw - 2, y + h - 3, paint);
        }

        if (charging) {
            float cx = x + w / 2f, top = y + 2f;
            Path bolt = new Path();
            bolt.moveTo(cx + 3f, top);
            bolt.lineTo(cx - 6f, top + 11f);
            bolt.lineTo(cx - 0.5f, top + 11f);
            bolt.lineTo(cx - 3f, top + 18f);
            bolt.lineTo(cx + 6f, top + 7f);
            bolt.lineTo(cx + 0.5f, top + 7f);
            bolt.close();
            paint.setColor(sky.colorAt(575f));
            paint.setStyle(Paint.Style.FILL_AND_STROKE);
            paint.setStrokeWidth(1.6f);
            c.drawPath(bolt, paint);
            paint.setColor(ink);
            paint.setStyle(Paint.Style.FILL);
            c.drawPath(bolt, paint);
        }

        text(c, batteryPct + "%", 342, 592, 44, ink, bebas, Paint.Align.RIGHT, 0f);

        String status;
        if (charging) {
            String src = pluggedType == BatteryManager.BATTERY_PLUGGED_WIRELESS ? "WIRELESS"
                    : (pluggedType == BatteryManager.BATTERY_PLUGGED_USB ? "USB" : "CABLE");
            status = "CHARGING • " + src;
        } else {
            status = "ON BATTERY";
        }
        if (tempC >= 0) status += " • " + Math.round(tempC) + "°C";
        // the accent colour is only used when it stands out from what is behind it; otherwise the status follows the white / black rule
        int stCol = ink;
        if (charging) {
            boolean accentOk = true;
            if (bdBmp != null && !sampling) {
                c.getMatrix(bdM);
                float bl = lumAt(bdM, 146f, 585f, 260f, 596f);
                float al = Sky.relLum(accent);
                accentOk = Math.abs(bl - al) > 0.22f;
            }
            if (accentOk) stCol = accent;
        }
        text(c, status, 146, 593, 6.2f, stCol, roboto, Paint.Align.LEFT, 0.16f);

        // a short message that matches the charge
        String msg = "“" + batteryMessage(cal, charging) + "”";
        paint.setTypeface(roboto);
        paint.setLetterSpacing(0.04f);
        float qs = 6f;
        paint.setTextSize(qs);
        float qw = paint.measureText(msg);
        if (qw > 204f) qs = Math.max(4.2f, qs * 204f / qw);
        paint.setTextSkewX(-0.2f);
        text(c, msg, 146f, 604f, qs, ink, roboto, Paint.Align.LEFT, 0.04f);
        paint.setTextSkewX(0f);
    }

    // ---------- the cassette deck ----------

    // ---------- the boombox player ----------

    private float[] speakerDots;
    private android.graphics.DashPathEffect ringDash;
    private long volUntil = 0L;
    private boolean volDrag = false;

    private float volume() {
        try {
            int mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            return mx <= 0 ? 0f : audio.getStreamVolume(AudioManager.STREAM_MUSIC) / (float) mx;
        } catch (Throwable t) {
            return 0.5f;
        }
    }

    private void setVolume(float f) {
        try {
            int mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(Math.max(0f, Math.min(1f, f)) * mx), 0);
        } catch (Throwable ignored) { }
    }

    private void volumeFromX(float x) {
        // dial runs from x = 68 (silent) to x = 300 (full) in design units
        setVolume((x - 68f) / 232f);
        volUntil = SystemClock.uptimeMillis() + 5000L;
        invalidate();
    }

    private boolean inVolumeStrip(float x, float y) {
        return inRect(x, y, 50f, 411f, 310f, 439f);
    }

    private void keyFace(Canvas c, int i, boolean pressed, int topCol, int botCol, int edge) {
        float l = KEY_L[i], t = KEY_T + (pressed ? 1.5f : 0f), r = l + KEY_WS[i], b = KEY_B + (pressed ? 0.5f : 0f);
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(pressed ? 40 : 100, 0, 0, 0));
        c.drawRoundRect(new RectF(l + 1f, t + 2.5f, r + 1f, b + 2.5f), 3.5f, 3.5f, paint);
        paint.setShader(new LinearGradient(0f, t, 0f, b, topCol, botCol, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(l, t, r, b), 3.5f, 3.5f, paint);
        paint.setShader(null);
        paint.setColor(Color.argb(pressed ? 0 : 60, 255, 255, 255));
        c.drawRoundRect(new RectF(l + 3f, t + 1.8f, r - 3f, t + 4.8f), 1.5f, 1.5f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(edge);
        c.drawRoundRect(new RectF(l, t, r, b), 3.5f, 3.5f, paint);
    }

    private void tri(Canvas c, float x0, float y0, float x1, float y1, float x2, float y2, int col) {
        Path p = new Path();
        p.moveTo(x0, y0);
        p.lineTo(x1, y1);
        p.lineTo(x2, y2);
        p.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(col);
        c.drawPath(p, paint);
    }

    private void speaker(Canvas c, float cx, float cy, boolean pulse, long now, int rim, int ringCol) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(64, 0, 0, 0));
        c.drawCircle(cx + 1f, cy + 2.5f, 45f, paint);
        paint.setShader(new LinearGradient(cx - 44f, cy - 44f, cx + 44f, cy + 44f,
                new int[]{0xFFF3DC9A, 0xFFB98C3A, 0xFF7A5A22}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, 44f, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(0xFF5B3D12);
        c.drawCircle(cx, cy, 44f, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(rim);
        c.drawCircle(cx, cy, 40f, paint);
        paint.setColor(0xFF141415);
        c.drawCircle(cx, cy, 38f, paint);
        if (speakerDots == null) {
            java.util.ArrayList<Float> pts = new java.util.ArrayList<Float>();
            for (float yy = -35f; yy <= 35f; yy += 3f) {
                for (float xx = -35f; xx <= 35f; xx += 3f) {
                    if (xx * xx + yy * yy <= 35.5f * 35.5f) {
                        pts.add(xx);
                        pts.add(yy);
                    }
                }
            }
            speakerDots = new float[pts.size()];
            for (int i = 0; i < speakerDots.length; i++) speakerDots[i] = pts.get(i);
        }
        c.save();
        c.translate(cx, cy);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(1.5f);
        paint.setColor(0xFF3B3B3D);
        c.drawPoints(speakerDots, paint);
        paint.setStrokeCap(Paint.Cap.BUTT);
        c.restore();
        if (pulse) {
            if (ringDash == null) ringDash = new android.graphics.DashPathEffect(new float[]{6f, 5f}, 0f);
            paint.setPathEffect(ringDash);
            paint.setStrokeWidth(2f);
            for (int k = 0; k < 3; k++) {
                float u = ((now % 1200L) / 1200f + k / 3f) % 1f;
                paint.setColor(ringCol);
                paint.setAlpha((int) (240 * (1f - u)));
                c.drawCircle(cx, cy, 11f + u * 25f, paint);
            }
            paint.setPathEffect(null);
            paint.setAlpha(255);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new android.graphics.RadialGradient(cx - 3f, cy - 3f, 12f, 0xFFD9D9D9, 0xFF555555, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, 9f, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0.8f);
        paint.setColor(Color.BLACK);
        c.drawCircle(cx, cy, 9f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void knob(Canvas c, float x, float y) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(100, 0, 0, 0));
        c.drawCircle(x, y + 1f, 5f, paint);
        paint.setShader(new android.graphics.RadialGradient(x - 1.5f, y - 1.5f, 7f, 0xFF666666, 0xFF151515, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, 5f, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(0xFFEEEEEE);
        c.drawLine(x, y, x + 3.5f, y - 3.5f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawDeck(Canvas c) {
        boolean playing = musicActive();
        long now = System.currentTimeMillis();
        boolean volMode = SystemClock.uptimeMillis() < volUntil;
        int acc = sky.accent();
        // a slightly richer, deeper shade of the day's theme colour
        int top = Sky.blend(acc, Color.WHITE, 0.14f), bot = Sky.blend(acc, Color.BLACK, 0.42f);
        int rim = Sky.blend(acc, Color.BLACK, 0.55f), edge = Sky.blend(acc, Color.BLACK, 0.70f);
        int hi = Sky.blend(acc, Color.WHITE, 0.30f), lo = Sky.blend(acc, Color.BLACK, 0.35f);
        int mark = Sky.blend(acc, Color.WHITE, 0.38f);
        int light = Sky.LIGHT;
        float vol = volume();

        c.save();
        c.translate(DECK_L, DECK_T);
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(110, 0, 0, 0));
        c.drawRoundRect(new RectF(2f, 4f, 338f, 154f), 12f, 12f, paint);
        paint.setShader(new LinearGradient(0f, 0f, 0f, 150f, top, bot, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0f, 0f, 336f, 150f), 12f, 12f, paint);
        paint.setShader(null);
        paint.setColor(Color.argb(75, 255, 255, 255));
        c.drawRoundRect(new RectF(6f, 4f, 330f, 7f), 1.5f, 1.5f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        paint.setColor(edge);
        c.drawRoundRect(new RectF(0f, 0f, 336f, 150f), 12f, 12f, paint);

        // tuner strip: the FM / AM dial, whose marker is the volume
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF0C0C0D);
        c.drawRoundRect(new RectF(38f, 12f, 298f, 40f), 2f, 2f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0.8f);
        paint.setColor(Color.BLACK);
        c.drawRoundRect(new RectF(38f, 12f, 298f, 40f), 2f, 2f, paint);
        if (!volMode) {
            text(c, "FM", 43f, 22f, 6f, light, roboto, Paint.Align.LEFT, 0f);
            text(c, "AM", 43f, 34f, 6f, light, roboto, Paint.Align.LEFT, 0f);
            for (int i = 0; i < 10; i++) {
                float x = 62f + 220f * i / 9f;
                text(c, String.valueOf(87 + i * 2), x, 22f, 5f, light, roboto, Paint.Align.CENTER, 0f);
                text(c, String.valueOf(530 + i * 110), x, 34f, 5f, light, roboto, Paint.Align.CENTER, 0f);
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(0.4f);
            paint.setColor(light);
            for (int i = 0; i <= 45; i++) {
                float x = 56f + 232f * i / 45f;
                c.drawLine(x, i % 5 == 0 ? 24.5f : 25.5f, x, i % 5 == 0 ? 27.5f : 26.5f, paint);
            }
        } else {
            text(c, "VOL", 44f, 33f, 11f, light, bebas, Paint.Align.LEFT, 0.05f);
            int lit = Math.round(vol * 20f);
            paint.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 20; i++) {
                int col = i >= 16 ? mark : 0xFFF4C542;
                paint.setColor(col);
                paint.setAlpha(i < lit ? 255 : 46);
                float h = 6f + i * 0.45f;
                c.drawRoundRect(new RectF(78f + i * 10.4f, 37f - h, 85.5f + i * 10.4f, 37f), 1f, 1f, paint);
            }
            paint.setAlpha(255);
        }
        float mx = 56f + 232f * vol;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(mark);
        c.drawRect(mx - 0.9f, 14f, mx + 0.9f, 38f, paint);
        c.drawRect(mx - 2.2f, 13f, mx + 2.2f, 15.2f, paint);

        knob(c, 14f, 22f);
        knob(c, 26f, 22f);
        knob(c, 318f, 22f);

        // speakers and side tabs
        speaker(c, 54f, 92f, playing || volMode, now, rim, mark);
        speaker(c, 282f, 92f, playing || volMode, now, rim, mark);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0f, 78f, 0f, 100f, 0xFFF3DC9A, 0xFF9C7430, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(2f, 78f, 11f, 100f), 2f, 2f, paint);
        c.drawRoundRect(new RectF(325f, 78f, 334f, 100f), 2f, 2f, paint);
        paint.setShader(null);

        // cassette door: the arrow bar runs while a song plays
        paint.setColor(0xFF25100E);
        c.drawRoundRect(new RectF(102f, 42f, 234f, 102f), 3f, 3f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0.8f);
        paint.setColor(Color.BLACK);
        c.drawRoundRect(new RectF(102f, 42f, 234f, 102f), 3f, 3f, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF111111);
        c.drawRoundRect(new RectF(106f, 45f, 230f, 53f), 1f, 1f, paint);
        double phase = now / 190.0;
        for (int i = 0; i < 3; i++) {
            float al = playing ? 0.25f + 0.75f * (float) Math.max(0.0, Math.cos(phase - i * 0.9)) : 0.18f;
            paint.setColor(0xFFF4C542);
            paint.setAlpha((int) (255 * al));
            float x = 150f + i * 13f;
            Path ap = new Path();
            ap.moveTo(x, 46.3f);
            ap.lineTo(x + 5f, 49f);
            ap.lineTo(x, 51.7f);
            ap.close();
            c.drawPath(ap, paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(0xFFF4C542);
        paint.setAlpha(playing ? 180 : 50);
        c.drawLine(120f, 49f, 146f, 49f, paint);
        paint.setAlpha(playing ? 70 : 30);
        c.drawLine(192f, 49f, 218f, 49f, paint);
        paint.setAlpha(255);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF3A1511);
        c.drawRoundRect(new RectF(110f, 56f, 226f, 96f), 3f, 3f, paint);
        paint.setColor(0xFFCFC3A3);
        c.drawRoundRect(new RectF(118f, 60f, 218f, 90f), 3f, 3f, paint);
        paint.setColor(0xFFEFE7D3);
        c.drawRect(124f, 62.5f, 212f, 71.5f, paint);
        paint.setColor(acc);
        c.drawRect(128f, 66f, 198f, 67.3f, paint);
        paint.setColor(0xFF2B2A28);
        c.drawRoundRect(new RectF(134f, 74f, 202f, 87f), 6.5f, 6.5f, paint);

        float frac = ((now / 60000L) % 12L) / 12f;
        float[] rx = {146f, 190f};
        float ry = 80.5f;
        float[] tape = {6.4f - 1.8f * frac, 3.8f + 1.8f * frac};
        double spin = playing ? (now % 900L) / 900.0 * 360.0 : 20.0;
        for (int i = 0; i < 2; i++) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFF5A4632);
            c.drawCircle(rx[i], ry, tape[i], paint);
            paint.setColor(0xFFE8E2D0);
            c.drawCircle(rx[i], ry, 3.4f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(0.9f);
            paint.setColor(0xFF2B2A28);
            for (int k = 0; k < 6; k++) {
                double a = Math.toRadians(spin + k * 60.0);
                c.drawLine(rx[i] + (float) Math.cos(a) * 1.2f, ry + (float) Math.sin(a) * 1.2f,
                        rx[i] + (float) Math.cos(a) * 3.1f, ry + (float) Math.sin(a) * 3.1f, paint);
            }
        }
        paint.setStrokeWidth(0.8f);
        paint.setColor(0xFF5A4632);
        c.drawLine(rx[0], ry + tape[0], rx[1], ry + tape[1], paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(110f, 56f, 226f, 96f, Color.argb(80, 255, 255, 255), Color.argb(0, 255, 255, 255),
                Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(110f, 56f, 226f, 96f), 3f, 3f, paint);
        paint.setShader(null);
        c.restore();

        // keys (absolute coordinates: they are also the touch targets)
        int darkTop = 0xFF4A4A47, darkBot = 0xFF1C1C1A;
        keyFace(c, 0, false, darkTop, darkBot, 0xFF111111);
        keyFace(c, 1, playing, hi, lo, 0xFF111111);
        keyFace(c, 2, false, darkTop, darkBot, 0xFF111111);
        keyFace(c, 3, false, darkTop, darkBot, 0xFF111111);
        float cy = (KEY_T + KEY_B) / 2f;
        float c0 = KEY_L[0] + KEY_WS[0] / 2f, c1 = KEY_L[1] + KEY_WS[1] / 2f;
        float c2 = KEY_L[2] + KEY_WS[2] / 2f, c3 = KEY_L[3] + KEY_WS[3] / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(light);
        c.drawRect(c0 - 6.5f, cy - 5f, c0 - 4.5f, cy + 5f, paint);
        tri(c, c0 + 6.5f, cy - 5f, c0 - 3.5f, cy, c0 + 6.5f, cy + 5f, light);
        if (playing) {
            c.drawRect(c1 - 5.5f, cy - 5f, c1 - 2f, cy + 5f, paint);
            c.drawRect(c1 + 2f, cy - 5f, c1 + 5.5f, cy + 5f, paint);
        } else {
            tri(c, c1 - 4f, cy - 6f, c1 - 4f, cy + 6f, c1 + 6f, cy, light);
        }
        c.drawRect(c2 + 4.5f, cy - 5f, c2 + 6.5f, cy + 5f, paint);
        tri(c, c2 - 6.5f, cy - 5f, c2 + 3.5f, cy, c2 - 6.5f, cy + 5f, light);
        tri(c, c3 - 6f, cy + 1f, c3 + 6f, cy + 1f, c3, cy - 6f, light);
        c.drawRect(c3 - 6f, cy + 3f, c3 + 6f, cy + 5.2f, paint);
    }
}
