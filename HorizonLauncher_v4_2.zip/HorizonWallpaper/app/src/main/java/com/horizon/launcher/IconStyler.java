package com.horizon.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;

/**
 * Turns an app's own icon into the poster print style: ink, cream and red dots in a coarse halftone,
 * done on the phone from the installed icon. Nothing is copied or shipped with the launcher.
 */
final class IconStyler {

    private IconStyler() { }

    /** Size of the converted bitmap in pixels; it is shown enlarged without smoothing so the dots stay chunky. */
    static final int S = 72;

    private static final int[][] BAYER = {{0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};

    static Bitmap style(Drawable d, int ink, int cream, int red) {
        Bitmap src = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(src);
        boolean mono = false;
        if (Build.VERSION.SDK_INT >= 33 && d instanceof AdaptiveIconDrawable) {
            Drawable m = ((AdaptiveIconDrawable) d).getMonochrome();
            if (m != null) {
                // the themed (one-colour) layer is the cleanest source; its visible part is the middle two thirds
                int pad = Math.round(S * 0.25f);
                m.setBounds(-pad, -pad, S + pad, S + pad);
                m.draw(c);
                mono = true;
            }
        }
        if (!mono) {
            d.setBounds(0, 0, S, S);
            d.draw(c);
        }
        int[] px = new int[S * S];
        src.getPixels(px, 0, S, 0, 0, S, S);
        for (int y = 0; y < S; y++) {
            for (int x = 0; x < S; x++) {
                int p = px[y * S + x];
                int a = Color.alpha(p);
                float th = (BAYER[y & 3][x & 3] + 0.5f) / 16f;
                int out;
                if (mono) {
                    out = (a / 255f) > th ? ink : cream;
                } else if (a < 110) {
                    out = cream;
                } else {
                    int r = Color.red(p), g = Color.green(p), b = Color.blue(p);
                    int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
                    float v = mx / 255f;
                    float s = mx == 0 ? 0f : (mx - mn) / (float) mx;
                    float lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f;
                    if (s > 0.45f && v > 0.35f) {
                        out = th < 0.85f - 0.2f * (1f - lum) ? red : cream;
                    } else {
                        out = lum > th ? cream : ink;
                    }
                }
                px[y * S + x] = out;
            }
        }
        src.recycle();
        Bitmap res = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        res.setPixels(px, 0, S, 0, 0, S, S);
        return res;
    }

    /** Fallback tile: a cream square with the app's first letter in ink and a red bar. */
    static Bitmap letterTile(String label, int ink, int cream, int red, Typeface tf) {
        Bitmap bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(cream);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(tf);
        p.setColor(ink);
        p.setTextSize(S * 0.62f);
        p.setTextAlign(Paint.Align.CENTER);
        String ch = label == null || label.length() == 0 ? "?" : label.substring(0, 1).toUpperCase();
        c.drawText(ch, S / 2f, S * 0.66f, p);
        p.setColor(red);
        c.drawRect(S * 0.32f, S * 0.78f, S * 0.68f, S * 0.84f, p);
        return bmp;
    }
}
