package com.horizon.launcher;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Everything that changes from one day to the next: colour scheme, festival, scene and the text of every message spot. */
final class Look {

    static final String[] SCENE_IDS = {"lake", "peaks", "dunes", "sea", "city", "palms"};
    static final String[] SCENE_NAMES = {"LAKE", "PEAKS", "DESERT", "ISLANDS", "CITY", "PALMS"};
    static final String[] PREVIEW_NAMES = {"DIWALI", "INDEPENDENCE DAY", "REPUBLIC DAY", "GANDHI JAYANTI",
            "MAKAR SANKRANTI", "HOLI", "EID AL-FITR", "CHRISTMAS", "NEW YEAR", "PONGAL", "GURU NANAK JAYANTI"};

    Palette pal = Palette.HORIZON;
    Festivals.Fest fest;
    String sceneId = "lake";
    String slogan1 = "", slogan2 = "", tagline = "", cornerL = "", cornerR = "", dayNote = "";
    int dayN;
    ContentPack pack;
    String key = "";
    long previewUntil = 0L;

    static Look compute(Context ctx, ContentPack pack, Calendar cal) {
        SharedPreferences sp = ctx.getSharedPreferences("horizon", Context.MODE_PRIVATE);
        Look l = new Look();
        l.pack = pack;
        l.dayN = Texts.dayNumber(cal);

        boolean festOn = sp.getBoolean("fest", true);
        long until = sp.getLong("pv_until", 0L);
        String pvName = sp.getString("pv_name", null);
        if (pvName != null && System.currentTimeMillis() < until) {
            l.fest = Festivals.byName(pvName);
            if (l.fest != null) l.previewUntil = until;
        } else if (festOn) {
            l.fest = Festivals.find(cal, pack.festivals());
        }
        String want0 = sp.getString("pal", "AUTO");
        if (l.fest != null) {
            l.pal = Palette.byId(l.fest.palette);
        } else if ("AUTO".equals(want0)) {
            l.pal = Palette.DAILY[Math.floorMod(l.dayN, Palette.DAILY.length)];
        } else {
            l.pal = Palette.byId(want0);
        }

        List<String> ids = new ArrayList<String>();
        for (String s : SCENE_IDS) ids.add(s);
        for (String[] ps : pack.scenes()) {
            if (!ids.contains(ps[0])) ids.add(ps[0]);
        }
        String want = sp.getString("scene", "AUTO");
        if (!"AUTO".equals(want) && ids.contains(want)) {
            l.sceneId = want;
        } else {
            l.sceneId = ids.get(Math.floorMod(l.dayN, ids.size()));
        }

        int n = l.dayN;
        l.slogan1 = Texts.pick(Texts.SLOGAN1, pack.quotes("slogan1"), n, 1);
        l.slogan2 = Texts.pick(Texts.SLOGAN2, pack.quotes("slogan2"), n, 2);
        l.tagline = Texts.pick(Texts.TAGLINE, pack.quotes("tagline"), n, 3);
        l.cornerL = Texts.pick(Texts.CORNER_L, pack.quotes("cornerL"), n, 4);
        l.cornerR = Texts.pick(Texts.CORNER_R, pack.quotes("cornerR"), n, 5);
        l.dayNote = Texts.dayNote(cal, pack.quotes("dayNote"));

        if (l.fest != null) {
            if (l.fest.s1.length() > 0) l.slogan1 = l.fest.s1;
            if (l.fest.s2.length() > 0) l.slogan2 = l.fest.s2;
            if (l.fest.tagline.length() > 0) l.tagline = l.fest.tagline;
        }
        l.key = n + "|" + l.pal.id + "|" + l.sceneId + "|" + (l.fest == null ? "-" : l.fest.name);
        return l;
    }

    /** All scene choices as {id, name}: built-in first, then imported ones. */
    static List<String[]> allScenes(ContentPack pack) {
        List<String[]> out = new ArrayList<String[]>();
        for (int i = 0; i < SCENE_IDS.length; i++) out.add(new String[]{SCENE_IDS[i], SCENE_NAMES[i]});
        for (String[] ps : pack.scenes()) {
            boolean dup = false;
            for (String[] o : out) {
                if (o[0].equals(ps[0])) dup = true;
            }
            if (!dup) out.add(new String[]{ps[0], ps[1]});
        }
        return out;
    }
}
