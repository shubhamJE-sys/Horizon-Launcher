package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.io.InputStream;

/**
 * The layered Classic scenes ("city" and "highway"): every layer is a transparent picture already placed in the
 * 1364x944 picture space, drawn back to front, with traffic and people that move between the layers.
 *
 * City:    far skyline + towers, lit windows (night), shop-houses, road with street furniture; vehicles drive on the
 *          road, people walk on the pavement.
 * Highway: mountains + valley, road on the slope, foreground trees; vehicles drive between the road and the trees
 *          (the trees at the sides of the road cover them as they enter and leave).
 * A rare Meteor motorbike overtakes everything (every 40 to 60 minutes, or on a double tap on the scene).
 */
final class StackScene {

    static final int W = 1364, H = 944;
    private static final long PERIOD = 50L * 60000L;
    private static final long METEOR_MS = 3000L;
    private static volatile long manualStart = -1000000L;

    /** Set by the caller for the length of one draw: a lamp festival (decor DIYA) puts small diyas along the highway's road edge. */
    static volatile boolean diyaRoad = false;
    private Bitmap[] dyB, flB;
    private float[][] dyTip;
    final boolean city;
    private boolean oasis;   // the desert oasis: dunes, palms and a pool, with a caravan camp and a fire in front
    private Bitmap b0, bWin, b1, b1r, b2;   // b1r: the highway's guardrail and wall, drawn in front of the traffic
    private Bitmap[] veh = new Bitmap[0];
    private Bitmap[] ppl = new Bitmap[0];
    private Bitmap[] props = new Bitmap[0];
    private Bitmap meteor;
    private float lampX = 0.97f, lampY = 0.46f;   // where the Meteor's headlight sits in its picture

    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint plain = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint fade = new Paint();
    private Paint tint;

    private StackScene(boolean city) { this.city = city; }

    private static Bitmap dec(Context ctx, String name) {
        try {
            InputStream in = ctx.getAssets().open(name);
            try { return BitmapFactory.decodeStream(in); } finally { in.close(); }
        } catch (Throwable t) {
            return null;
        }
    }

    private static Bitmap[] decAll(Context ctx, String prefix, int n) {
        Bitmap[] out = new Bitmap[n];
        for (int i = 0; i < n; i++) out[i] = dec(ctx, prefix + i + ".webp");
        return out;
    }

    static StackScene load(Context ctx, String id) {
        boolean city = "city".equals(id);
        StackScene s = new StackScene(city);
        if ("oasis".equals(id)) {
            s.oasis = true;
            s.b0 = dec(ctx, "sc_oa_0.webp");
            s.b1 = dec(ctx, "sc_oa_1.webp");
            s.b1r = dec(ctx, "sc_oa_g.webp");   // the sand ridge in front of the pool, the camp stands on it
            s.b2 = dec(ctx, "sc_oa_2.webp");    // palms and rocks at the two sides, in front of the camp
            // 0 fire pit, 1 the burning bonfire, 4-7 people, 8-11 camels
            s.props = new Bitmap[14];
            s.props[0] = dec(ctx, "oa_pit.webp");
            s.props[1] = dec(ctx, "oa_fire.webp");   // the same pit with its bonfire burning
            s.props[12] = dec(ctx, "oa_wind.webp");    // a gust of sand blowing low over the ground
            s.props[13] = dec(ctx, "oa_devil.webp");   // a sand whirlwind far out on the dunes
            for (int i = 0; i < 4; i++) { s.props[4 + i] = dec(ctx, "oa_p" + i + ".webp"); s.props[8 + i] = dec(ctx, "oa_c" + i + ".webp"); }
            if (s.b0 == null || s.b1 == null) return null;
            return s;
        }
        if (city) {
            s.b0 = dec(ctx, "sc_city_0.webp");
            s.bWin = dec(ctx, "sc_city_win.webp");
            s.b1 = dec(ctx, "sc_city_1.webp");
            s.b2 = dec(ctx, "sc_city_2.webp");
            s.veh = decAll(ctx, "spr_cv", 18);
            s.ppl = decAll(ctx, "spr_cp", 12);
        } else {
            s.b0 = dec(ctx, "sc_hw_0.webp");
            s.b1 = dec(ctx, "sc_hw_1.webp");
            s.b1r = dec(ctx, "sc_hw_1r.webp");
            s.b2 = dec(ctx, "sc_hw_2.webp");
            s.veh = decAll(ctx, "spr_hv", 8);
            s.props = decAll(ctx, "spr_hp", 5);
            s.dyB = decAll(ctx, "diya_", 6);
            s.flB = decAll(ctx, "flame_", 6);
            s.dyTip = new float[6][2];
            for (int i = 0; i < 6; i++) {
                s.dyTip[i][0] = 0.5f; s.dyTip[i][1] = 0.1f;
                Bitmap d = s.dyB[i];
                if (d == null) continue;
                outer:
                for (int y = 0; y < d.getHeight(); y++) {
                    long sx = 0; int n = 0;
                    for (int x = 0; x < d.getWidth(); x++) if ((d.getPixel(x, y) >>> 24) > 140) { sx += x; n++; }
                    if (n > 0) { s.dyTip[i][0] = sx / (float) n / d.getWidth(); s.dyTip[i][1] = (y + 2) / (float) d.getHeight(); break outer; }
                }
            }
        }
        // the highway has its own hero bike (the Meteor with the leather-jacket rider); the old one stays in the city scenes
        s.meteor = city ? dec(ctx, "spr_meteor0.webp") : dec(ctx, "spr_meteor1.webp");
        if (s.meteor == null) s.meteor = dec(ctx, "spr_meteor0.webp");
        s.lampX = city ? 0.97f : 0.83f;
        s.lampY = city ? 0.46f : 0.43f;
        if (s.b0 == null || s.b1 == null) return null;
        return s;
    }

    /** Double tap on the scene: the Meteor rides past now (ignored while one is already riding). */
    static boolean trigger(long now) {
        if (now - manualStart < METEOR_MS + 4000L) return false;
        manualStart = now;
        return true;
    }

    // ---------- drawing ----------

    /**
     * Width-fit and anchored at the bottom line: the picture is never cropped or enlarged. Whatever height the box has
     * above the picture is sky. Below the line the ground carries on (the last rows of every layer stretched) and fades out.
     */
    void draw(Canvas c, Paint tinted, float l, float r, float top, float bottom, float nightK, long now) {
        float s = (r - l) / W;
        float ty = bottom - H * s;
        float ext = 23f;   // fade length below the line: from the line (0%) to the middle of the greeting text (100%)
        tint = tinted;
        Paint bp = new Paint(tinted);
        bp.setFilterBitmap(true);
        c.save();
        // nothing may show below the end of the fade (the highway layers carry extra ground rows beyond it)
        c.clipRect(l - 100000f, top - 100000f, r + 100000f, bottom + ext);
        c.translate(l, ty);
        c.scale(s, s);
        if (oasis) drawOasis(c, bp, nightK, now); else if (city) drawCity(c, bp, nightK, now); else drawHighway(c, bp, nightK, now);
        // the ground below the line carries on as a mirrored copy of the scene's own bottom (real texture, no streaks);
        // it dissolves into the panel colour below
        if (city) {
            c.save();
            c.clipRect(0f, H - 0.5f, W, H + ext / s);
            c.scale(1f, -1f, 0f, H);
            for (Bitmap b : new Bitmap[]{b0, b1, b1r, b2}) {
                if (b != null) c.drawBitmap(b, 0f, 0f, bp);
            }
            c.restore();
        }
        // (the highway's layers carry 100 rows of real ground below the line, so it needs no mirrored copy)
        c.restore();
        // one rule for every scene: linear 0% at the imaginary line to 100% at the middle of the greeting text;
        // below that only the sky / panel colour shows
        fade.setShader(new LinearGradient(0f, bottom, 0f, bottom + ext, 0x00000000, 0xFF000000, Shader.TileMode.CLAMP));
        fade.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        c.drawRect(l, bottom, r, bottom + ext + 1f, fade);
        fade.setShader(null);
    }

    private void layer(Canvas c, Paint p, Bitmap b) {
        if (b != null) c.drawBitmap(b, 0f, 0f, p);
    }

    // ---------- the desert oasis ----------

    /** One camp sprite: standing on (x, base), `h` tall (the width follows), turned to face the other way when `flip`. */
    private void campSprite(Canvas c, Paint bp, Bitmap b, float x, float base, float h, boolean flip) {
        if (b == null) return;
        float w = h * b.getWidth() / b.getHeight();
        c.save();
        if (flip) c.scale(-1f, 1f, x, base);
        c.drawBitmap(b, null, new android.graphics.RectF(x - w / 2f, base - h, x + w / 2f, base), bp);
        c.restore();
    }

    static final float OA_FIRE_X = 682f, OA_BASE = 929f;

    private void drawOasis(Canvas c, Paint bp, float night, long now) {
        layer(c, bp, b0);   // far dunes
        sandDevil(c, bp, night, now);   // behind the palms and the pool
        layer(c, bp, b1);   // palms, pool and the sand in front
        layer(c, bp, b1r);  // sand ridge the camp stands on
        Bitmap pit = props[0];
        if (pit == null) return;
        // sizes follow the art brief: a sitting adult about half of a sitting camel, a child 70% of an adult, the fire pit about
        // as wide as a camel is long (ring 110 px)
        float ph = 110f * 427f / 880f, pw = 110f;
        // the travellers sit round the fire facing it, on the sand ridge, a little apart and at different depths
        campSprite(c, bp, props[5], 500f, 918f, 74f, false);
        campSprite(c, bp, props[4], 575f, 928f, 80f, false);
        campSprite(c, bp, props[6], 800f, 929f, 78f, true);
        campSprite(c, bp, props[7], 868f, 921f, 54f, true);
        // the fire pit
        campSprite(c, bp, pit, OA_FIRE_X, OA_BASE, ph, false);
        // fire: lit from dusk, out in full daylight
        float lit = Math.max(0f, Math.min(1f, (night - 0.1f) / 0.4f));
        float fk = fireLevel(now);   // 1 burning ... 0 blown out (only embers)
        if (lit > 0f) {
            float flick = 0.88f + 0.12f * (float) Math.sin(now / 90.0) * (float) Math.sin(now / 230.0 + 1.0);
            float fy = OA_BASE - ph * 0.45f;
            // warm light on the sand, the people and the camels (goes with the flame)
            if (fk > 0.01f) glowAt(c, OA_FIRE_X, fy - 10f, 190f * (0.95f + 0.05f * flick), lit * fk * flick, 255, 150, 50, 1.6f, 0.9f);
            Bitmap fire = props[1];
            if (fire != null && fk > 0.01f) {
                // the burning bonfire is the unlit pit's own picture with the fire in it: it fades in over the pit from dusk
                // (same stone ring, so the ring width 880 of the pit = 941 of the fire picture), and breathes a little
                float u = ph / 427f * 880f / 941f;
                float fh = fire.getHeight() * u * (0.985f + 0.03f * flick);
                plain.setAlpha((int) (255 * lit * fk));
                campSprite(c, plain, fire, OA_FIRE_X, OA_BASE, fh, false);
                plain.setAlpha(255);
            }
            // embers: when the wind has put the flame out only a dull red glow and a few live coals are left
            float em = lit * (1f - fk);
            if (em > 0.01f) {
                float pulse = 0.75f + 0.25f * (float) Math.sin(now / 700.0) * (float) Math.sin(now / 1300.0 + 2.0);
                glowAt(c, OA_FIRE_X, fy + 12f, 52f, em * 0.8f * pulse, 255, 70, 20, 1.5f, 0.55f);
                for (int i = 0; i < 9; i++) {
                    float ex = OA_FIRE_X - 32f + hash01(i, 21) * 64f, ey = OA_BASE - 36f + hash01(i, 22) * 16f;
                    float tw = 0.4f + 0.6f * (float) Math.abs(Math.sin(now / (500.0 + 90.0 * i) + i));
                    plain.setColor(0xFFFF6A2A);
                    plain.setAlpha((int) (255 * em * tw));
                    c.drawRect(ex, ey, ex + 2.2f, ey + 1.6f, plain);
                }
                plain.setAlpha(255);
            }
        }
        sandGust(c, bp, night, now);   // a gust passes low over the sand, in front of the camp
        layer(c, bp, b2);   // foreground palms, bushes and rock at the two sides
        // the camels lie in front of those palms, at the two ends of the camp
        campSprite(c, bp, props[8], 300f, 932f, 126f, false);
        campSprite(c, bp, props[10], 1070f, 930f, 118f, true);
        // with the fire out, the whole camp goes dark (only over pixels already drawn: the sky is not touched)
        float dark = lit * (1f - fk) * 0.4f;
        if (dark > 0.01f) {
            plain.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
            plain.setColor(0xFF04070F);
            plain.setAlpha((int) (255 * dark));
            c.drawRect(0f, 0f, W, H + 80f, plain);
            plain.setAlpha(255);
            plain.setXfermode(null);
        }
    }

    /**
     * How strongly the bonfire burns (1 = burning, 0 = blown out). Every 70 s the gust passes over the camp (13.5 s into it):
     * the flame is blown out in 1.5 s, only embers glow for 12 s, then it catches again over 4 s. Still pictures (now = 0): burning.
     */
    private static float fireLevel(long now) {
        if (now <= 0L) return 1f;
        float t = now % 70000L;
        if (t < 13500f) return 1f;
        if (t < 15000f) return 1f - (t - 13500f) / 1500f;
        if (t < 27000f) return 0f;
        if (t < 31000f) {
            float u = (t - 27000f) / 4000f;
            return u * u * (3f - 2f * u);
        }
        return 1f;
    }

    // --- sand in the wind (static pictures draw nothing: now == 0 on the lock screen) ---
    private static float hash01(int i, int j) {
        double v = Math.sin(i * 12.9898 + j * 78.233) * 43758.5453;
        return (float) (v - Math.floor(v));
    }

    /** One sand grain, about one screen pixel (1.6 picture px), warm sand colour, dimmer at night. */
    private void grain(Canvas c, float x, float y, float a, float night) {
        float k = 1f - 0.55f * night;
        plain.setColor(0xFFE6C27A);
        plain.setAlpha((int) (255 * Math.max(0f, Math.min(1f, a)) * k));
        c.drawRect(x, y, x + 1.6f, y + 1.6f, plain);
    }

    /** A gust: a drift of sand streaks crosses the ground left to right (30 s of every 70 s) with loose grains riding in it. */
    private void sandGust(Canvas c, Paint bp, float night, long now) {
        if (now <= 0L || props.length < 13 || props[12] == null) return;
        float g = (now % 70000L) / 30000f;
        if (g >= 1f) return;
        float env = (float) Math.sin(Math.PI * g);
        env = env * env;
        Bitmap w = props[12];
        float h = 150f, wd = h * w.getWidth() / w.getHeight();
        float x = -wd + g * (W + wd + 120f);
        float base = 915f;
        plain.setAlpha((int) (255 * 0.8f * env * (1f - 0.35f * night)));
        c.drawBitmap(w, null, new android.graphics.RectF(x, base - h, x + wd, base), plain);
        plain.setAlpha(255);
        long cycle = now / 70000L;
        for (int i = 0; i < 90; i++) {
            float u = hash01(i, (int) cycle), v = hash01(i + 300, 7);
            float gx = x + u * wd + (float) Math.sin(now / 420.0 + i) * 6f + ((now % 70000L) / 1000f) * 18f * (0.3f + v);
            float gy = base - 8f - v * (h * 0.9f) + (float) Math.sin(now / 300.0 + i * 1.7) * 3f;
            if (gx < -4f || gx > W + 4f) continue;
            grain(c, gx, gy, env * (0.45f + 0.55f * hash01(i, 99)), night);
        }
    }

    /** A sand whirlwind wanders slowly along the far dunes (100 s of every 240 s), grains spiralling up round it. */
    private void sandDevil(Canvas c, Paint bp, float night, long now) {
        if (now <= 0L || props.length < 14 || props[13] == null) return;
        float d = (now % 240000L) / 100000f;
        if (d >= 1f) return;
        float env = (float) Math.pow(Math.sin(Math.PI * d), 0.6);
        Bitmap t = props[13];
        float h = 250f * (0.9f + 0.1f * env), w = h * t.getWidth() / t.getHeight();
        float cx = 150f + d * 1000f, base = 590f;
        float sway = (float) Math.sin(now / 1100.0) * 3f;
        plain.setAlpha((int) (255 * 0.95f * env * (1f - 0.35f * night)));
        c.save();
        c.translate(cx + sway, base);
        c.scale(1f + 0.02f * (float) Math.sin(now / 260.0), 1f);
        c.drawBitmap(t, null, new android.graphics.RectF(-w / 2f, -h, w / 2f, 0f), plain);
        c.restore();
        plain.setAlpha(255);
        for (int i = 0; i < 70; i++) {
            float ph = hash01(i, 5);
            float u = ((now / 3200f) + ph) % 1f;            // 0 at the foot, 1 at the top
            float ang = now / 380f * (1.3f - 0.5f * u) + ph * 6.283f;
            float rad = (10f + 80f * u) * (0.6f + 0.8f * hash01(i, 11));
            float gx = cx + sway + (float) Math.cos(ang) * rad;
            float gy = base - u * h * 1.05f + (float) Math.sin(ang) * rad * 0.18f;
            grain(c, gx, gy, env * (u < 0.1f ? u * 10f : 1f - 0.5f * u), night);
        }
    }

    private void drawCity(Canvas c, Paint bp, float night, long now) {
        layer(c, bp, b0);
        if (bWin != null && night > 0.05f) {
            plain.setAlpha((int) (255 * Math.min(1f, night * 1.15f)));
            c.drawBitmap(bWin, 0f, 0f, plain);
            plain.setAlpha(255);
        }
        layer(c, bp, b1);
        if (now > 0L) {
            people(c, bp, now, night);
        }
        layer(c, bp, b2);
        lamps(c, night, new float[][]{{118, 627}, {265, 627}, {565, 627}, {930, 627}}, 70f);
        if (now > 0L) {
            traffic(c, bp, now, night, 918f, 938f, false, 0.34f, 1.0f, 913f, 0f, 0f);
        }
    }

    /** The centre line of the highway's road slopes down to the right (picture px): y = HW_LINE + HW_SLOPE * x / W. */
    private static final float HW_LINE = 796f, HW_SLOPE = 9f;

    private void drawHighway(Canvas c, Paint bp, float night, long now) {
        layer(c, bp, b0);
        // the two farm houses on the far slope: one lit window each at night, a single picture pixel (the trees of the next layer still cover it)
        if (night > 0.12f) {
            plain.setColor(0xFFFFC860);
            plain.setAlpha((int) (255 * Math.min(1f, (night - 0.12f) * 1.5f)));
            c.drawRect(900f, 492f, 901f, 493f, plain);
            c.drawRect(971f, 490f, 972f, 491f, plain);
            plain.setAlpha(255);
        }
        layer(c, bp, b1);
        // roadside: milestone, tea stall, prayer flags, shrine and a warning sign on the verge, behind the traffic
        if (props.length >= 5) {
            propOnVerge(c, bp, props[2], 250f);
            propOnVerge(c, bp, props[3], 470f);
            propOnVerge(c, bp, props[1], 650f);
            propOnVerge(c, bp, props[4], 860f);
            propOnVerge(c, bp, props[0], 1060f);
        }
        roadsideLights(c, night, now);
        if (diyaRoad) roadDiyas(c, bp, night, now, true);   // far edge of the road (vehicles drive in front of these)
        if (now > 0L) {
            // vehicles heading right keep to the upper half of the road, oncoming traffic to the lower half,
            // the Meteor rides on the centre line (all follow the slope of the line)
            traffic(c, bp, now, night, HW_LINE - 11f, HW_LINE + 14f, true, 0.22f, 0.54f, HW_LINE, HW_SLOPE, HW_SLOPE);
        }
        layer(c, bp, b1r);   // guardrail: vehicles drive behind it
        if (diyaRoad) roadDiyas(c, bp, night, now, false);   // near edge, in front of the rail feet
        layer(c, bp, b2);    // foreground trees at the sides
    }

    /**
     * Lamp festivals: small diyas stand along BOTH edges of the road (far = top edge, near = rail side), one between every two posts of the guardrail, each as wide as a post.
     * (posts are about 62.7 px apart, the first gap's middle is at x = 228; the asphalt edge runs from y = 822 at x = 230 to 834 at x = 1137)
     */
    private void roadDiyas(Canvas c, Paint bp, float night, long now, boolean far) {
        if (dyB == null) return;
        float glowK = Math.max(0.25f, Math.min(1f, night * 1.3f));
        int k = 0;
        for (float x = 228f - 62.7f * 3; x < W + 20f; x += 62.7f, k++) {
            int si = (k + (far ? 3 : 0)) % 6;
            Bitmap dy = dyB[si], fl = flB[(int) ((now / 130L + k * 3 + (far ? 2 : 0)) % 6)];
            if (dy == null || fl == null) continue;
            float edge = far ? 0f : 822f + (x - 230f) * (12f / 907f);
            float dw = 16f, dh = dw * dy.getHeight() / dy.getWidth();
            float base = far ? 761f + 8f * x / W + 4f : edge + 9f;   // far edge: on the top edge of the asphalt, just under the kerb
            float flick = 0.85f + 0.15f * (float) Math.sin(now / 95.0 + k * 1.7) * (float) Math.sin(now / 210.0 + k);
            float left = x - dw / 2f, top = base - dh;
            c.drawBitmap(dy, null, new android.graphics.RectF(left, top, left + dw, base), bp);
            float tx = left + dyTip[si][0] * dw, ty = top + dyTip[si][1] * dh;
            float fh = 12f * (0.9f + 0.1f * flick), fw = fh * fl.getWidth() / fl.getHeight();
            glow.setShader(new RadialGradient(tx, ty - fh * 0.4f, fh * 1.8f, new int[]{argb(150 * flick * glowK, 255, 210, 110), argb(60 * flick * glowK, 255, 190, 70), 0},
                    new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(tx, ty - fh * 0.4f, fh * 1.8f, glow);
            glow.setShader(null);
            c.drawBitmap(fl, null, new android.graphics.RectF(tx - fw / 2f, ty - fh + 1f, tx + fw / 2f, ty + 1f), plain);
        }
    }

    /** Where a roadside prop's picture sits in the scene (top-left corner), the same as propOnVerge draws it. */
    private float[] propOrigin(Bitmap b, float cx) {
        if (b == null) return new float[]{cx, 0f};
        return new float[]{cx - b.getWidth() / 2f, 761f + 8f * cx / W - b.getHeight()};
    }

    private void glowAt(Canvas c, float x, float y, float rad, float k, int r, int g, int b, float sx, float sy) {
        glow.setShader(new RadialGradient(x, y, rad, new int[]{argb(200 * k, r, g, b), argb(80 * k, r, g, b), 0},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.save();
        c.translate(x, y);
        c.scale(sx, sy);
        c.translate(-x, -y);
        c.drawCircle(x, y, rad, glow);
        c.restore();
        glow.setShader(null);
    }

    /** Night lights of the tea stall (its hanging bulb and its tube light) and the shrine's two diyas. (The festival string lights are drawn by PosterView.) */
    private void roadsideLights(Canvas c, float night, long now) {
        if (props.length < 5 || props[3] == null || props[4] == null) return;
        float[] st = propOrigin(props[3], 470f);   // tea stall
        float[] sh = propOrigin(props[4], 860f);   // shrine
        float k = night < 0.06f ? 0f : Math.min(1f, night * 1.2f);
        if (k <= 0f) return;
        // tea stall: the bulb hanging from the ceiling (warm) and the tube light (long, cool white)
        glowAt(c, st[0] + 76f, st[1] + 18f, 34f, k, 255, 214, 130, 1f, 1f);
        glowAt(c, st[0] + 54f, st[1] + 22f, 30f, k * 0.9f, 235, 245, 255, 2.2f, 0.55f);
        // shrine: one glow for each diya
        float f1 = 1f, f2 = 1f;
        if (now > 0L) {
            f1 = 0.88f + 0.12f * (float) Math.sin(now / 130.0);
            f2 = 0.88f + 0.12f * (float) Math.sin(now / 150.0 + 2.0);
        }
        glowAt(c, sh[0] + 24f, sh[1] + 56f, 16f, k * f1, 255, 190, 90, 1f, 1f);
        glowAt(c, sh[0] + 42.3f, sh[1] + 56.5f, 16f, k * f2, 255, 190, 90, 1f, 1f);
    }

    /** Box {left, top, width, height} (scene px) of the roadside prop k as drawn on the verge, or null. k: 3 tea stall, 4 shrine. */
    float[] propBox(int k) {
        if (city || props == null || k >= props.length || props[k] == null) return null;
        float cx = k == 3 ? 470f : (k == 4 ? 860f : -1f);
        if (cx < 0f) return null;
        float[] o = propOrigin(props[k], cx);
        return new float[]{o[0], o[1], props[k].getWidth(), props[k].getHeight()};
    }

    private void propOnVerge(Canvas c, Paint bp, Bitmap b, float cx) {
        prop(c, bp, b, cx, 761f + 8f * cx / W);
    }

    private void prop(Canvas c, Paint bp, Bitmap b, float cx, float base) {
        if (b != null) c.drawBitmap(b, cx - b.getWidth() / 2f, base - b.getHeight(), bp);
    }

    private void lamps(Canvas c, float night, float[][] pts, float rad) {
        if (night < 0.06f) return;
        float k = Math.min(1f, night * 1.2f);
        for (float[] p : pts) {
            glow.setShader(new RadialGradient(p[0], p[1], rad,
                    new int[]{argb(190 * k, 255, 214, 130), argb(70 * k, 255, 190, 90), 0},
                    new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(p[0], p[1], rad, glow);
        }
        glow.setShader(null);
    }

    private static int argb(float a, int r, int g, int b) {
        return ((int) Math.max(0, Math.min(255, a)) << 24) | (r << 16) | (g << 8) | b;
    }

    // ---------- people ----------

    private static int hash(long a, int b) {
        long x = a * 0x9E3779B97F4A7C15L + b * 0xBF58476D1CE4E5B9L;
        x ^= (x >>> 29);
        x *= 0x94D049BB133111EBL;
        x ^= (x >>> 32);
        return (int) (x & 0x7fffffff);
    }

    private void people(Canvas c, Paint bp, long now, float night) {
        final long S = 15000L;            // a new walker may start every 15 s
        final float speed = 26f;          // picture px per second
        final long dur = (long) ((W + 400f) / speed * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        for (long n = n0; n <= n1; n++) {
            int h = hash(n, 7);
            if (h % 100 >= 78) continue;
            long t = now - n * S;
            if (t < 0 || t > dur) continue;
            int pick = (h >> 8) % 9;      // walkers 0-7 and the dog
            if (pick == 8) pick = 9;
            Bitmap b = pick < ppl.length ? ppl[pick] : null;
            if (b == null) continue;
            boolean rightward = ((h >> 4) & 1) == 0;
            float sp = speed * (0.85f + ((h >> 12) % 40) / 100f);
            float x = -200f + sp * t / 1000f;
            if (!rightward) x = W + 200f - sp * t / 1000f;
            if (x < -200f || x > W + 200f) continue;
            float feet = 874f + ((h >> 16) % 5);
            // a gentle stride bob
            float bob = (float) Math.abs(Math.sin(t / 1000.0 * 5.2 + h)) * 2.2f;
            drawSprite(c, bp, b, x, feet - bob, !rightward, false, night, 0f);
        }
    }

    // ---------- traffic ----------

    /**
     * Two lanes. Lane A runs left to right (feet at yA), lane B right to left (feet at yB). The sprite sheet of the
     * city has both directions; the highway only has right-facing ones, which are mirrored.
     */
    private void traffic(Canvas c, Paint bp, long now, float night, float yA, float yB, boolean mirrorOnly, float spacingK, float meteorK, float meteorY, float slope, float meteorSlope) {
        // far lane first, then the Meteor (a little further into the far lane), then the near lane on top of it:
        // the bike overtakes behind the oncoming traffic instead of riding over it
        if (!city) {
            runLaneHw(c, bp, now, night, true, 1);
            meteor(c, bp, now, night, meteorY, meteorK, meteorSlope);
            runLaneHw(c, bp, now, night, false, 2);
            return;
        }
        runLane(c, bp, now, night, yA, true, mirrorOnly, 1, slope);
        meteor(c, bp, now, night, meteorY, meteorK, meteorSlope);
        runLane(c, bp, now, night, yB, false, mirrorOnly, 2, slope);
    }

    private void runLane(Canvas c, Paint bp, long now, float night, float feet, boolean rightward, boolean mirrorOnly, int lane, float slope) {
        final long S = city ? 6500L : 7500L;
        final float speed = city ? 115f : (rightward ? 80f : 70f);
        final long dur = (long) ((W + 800f) / speed * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        for (long n = n0; n <= n1; n++) {
            int h = hash(n, lane * 31);
            if (h % 100 >= (city ? 72 : 55)) continue;
            long t = now - n * S;
            if (t < 0 || t > dur) continue;
            int count = veh.length;
            int k;
            boolean flip;
            if (mirrorOnly) {
                k = (h >> 6) % count;
                flip = !rightward;
            } else {
                // right-facing pictures are 0..8, left-facing 9..17
                int base = (h >> 6) % 9;
                k = rightward ? base : base + 9;
                flip = false;
            }
            Bitmap b = veh[k];
            if (b == null) continue;
            float sp = speed * (0.9f + ((h >> 14) % 25) / 100f);
            float x = rightward ? -400f + sp * t / 1000f : W + 400f - sp * t / 1000f;
            if (x < -420f || x > W + 420f) continue;
            // the heaviest vehicles are slower
            drawSprite(c, bp, b, x, feet + slope * Math.max(0f, Math.min(1f, x / W)), flip, true, night, 1f);
        }
    }

    /** Highway speeds in picture px per second, by sprite: bus, blue truck, Thar, bike, yellow pickup, hatchback, army truck, van. Heavy ones are slow, light ones fast. */
    private static final float[] HW_SPEED = {60f, 54f, 90f, 104f, 68f, 98f, 50f, 76f};

    /**
     * The highway's traffic, worked out from the clock alone (no stored state). Vehicles heading right keep to their left, the
     * far (upper) lane; oncoming ones keep to their left, the near (lower) lane. Nobody drives on the centre line (the Meteor's).
     * Each vehicle keeps its own place in its lane. A faster vehicle that catches a slower one moves out to the vehicle's right
     * (toward the centre line), passes, and moves back in.
     */
    private void runLaneHw(Canvas c, Paint bp, long now, float night, boolean rightward, int lane) {
        final long S = 8000L;
        final float vMin = 48f;
        final long dur = (long) ((W + 800f) / vMin * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        final int MAXV = 14;
        float[] pos = new float[MAXV], spd = new float[MAXV], wid = new float[MAXV], u = new float[MAXV];
        int[] kk = new int[MAXV];
        int cnt = 0;
        for (long n = n0; n <= n1 && cnt < MAXV; n++) {
            int h = hash(n, lane * 31);
            if (h % 100 >= 45) continue;
            long t = now - n * S;
            if (t < 0) continue;
            int k = (h >> 6) % Math.max(1, veh.length);
            if (k >= veh.length || veh[k] == null) continue;
            float v = (k < HW_SPEED.length ? HW_SPEED[k] : 70f) * (0.96f + ((h >> 14) % 9) / 100f);
            float dist = v * t / 1000f;                      // how far it has travelled since it entered
            if (dist > W + 800f) continue;
            pos[cnt] = dist; spd[cnt] = v; wid[cnt] = veh[k].getWidth(); u[cnt] = ((h >> 20) % 100) / 100f; kk[cnt] = k;
            cnt++;
        }
        float[] feetA = new float[cnt], xA = new float[cnt];
        Integer[] order = new Integer[cnt];
        for (int i = 0; i < cnt; i++) {
            float shift = 0f, give = 0f;
            for (int j = 0; j < cnt; j++) {
                if (i == j) continue;
                float d = Math.abs(pos[j] - pos[i]);
                float gap = (wid[i] + wid[j]) / 2f + 12f, ramp = 120f;
                float f = d <= gap ? 1f : (d >= gap + ramp ? 0f : 1f - (d - gap) / ramp);
                f = f * f * (3f - 2f * f);
                if (spd[i] > spd[j]) { if (f > shift) shift = f; }     // I am the faster one: I pull out and pass
                else if (spd[i] < spd[j]) { if (f > give) give = f; }  // the faster one passes me: I give it room
            }
            float x = rightward ? -400f + pos[i] : W + 400f - pos[i];
            float line = HW_LINE + HW_SLOPE * Math.max(0f, Math.min(1f, x / W));
            float off;
            if (rightward) {
                final float edge = -27f;                      // far edge of the road: nobody goes further
                float own = edge + 10f * u[i];                 // its own place in the lane
                off = own + (-10f - own) * shift + (edge - own) * give * (1f - shift);
            } else {
                final float edge = 19f;                       // near edge of the road
                float own = edge - 6f * u[i];
                off = own + (6f - own) * shift + (edge - own) * give * (1f - shift);
            }
            xA[i] = x; feetA[i] = line + off; order[i] = i;
        }
        final float[] fa = feetA;
        java.util.Arrays.sort(order, new java.util.Comparator<Integer>() {
            @Override public int compare(Integer p, Integer q) { return Float.compare(fa[p], fa[q]); }
        });
        for (int oi = 0; oi < cnt; oi++) {
            int i = order[oi];
            if (xA[i] < -420f || xA[i] > W + 420f) continue;
            drawSprite(c, bp, veh[kk[i]], xA[i], feetA[i], !rightward, true, night, 1f);
        }
    }

    private void meteor(Canvas c, Paint bp, long now, float night, float feet, float scale, float slope) {
        if (meteor == null) return;
        long k = now / PERIOD;
        long ev = k * PERIOD + (long) ((hash(k, 99) % 10000) / 10000f * 10f * 60000f);
        float p = -1f;
        if (now >= ev && now < ev + METEOR_MS) p = (now - ev) / (float) METEOR_MS;
        long m = now - manualStart;
        if (m >= 0 && m < METEOR_MS) p = m / (float) METEOR_MS;
        if (p < 0f) return;
        float bw = meteor.getWidth() * scale, bh = meteor.getHeight() * scale;
        float x = -bw + (W + 2f * bw) * p;       // about three times faster than the traffic
        float y = feet + slope * Math.max(0f, Math.min(1f, (x + bw / 2f) / W));
        c.save();
        c.translate(x - bw / 2f + bw / 2f, 0f);
        // speed streak behind the bike
        if (night > 0.2f) {
            float a = Math.min(1f, night * 1.3f);
            glow.setShader(new android.graphics.LinearGradient(-bw * 2.4f, 0f, 0f, 0f, 0x00FF4030, argb(120 * a, 255, 70, 50), Shader.TileMode.CLAMP));
            c.drawRect(-bw * 2.4f, y - bh * 0.42f, 0f, y - bh * 0.34f, glow);
            glow.setShader(null);
        } else {
            glow.setShader(new android.graphics.LinearGradient(-bw * 2.0f, 0f, 0f, 0f, 0x00FFFFFF, 0x66FFFFFF, Shader.TileMode.CLAMP));
            c.drawRect(-bw * 2.0f, y - bh * 0.30f, 0f, y - bh * 0.26f, glow);
            glow.setShader(null);
        }
        c.restore();
        Paint pp = bp;
        c.drawBitmap(meteor, null, new android.graphics.RectF(x, y - bh, x + bw, y), pp);
        if (night > 0.12f) {
            float hx = x + bw * lampX, hy = y - bh * lampY;
            headlight(c, hx, hy, 150f * scale + 40f, night, true);
        }
    }

    private void headlight(Canvas c, float x, float y, float len, float night, boolean toRight) {
        float a = Math.min(1f, (night - 0.1f) * 1.4f);
        if (a <= 0f) return;
        float dir = toRight ? 1f : -1f;
        glow.setShader(new RadialGradient(x, y, len, new int[]{argb(190 * a, 255, 240, 190), argb(60 * a, 255, 225, 150), 0},
                new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        c.save();
        c.translate(x, y);
        c.scale(1.7f * dir, 0.45f);
        c.translate(-x, -y);
        c.drawCircle(x, y, len, glow);
        c.restore();
        glow.setShader(null);
    }

    /**
     * @param feet  y of the wheels / feet
     * @param flip  mirror the picture
     */
    private void drawSprite(Canvas c, Paint bp, Bitmap b, float cx, float feet, boolean flip, boolean vehicle, float night, float unused) {
        float w = b.getWidth(), h = b.getHeight();
        float left = cx - w / 2f, top = feet - h + 3f;
        c.save();
        if (flip) c.scale(-1f, 1f, cx, 0f);
        c.drawBitmap(b, left, top, bp);
        c.restore();
        if (vehicle && night > 0.12f) {
            // the car travels toward its front: right-facing picture unless mirrored
            boolean right = !flip;
            // pictures 9..17 of the city sheet face left; their flip flag is false but they head left
            int idx = -1;
            for (int i = 0; i < veh.length; i++) if (veh[i] == b) { idx = i; break; }
            if (city && idx >= 9) right = false;
            float fx = right ? cx + w * 0.47f : cx - w * 0.47f;
            float fy = top + h * 0.62f;
            headlight(c, fx, fy, Math.max(60f, w * 0.55f), night, right);
            float rx = right ? cx - w * 0.47f : cx + w * 0.47f;
            float a = Math.min(1f, (night - 0.1f) * 1.4f);
            glow.setShader(new RadialGradient(rx, fy, 9f, new int[]{argb(200 * a, 255, 50, 40), 0}, null, Shader.TileMode.CLAMP));
            c.drawCircle(rx, fy, 9f, glow);
            glow.setShader(null);
        }
    }
}
