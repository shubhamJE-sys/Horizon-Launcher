package com.horizon.launcher;

import android.graphics.Color;

/**
 * A colour scheme. Each scheme describes the whole-screen sky gradient for three phases of the day
 * (day, twilight, night) as four colours: top, mid, horizon, deep (bottom of the screen).
 */
final class Palette {

    final String id;
    final String name;
    final int[] day, twi, night;
    final int accent;
    final float[] tint;
    final boolean bleed;

    private Palette(String id, String name, String[] day, String[] twi, String[] night,
                    String accent, float[] tint, boolean bleed) {
        this.id = id;
        this.name = name;
        this.day = parse(day);
        this.twi = parse(twi);
        this.night = parse(night);
        this.accent = Color.parseColor(accent);
        this.tint = tint;
        this.bleed = bleed;
    }

    private static int[] parse(String[] s) {
        int[] o = new int[s.length];
        for (int i = 0; i < s.length; i++) o[i] = Color.parseColor(s[i]);
        return o;
    }

    private static final String[] H_DAY = {"#E6DFCD", "#ECE4D1", "#F1E7CF", "#D9D1BF"};
    private static final String[] H_TWI = {"#6A5A66", "#B98768", "#EBA877", "#6F5A58"};
    private static final String[] H_NIGHT = {"#0B0E16", "#141926", "#262C3E", "#0D1018"};

    static final Palette HORIZON = new Palette("HORIZON", "HORIZON  •  SKY COLOURS",
            H_DAY, H_TWI, H_NIGHT, "#C8382C", new float[]{1f, 1f, 1f}, true);

    static final Palette MONSOON = new Palette("MONSOON", "MONSOON  •  COOL BLUE",
            new String[]{"#DCE3E3", "#E4EAE8", "#EAF0EC", "#C9D3D2"},
            new String[]{"#4C5668", "#8D93A6", "#D3A890", "#4A5262"},
            new String[]{"#080D14", "#101A24", "#1C2B38", "#0A1118"},
            "#1F7A8C", new float[]{0.92f, 1.0f, 1.06f}, true);

    static final Palette SAFFRON = new Palette("SAFFRON", "SAFFRON  •  WARM GOLD",
            new String[]{"#F1E0C2", "#F5E4C6", "#F8E5BE", "#E3C99B"},
            new String[]{"#7A3E34", "#D0703A", "#F2A33C", "#6B3A2C"},
            new String[]{"#14080C", "#24101A", "#3B1A22", "#160A0C"},
            "#C2410C", new float[]{1.06f, 0.97f, 0.85f}, true);

    static final Palette FOREST = new Palette("FOREST", "FOREST  •  SAGE GREEN",
            new String[]{"#DCE2CE", "#E3E8D4", "#EAEDD5", "#C8D0B4"},
            new String[]{"#3F4A47", "#8E8A66", "#D9A860", "#3E4A3A"},
            new String[]{"#07100C", "#0F1C15", "#1B2D22", "#08120D"},
            "#B5532C", new float[]{0.93f, 1.04f, 0.9f}, true);

    static final Palette MONO = new Palette("MONO", "MONO  •  BLACK AND WHITE",
            new String[]{"#E7E7E5", "#EDEDEB", "#F1F1EF", "#D2D2D0"},
            new String[]{"#4A4A4E", "#8C8C90", "#CFCFCF", "#4C4C50"},
            new String[]{"#09090B", "#151518", "#26262A", "#0C0C0E"},
            "#B3261E", new float[]{0.98f, 0.98f, 1.0f}, true);

    static final Palette CLASSIC = new Palette("CLASSIC", "CLASSIC CREAM  •  ORIGINAL",
            H_DAY, H_TWI, H_NIGHT, "#C8382C", new float[]{1f, 1f, 1f}, false);

    // ---- festival schemes (not listed in the menu; chosen by the festival calendar) ----

    static final Palette DIWALI = new Palette("DIWALI", "DIWALI",
            new String[]{"#F3DDB0", "#F7E0A8", "#FBDC90", "#E7BE72"},
            new String[]{"#5C1F2B", "#B8452A", "#F6A623", "#4A1A20"},
            new String[]{"#12060B", "#2A0E14", "#4B1A14", "#170709"},
            "#A31621", new float[]{1.08f, 0.98f, 0.8f}, true);

    static final Palette TRICOLOUR = new Palette("TRICOLOUR", "TRICOLOUR",
            new String[]{"#F6C58B", "#F4EEDF", "#EFEAD8", "#B9D6A6"},
            new String[]{"#7A4A2E", "#D9B58A", "#EAD6B0", "#4C7046"},
            new String[]{"#1A1008", "#1B1B1E", "#22252A", "#0B1A0E"},
            "#1B3F94", new float[]{1f, 1f, 1f}, true);

    static final Palette HOLI = new Palette("HOLI", "HOLI",
            new String[]{"#F6D0E0", "#F8E7B5", "#D4EBD0", "#CBD6F4"},
            new String[]{"#6A3A6A", "#C0507A", "#F0A04A", "#3E4A7A"},
            new String[]{"#14081E", "#231040", "#3A1A54", "#0E1030"},
            "#C2185B", new float[]{1f, 1f, 1f}, true);

    static final Palette EID = new Palette("EID", "EID",
            new String[]{"#DCEBDD", "#E6F0E2", "#F1F0DC", "#C5DCC9"},
            new String[]{"#1F3E44", "#4D8F7A", "#E3C27A", "#1B3A38"},
            new String[]{"#04100F", "#0A1F1C", "#12342F", "#05110E"},
            "#0F7B4A", new float[]{0.92f, 1.02f, 0.96f}, true);

    static final Palette CHRISTMAS = new Palette("CHRISTMAS", "CHRISTMAS",
            new String[]{"#E3ECE6", "#EEF3EE", "#F5F2EA", "#D3DED6"},
            new String[]{"#2D3B3A", "#A8605A", "#E7B089", "#2F3F36"},
            new String[]{"#06100C", "#0E1C16", "#1B2F25", "#07120D"},
            "#B3261E", new float[]{0.95f, 1.02f, 0.97f}, true);

    static final Palette GOLD = new Palette("GOLD", "GOLD",
            new String[]{"#F2E3BE", "#F5E8C6", "#F8EAC0", "#E5D09E"},
            new String[]{"#6B4A2E", "#C98E3C", "#F2C25A", "#5C4326"},
            new String[]{"#120C06", "#21160C", "#37250F", "#140D06"},
            "#A8700A", new float[]{1.06f, 1.0f, 0.86f}, true);

    /** The schemes the user can pick from the style menu. */
    static final Palette[] USER = {HORIZON, MONSOON, SAFFRON, FOREST, MONO, CLASSIC};

    private static final Palette[] ALL = {HORIZON, MONSOON, SAFFRON, FOREST, MONO, CLASSIC,
            DIWALI, TRICOLOUR, HOLI, EID, CHRISTMAS, GOLD};

    static Palette byId(String id) {
        if (id != null) {
            for (Palette p : ALL) {
                if (p.id.equalsIgnoreCase(id)) return p;
            }
        }
        return HORIZON;
    }
}
