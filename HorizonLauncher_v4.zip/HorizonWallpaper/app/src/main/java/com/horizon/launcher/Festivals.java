package com.horizon.launcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Locale;

/**
 * Built-in festival calendar (Indian government gazetted holidays plus popular festivals, 2026-2027).
 * Entries with a full date (YYYY-MM-DD) apply once; entries with MM-DD repeat every year.
 * A content pack can add or override entries without a new APK.
 */
final class Festivals {

    static final class Fest {
        String name = "", greet = "", tagline = "", s1 = "", s2 = "", palette = "GOLD", decor = "SPARKLE";
    }

    // date, name, greeting, tagline, slogan1, slogan2, palette, decor
    private static final String[][] BUILTIN = {
            // ----- repeating every year -----
            {"01-01", "NEW YEAR", "HAPPY NEW YEAR", "A FRESH YEAR, A FRESH SKY", "NEW YEAR|NEW|HORIZONS", "MAKE|THIS YEAR|YOUR BEST|YET", "GOLD", "SPARKLE"},
            {"01-26", "REPUBLIC DAY", "HAPPY REPUBLIC DAY", "PROUD OF OUR REPUBLIC", "REPUBLIC|DAY", "JAI HIND|JAI|BHARAT", "TRICOLOUR", "TRICOLOUR"},
            {"04-14", "AMBEDKAR JAYANTI", "AMBEDKAR JAYANTI", "EDUCATE. AGITATE. ORGANISE", "AMBEDKAR|JAYANTI", "EQUALITY|LIBERTY|FRATERNITY", "MONSOON", "SPARKLE"},
            {"08-15", "INDEPENDENCE DAY", "HAPPY INDEPENDENCE DAY", "FREE SKIES, PROUD HEARTS", "INDEPENDENCE|DAY", "JAI HIND|JAI|BHARAT", "TRICOLOUR", "TRICOLOUR"},
            {"09-05", "TEACHERS DAY", "HAPPY TEACHERS DAY", "THANK YOU TO EVERY TEACHER", "TEACHERS|DAY", "THANK YOU|FOR THE|LIGHT", "GOLD", "SPARKLE"},
            {"10-02", "GANDHI JAYANTI", "GANDHI JAYANTI", "BE THE CHANGE YOU WISH TO SEE", "GANDHI|JAYANTI", "TRUTH|AND|NON-|VIOLENCE", "GOLD", "SPARKLE"},
            {"12-25", "CHRISTMAS", "MERRY CHRISTMAS", "PEACE, JOY AND WARM WISHES", "MERRY|CHRISTMAS", "PEACE ON|EARTH|GOODWILL|TO ALL", "CHRISTMAS", "SNOW"},
            {"12-31", "NEW YEAR EVE", "HAPPY NEW YEAR EVE", "GOODBYE OLD YEAR, HELLO NEW", "LAST|DAY OF|THE YEAR", "THANK YOU|FOR|EVERYTHING", "GOLD", "SPARKLE"},

            // ----- 2026 (remaining) -----
            {"2026-11-08", "DIWALI", "HAPPY DIWALI", "MAY YOUR LIFE GLOW WITH LIGHT", "HAPPY|DIWALI", "LIGHT|OVER|DARKNESS|ALWAYS", "DIWALI", "DIYA"},
            {"2026-11-24", "GURU NANAK JAYANTI", "HAPPY GURPURAB", "ONE LIGHT, ONE ENERGY, ONE LOVE", "GURU NANAK|JAYANTI", "SERVE|SHARE|REMEMBER", "GOLD", "SPARKLE"},

            // ----- 2027 -----
            {"2027-01-15", "PONGAL", "HAPPY PONGAL", "SWEET RICE, BRIGHT SKIES", "HAPPY|PONGAL|SANKRANTI", "FLY HIGH|LIKE A|KITE", "SAFFRON", "KITES"},
            {"2027-02-11", "VASANT PANCHAMI", "HAPPY VASANT PANCHAMI", "SPRING BEGINS WITH LEARNING", "VASANT|PANCHAMI", "SPRING|IS|HERE", "GOLD", "SPARKLE"},
            {"2027-03-06", "MAHA SHIVRATRI", "HAPPY MAHA SHIVRATRI", "OM NAMAH SHIVAYA", "MAHA|SHIVRATRI", "OM NAMAH|SHIVAYA", "MONSOON", "SPARKLE"},
            {"2027-03-10", "EID AL-FITR", "EID MUBARAK", "MAY YOUR DAY BE BLESSED", "EID|MUBARAK", "PEACE|JOY|BLESSINGS", "EID", "CRESCENT"},
            {"2027-03-23", "HOLI", "HAPPY HOLI", "COLOURS OF JOY FOR YOU", "HAPPY|HOLI", "COLOURS|OF|JOY", "HOLI", "COLOURS"},
            {"2027-03-26", "GOOD FRIDAY", "GOOD FRIDAY", "A DAY OF QUIET REFLECTION", "GOOD|FRIDAY", "QUIET|REFLECT|REMEMBER", "MONO", "NONE"},
            {"2027-04-07", "UGADI", "HAPPY UGADI", "NEW YEAR, NEW BEGINNINGS", "HAPPY UGADI|GUDI PADWA", "NEW|YEAR|NEW|HOPES", "SAFFRON", "SPARKLE"},
            {"2027-04-15", "RAM NAVAMI", "HAPPY RAM NAVAMI", "JAI SHRI RAM", "RAM|NAVAMI", "JAI|SHRI|RAM", "SAFFRON", "SPARKLE"},
            {"2027-04-19", "MAHAVIR JAYANTI", "MAHAVIR JAYANTI", "LIVE AND LET LIVE", "MAHAVIR|JAYANTI", "LIVE|AND LET|LIVE", "GOLD", "SPARKLE"},
            {"2027-05-17", "EID AL-ADHA", "EID MUBARAK", "MAY YOUR DAY BE BLESSED", "EID AL-ADHA|MUBARAK", "PEACE|JOY|BLESSINGS", "EID", "CRESCENT"},
            {"2027-05-20", "BUDDHA PURNIMA", "HAPPY BUDDHA PURNIMA", "PEACE BEGINS WITHIN", "BUDDHA|PURNIMA", "PEACE|BEGINS|WITHIN", "GOLD", "SPARKLE"},
            {"2027-06-16", "MUHARRAM", "MUHARRAM", "A DAY OF REMEMBRANCE", "MUHARRAM", "REMEMBER|REFLECT", "MONO", "NONE"},
            {"2027-08-17", "RAKSHA BANDHAN", "HAPPY RAKSHA BANDHAN", "A BOND THAT NEVER BREAKS", "RAKSHA|BANDHAN", "A BOND|OF LOVE|AND CARE", "SAFFRON", "SPARKLE"},
            {"2027-08-25", "JANMASHTAMI", "HAPPY JANMASHTAMI", "RADHE RADHE", "HAPPY|JANMASHTAMI", "JAI|SHRI|KRISHNA", "MONSOON", "SPARKLE"},
            {"2027-09-04", "GANESH CHATURTHI", "GANPATI BAPPA MORYA", "WELCOME HOME, BAPPA", "GANESH|CHATURTHI", "GANPATI|BAPPA|MORYA", "SAFFRON", "SPARKLE"},
            {"2027-09-12", "ONAM", "HAPPY ONAM", "A FEAST OF FLOWERS AND JOY", "HAPPY|ONAM", "FLOWERS|FEAST|JOY", "GOLD", "SPARKLE"},
            {"2027-09-30", "NAVRATRI", "HAPPY NAVRATRI", "NINE NIGHTS OF JOY AND DANCE", "HAPPY|NAVRATRI", "NINE|NIGHTS|OF|SHAKTI", "SAFFRON", "SPARKLE"},
            {"2027-10-09", "DUSSEHRA", "HAPPY DUSSEHRA", "GOOD ALWAYS WINS", "HAPPY|DUSSEHRA", "VICTORY|OF GOOD|OVER EVIL", "SAFFRON", "SPARKLE"},
            {"2027-10-29", "DIWALI", "HAPPY DIWALI", "MAY YOUR LIFE GLOW WITH LIGHT", "HAPPY|DIWALI", "LIGHT|OVER|DARKNESS|ALWAYS", "DIWALI", "DIYA"},
            {"2027-10-31", "BHAI DOOJ", "HAPPY BHAI DOOJ", "TO BROTHERS AND SISTERS", "HAPPY|BHAI DOOJ", "SIBLINGS|ARE|FOREVER", "GOLD", "SPARKLE"},
            {"2027-11-14", "GURU NANAK JAYANTI", "HAPPY GURPURAB", "ONE LIGHT, ONE ENERGY, ONE LOVE", "GURU NANAK|JAYANTI", "SERVE|SHARE|REMEMBER", "GOLD", "SPARKLE"},
    };

    private static Fest fromRow(String[] r) {
        Fest f = new Fest();
        f.name = r[1];
        f.greet = r[2];
        f.tagline = r[3];
        f.s1 = r[4];
        f.s2 = r[5];
        f.palette = r[6];
        f.decor = r[7];
        return f;
    }

    private static String joinLines(JSONObject o, String key) {
        Object v = o.opt(key);
        if (v instanceof JSONArray) {
            JSONArray a = (JSONArray) v;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < a.length(); i++) {
                if (i > 0) sb.append('|');
                sb.append(a.optString(i, ""));
            }
            return sb.toString();
        }
        return v == null ? "" : String.valueOf(v);
    }

    private static Fest fromJson(JSONObject o) {
        Fest f = new Fest();
        f.name = o.optString("name", "FESTIVAL").toUpperCase(Locale.ENGLISH);
        f.greet = o.optString("greeting", f.name).toUpperCase(Locale.ENGLISH);
        f.tagline = o.optString("tagline", "").toUpperCase(Locale.ENGLISH);
        f.s1 = joinLines(o, "slogan1").toUpperCase(Locale.ENGLISH);
        f.s2 = joinLines(o, "slogan2").toUpperCase(Locale.ENGLISH);
        f.palette = o.optString("palette", "GOLD");
        f.decor = o.optString("decor", "SPARKLE").toUpperCase(Locale.ENGLISH);
        return f;
    }

    /** A festival by name (for the preview menu): built-in entries only. */
    static Fest byName(String name) {
        if (name == null) return null;
        for (String[] r : BUILTIN) {
            if (r[1].equalsIgnoreCase(name)) return fromRow(r);
        }
        return null;
    }

    /** Returns today's festival or null. Content-pack entries win over built-in ones; exact dates win over yearly ones. */
    static Fest find(Calendar cal, JSONArray pack) {
        String full = String.format(Locale.US, "%04d-%02d-%02d",
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
        String yearly = full.substring(5);

        Fest packYearly = null;
        if (pack != null) {
            for (int i = 0; i < pack.length(); i++) {
                JSONObject o = pack.optJSONObject(i);
                if (o == null) continue;
                String d = o.optString("date", "");
                if (d.equals(full)) return fromJson(o);
                if (d.equals(yearly) && packYearly == null) packYearly = fromJson(o);
            }
        }
        if (packYearly != null) return packYearly;

        Fest builtinYearly = null;
        for (String[] r : BUILTIN) {
            if (r[0].equals(full)) return fromRow(r);
            if (r[0].equals(yearly) && builtinYearly == null) builtinYearly = fromRow(r);
        }
        return builtinYearly;
    }
}
